import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";

import "@fortawesome/fontawesome-free/css/all.min.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'assets/styles/style.css'
import 'assets/styles/style-responsive.css'
import 'assets/styles/deone.scss'

import { I18nextProvider } from 'react-i18next';
import i18n from './i18n';

import 'react-notifications/lib/notifications.css';

import MainLayout from "layouts/MainLayout"
import WatchLayout from "layouts/WatchLayout"

import Index from "views/Index";

import DeOneStatus from "views/DeOneStatus"
import GuaranteeStatus from "views/GuaranteeStatus";
import Oracle from "views/Oracle";
import Auction from "views/Auction";
import EcoSystem from "views/EcoSystem";
import Addresses from "views/Address";

import * as serviceWorker from './serviceWorker';

ReactDOM.render(

  <I18nextProvider i18n={i18n}>
    <BrowserRouter>
      <Switch>
        <WatchLayout>
          <Route path="/" exact component={Index} />
          <MainLayout>
            <Route path="/deonestatus" exact component={DeOneStatus} />
            <Route path="/guaranteeStatus" exact component={GuaranteeStatus} />
            <Route path="/oracle" exact component={Oracle} />
            <Route path="/auction" exact component={Auction} />
            <Route path="/ecoSystem" exact component={EcoSystem} />
            <Route path="/address" exact component={Addresses} />
          </MainLayout>
        </WatchLayout>
        <Redirect from="*" to="/notFount" />
      </Switch>
    </BrowserRouter>
  </I18nextProvider>,
  document.getElementById("root")
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();