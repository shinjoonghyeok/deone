const main = {
  "waiting": {
    "main-title": "잠시만 기다려주세요.",
    "sub-title": "이더리움 메인넷에서 데이터를 가져오는 중..."
    
  }
}

export default main;