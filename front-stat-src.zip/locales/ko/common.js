const common = {
  "error": {
    "notfound-title": "페이지를 찾을 수 없습니다.",
    "notfound-description": "찾고 있는 페이지가 없거나 존재하지 않습니다. <br />웹 주소가 올바른지 다시 확인해 주세요."
  },
  "btn": {
    "goto-home": "홈으로 가기"
  },
  "loading": {
    "initialize": "초기화중..."
  }
}

export default common;