const guarantee = {
    "loan-limit": "부채한도",
    "done-count": "디원수량",
    "guarantee-difference":"담보 차액",
    "recent-update":"최근 업데이트",
    "usage-rate":"이용률",
    "saftify-fee":"안정화 수수료",
    "recent-interest-date" : "최근 이자 지급일",
    "lowest-loan" : "최소대출액",
    "saved-amount":"예치된 수량",
    "saved-rate" : "예치율",
    "eth-a" : "ETH-A",
    "ttl" : "Ttl",
    "recent-update":"최근 업데이트",
}

export default guarantee;