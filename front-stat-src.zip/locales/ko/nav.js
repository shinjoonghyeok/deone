const nav = {
  "done-status": "디원현황",
  "guarantee-status": "담보현황",
  "oracle": "오라클",
  "auction": "경매",
  "life-cycle": "생태계",
  "address": "주소",
  "btn": {
    "block-update": "블록 {{block}}. 자동 업데이트 중."
  }
}

export default nav;
