const address = {
    "govAlpha" : "GovAlpha",
    "riskCoreUnit" : "Risk Core Unit",
    "growthCoreUnit" : "Growth Core Unit",
    "realWorldCoreUnit" : "Real World Core Unit",
    "contentPriductionUnit" : "Content Production Unit"
}

export default address;