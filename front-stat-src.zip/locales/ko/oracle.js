const oracle = {
    "nowPrice" : "현재가격",
    "predic-priceOfDiffer" : "변경 예상가격",
    "next-update" : "다음 업데이트",
    "ethTicker" : "ETH",
    "btcTicker" : "BTC",
    "yfiTicker" : "YFI",
    "uniTicker" : "UNI",
    "unit": "원"

}
  
  export default oracle;