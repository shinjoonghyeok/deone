const auction = {
    "left-DOne-Auction" : "디원 여분 경매",
    "tillNext-left-Auction" : "다음 여분 경매까지",
    "opened-vault" : "개설된 Vault",
    "supply-MCT" : "MCT 공급",
    "protocol-seed" : "프로토콜 자금"

}

export default auction;