const footer = {
  "menu": {
    "done-service": "디원 서비스",
    "community": "커뮤니티",
    "language": "언어",
    "use-guide": "이용안내",
    "loan-prod": "대출상품",
    "saving-prod": "저축상품",
    "governance": "거버넌스",
    "notice": "공지사항",
    "english": "English",
    "korea": "한국어",
    "privacy-policy": "개인정보처리방침",
    "use-term": "이용약관",
    "service-manual": "서비스 매뉴얼",
    "contact": "Contact"
  },
  "footer": {
    "address": "서울특별시 강남구 논현로63길 71 (주)몬스터큐브",
    "ceo": "CEO:유재범",
    "biz-number": "사업자등록:441-87-00779",
    "sail-number": "통신판매번호:제2018-서울강남-02815호",
    "tel": "Tel:02 1522 9746",
    "fax": "Fax : 0504 276 3309",
    "copy": "Copyright ©MONSTER CUBE Corporation. All Rights Reserved."
  }
}

export default footer;