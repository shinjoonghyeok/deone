export { default as nav } from './nav';
export { default as footer } from './footer';
export { default as common } from './common';

export { default as main } from './main';
export { default as done } from './done';
export { default as guarantee } from './guarantee';
export { default as oracle } from './oracle';
export { default as auction } from './auction';
export { default as ecosystem } from './ecosystem';
export { default as address } from './address';

