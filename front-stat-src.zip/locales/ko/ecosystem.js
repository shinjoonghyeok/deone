const Ecosystem = {
    "gsmPauseDelay": "GSM Pause Delay",
    "flashLoanLimit" : "Dai Flash Loan Limit",
    "tillNextAuction" : "다음 여분경매까지",
    "DaiSupply" : "Dai (ERC20) Supplt",
    "DaiInDsr" : "Dai in DSR",
    "pieInDsr" : "Pie in DSR",
    "daiSavingsRate" : "Dai Savings Rate",
    "lastDrip" : "Last Drip"
}

export default Ecosystem;