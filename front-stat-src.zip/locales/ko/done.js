const done = {
  "loan-limit": "부채한도",
  "done-count": "디원수량",
  "total-saving-amount": "총 예치 금액",
  "money-unit": "원",
  "guarantee-status": "담보현황",
  "saftify-fee":"안정화 수수료",
  "guarantee-difference":"담보 차액",
  "recent-interest-date" : "최근 이자 지급일",
  "deone-collateral": "담보 DeOne",
  "deone-generate": "생성된 DeOne",
  "lock-amount": "락업된 총 자산 가치",
  "guarantee-rate": "담보 비율"
}

export default done;