const main = {
  "intro": {
    "done-title": "Stabilized digital currency 'DeOne'",
    "done-content": "DeOne is a digital currency that pursues a stable KRW value, <br />and anyone can experience it in a decentralized ecosystem.",
    "done-subtitle": "A stable currency that pursues neutrality for the first time in Korea",
    "done-subcontent": "DeOne pursues stable value as a decentralized currency <br />without discrimination for users."
  },
  "service": {
    "done-service": "디원 서비스",
    "done-service-sub": "DeONE Service",
    "intro-done": "디원소개",
    "intro-done-content": "디파이 실형을 위한 웰렛 플렛폼을 <br />통해 디원을 경험하세요.",
    "loan-prod": "대출상품",
    "loan-prod-content": "더 많은 투자기회 확보를 <br />위해 담보대출을 이용해보세요.",
    "saving-prod": "저축상품",
    "saving-prod-content": "저축을 통해 안전화된 <br />자산관리를 경험하세요.",
    "governance": "거버넌스",
    "governance-content": "탈중앙화의 의사결정 <br />직접 투표하고 의사결정하세요."
  },
  "support": {
    "done-support": "지원서비스",
    "done-support-sub": "support Sservice",
    "support-bb-title": "쉽고 안전한 개인용 멀티 암호화폐 결제 지갑",
    "support-bb-content": "암호화폐 노드 집접 운영 및 관리를 통한 <br />안정적인 서비스",
    "support-bs-title": "차세대 디파이 탈중앙거래소 서비스",
    "support-bs-content": "이더리움 네트워크를 이용한 <br />스마트 컨트랙트로 구현된 거래소"
  },
  "partner": {
    "done-partner": "파트너사",
    "done-partner-sub": "Our Partners"
  },
  "external": {
    "done-external": "외부 지원 서비스",
    "done-external-sub": "External Support Service"
  },
  "btn": {
    "deploy-done": "디원 발행하기",
    "movie-done": "디원 영상보기",
    "goto": "바로가기 >",
    "make-bb-wallet": "비트베리 월렛 만들기",
    "goto-bs": "비트베리스왑 바로가기" 
  }
}

export default main;