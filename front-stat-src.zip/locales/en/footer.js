const footer = {
  "menu": {
    "done-service": "DeONE Service",
    "community": "Community",
    "language": "Language",
    "use-guide": "Information",
    "loan-prod": "Loan Products",
    "saving-prod": "Saving Products",
    "governance": "Governance",
    "notice": "Notice",
    "english": "English",
    "korea": "한국어",
    "privacy-policy": "Privacy Policy",
    "use-term": "Terms of service",
    "service-manual": "Service Manual",
    "contact": "Contact"
  },
  "footer": {
    "address": "71, Nonhyeon-ro 63-gil, Gangnam-gu, Seoul, Korea Monster Cube",
    "ceo": "CEO:유재범",
    "biz-number": "Business Registration:441-87-00779",
    "sail-number": "통신판매번호:제2018-서울강남-02815호",
    "tel": "Tel:02 1522 9746",
    "fax": "Fax : 0504 276 3309",
    "copy": "Copyright ©MONSTER CUBE Corporation. All Rights Reserved."
  }
}

export default footer;
