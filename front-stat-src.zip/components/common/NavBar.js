import React, {useContext, useState} from 'react'
import { Link, NavLink, useHistory } from "react-router-dom";
import { useTranslation } from 'react-i18next';

import { WatchDeOneState } from "layouts/WatchLayout"

import DeOneLogo from "assets/images/logo_deone.png"

const NavBar = () => {
  const [navbarOpen, setNavbarOpen] = React.useState(false);
  const { t } = useTranslation('nav');
  let history = useHistory();
  const { requestValue } = useContext(WatchDeOneState);
  
  let block = requestValue.blockNumber;
  block = Number(block).toLocaleString();

  const [mobileMenu, setMobileMenu] = useState(false);
  
  const toggleOn = () => {
    if(mobileMenu) setMobileMenu(false)
    else setMobileMenu(true)
  }

  const toggleOff = () => {
    setMobileMenu(false)
  }

  return (  
    <header id="header" className="px-3 py-4 px-lg-0">
      <nav className="gnb-bar container">
        <div className="row">
          <div className="col-auto z-index-999">
            <Link
              to="/"
            >
              <img src={DeOneLogo} alt="DeONE" />
            </Link>
          </div>
          <div className="col d-none d-lg-block">
            <div className="row justify-content-end fs-16 fw-500 h-100">
              <NavLink
                to="/deoneStatus"
                className="col-auto me-4 my-auto"
              >
                <span className="link-hover">{ t('done-status') }</span>
              </NavLink>
              <NavLink
                to="/guaranteeStatus"
                className="col-auto me-4 my-auto"
              >
                <span className="link-hover">{ t('guarantee-status') }</span>
              </NavLink>
              <NavLink
                to="/oracle"
                className="col-auto me-4 my-auto"
              >
                <span className="link-hover">{ t('oracle') }</span>
              </NavLink>
              <NavLink
                to="/auction"
                className="col-auto me-4 my-auto"
              >
                <span className="link-hover">{ t('auction') }</span>
              </NavLink>
              <NavLink
                to="/ecoSystem"
                className="col-auto me-4 my-auto"
              >
                <span className="link-hover">{ t('life-cycle') }</span>
              </NavLink>
              <NavLink
                to="/address"
                className="col-auto me-4 my-auto"
              >
                <span className="link-hover">{ t('address') }</span>
              </NavLink>
              
              <div className="col-auto fc-855cea border border-color-1 rounded-pill fs-14 fw-400 py-1 px-3 my-auto">
                <span>{ t('btn.block-update', {block}) }</span>
              </div>
            </div>
          </div>
          <div className="col d-lg-none">
            <div className="row justify-content-end">
              <div className={mobileMenu ? "menu menu-ico move-left close-ico z-index-999 active" : "menu menu-ico move-left close-ico z-index-999"} onClick={toggleOn}>
                <span className="fs-0">menu</span>
              </div>
            </div>
          </div>
          <div className={mobileMenu ? "pop-gnb active" : "pop-gnb"}  onClick={toggleOff}>
            <div className="pop-gnb-wrap fs-20 fw-700 text-center">
              <NavLink
                to="/deoneStatus"
                className="d-block btn btn-primary btn-outline mb-3"
              >
                <span className="link-hover">{ t('done-status') }</span>
              </NavLink>
              <NavLink
                to="/guaranteeStatus"
                className="d-block btn btn-primary btn-outline mb-3"
              >
                <span className="link-hover">{ t('guarantee-status') }</span>
              </NavLink>
              <NavLink
                to="/oracle"
                className="d-block btn btn-primary btn-outline mb-3"
              >
                <span className="link-hover">{ t('oracle') }</span>
              </NavLink>
              <NavLink
                to="/auction"
                className="d-block btn btn-primary btn-outline mb-3"
              >
                <span className="link-hover">{ t('auction') }</span>
              </NavLink>
              <NavLink
                to="/ecoSystem"
                className="d-block btn btn-primary btn-outline mb-3"
              >
                <span className="link-hover">{ t('life-cycle') }</span>
              </NavLink>
              <NavLink
                to="/address"
                className="d-block btn btn-primary btn-outline mb-3"
              >
                <span className="link-hover">{ t('address') }</span>
              </NavLink>
              
              <div href="" className="d-block border border-1 rounded-pill fs-14 fw-400 py-1 px-3 my-auto bg-ffffff">
                <span>{ t('btn.block-update', {block}) }</span>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </header>
  )
}

export default NavBar
