import React from 'react'

import DeOneFooterLogo from "assets/images/f_logo_deone.png"

const Footer = () => {
  return (
    <footer id="footer" className="bg-1f1b2f py-4 py-sm-5">
      <div className="container text-center py-4 py-sm-5">
          <img className="mb-4" src={DeOneFooterLogo} alt="DeOne" />
          <p className="fs-14 fs-sm-16 mb-3">Copyright © MONSTER CUBE Corporation. All Rights Reserved.</p>
      </div>
    </footer>
  )
}

export default Footer
