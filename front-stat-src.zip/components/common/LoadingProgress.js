import React from 'react'

import "assets/styles/loading.scss"

const LoadingProgress = ({mainTitle, subTitle}) => {

  return (
    <>
    <main id="page-deone" className="bg-1f1b2f">
      <section className="sec-01 pt-5 px-5">
        <div className="container-2 pt-5 mx-auto">
          <div className="card card-custom-3 py-5">
            <div className="row text-center py-5">
              <div className='loading mt-4 mb-2'>
                <div className='loading__square'></div>
                <div className='loading__square'></div>
                <div className='loading__square'></div>
                <div className='loading__square'></div>
                <div className='loading__square'></div>
                <div className='loading__square'></div>
                <div className='loading__square'></div>
              </div>
              <p className="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{mainTitle}</p>
              <p className="fs-16 fs-sm-18 fw-400 fc-9d8fed">{subTitle}</p>
            </div>
          </div>
        </div>
      </section>
    </main>
    </>
  )
}

export default LoadingProgress