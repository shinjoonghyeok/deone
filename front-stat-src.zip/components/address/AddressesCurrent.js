import React from 'react'
import { useTranslation } from 'react-i18next';

import { formatAmount, formatNoDecimals, formatDp, formatPercent } from "utils/format"
import add from "references/address"

const AddressesCurrent = () => {
  const { t } = useTranslation('address');

  return (
    <>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{t('govAlpha')}</span></dt>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{add.GOV_MULTISIG}</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{t('riskCoreUnit')}</span></dt>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{add.RISK_MULTISIG}</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{t('growthCoreUnit')}</span></dt>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{add.GRO_MULTISIG}</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-6 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{t('realWorldCoreUnit')}</span></dt>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{add.RWF_MULTISIG}</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-6 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{t('contentPriductionUnit')}</span></dt>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{add.CP_MULTISIG}</span></dd>
          </dl>
        </div>
    </div>
  </>
  )
}

export default AddressesCurrent
