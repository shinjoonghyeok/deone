import React from 'react'
import { useTranslation } from 'react-i18next';

import { formatAmount, formatNoDecimals, formatDp, formatPercent } from "utils/format"

const GuaranteeItem = ({item, debt}) => {
  const { t } = useTranslation('guarantee');

  const loanLimit = formatAmount.format(item.Art * item.rate); 
  const doneCount = formatAmount.format(item.line);
  const ilkNAme = item.ilk;
  const ethApercent = formatAmount.format(item.Art * item.rate / debt * 100);
  const loanLimit2 = formatAmount.format(item.lineMax);
  const guaranteeDifference = formatAmount.format(item.gap)
  const ttlTime = item.ttl / 60 / 60;
  const recentUpdateDate = item.lastInc;
  const usageRate = formatAmount.format(item.Art * item.rate / item.line * 100);
  const saftifyFeePercent = formatDp.format(item.locked)
  const interestDate = item.drip;
  const lowestLoan = formatAmount.format(item.dust);
  const savedPercent = formatPercent.format(item.locked / item.supply);
  const savedCount = formatAmount.format(item.value);

  const header1 = 
                <div className="row justify-content-center fs-14 fs-sm-16 fs-md-18 fw-400 mb-3">
                  <dd className="col-auto px-0"><span>{t('loan-limit')} : </span><span className="fc-9f79fa">{loanLimit}</span></dd>
                  <span className="col-auto mx-0">|</span>
                  <dd className="col-auto px-0"><span className="fc-ffffff">{t('done-count')} : </span><span className="fc-9f79fa">{doneCount}</span></dd>
                </div>
                
  const content1 = <dt className="mb-3"><span className="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{ ilkNAme }  ({ethApercent}%)</span></dt>

  const footer1 = <>
                    <dd className="mb-1"><span className="fs-12 fs-sm-14 fs-md-16">{t('loan-limit')} : {loanLimit2}</span></dd>
                    <dd className="mb-1"><span className="fs-12 fs-sm-14 fs-md-16">{t('guarantee-difference')} : {guaranteeDifference.toLocaleString()} | {t('ttl')} : {ttlTime}</span></dd>
                    <dd className="mb-1"><span className="fs-12 fs-sm-14 fs-md-16">{t('recent-update')} : {recentUpdateDate}</span></dd>
                    <dd className="mb-0"><span className="fs-12 fs-sm-14 fs-md-16">{t('usage-rate')} : {usageRate} %</span></dd>
                  </>

  const header2 = <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('saftify-fee')}</span></dt>
  const content2 = <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{saftifyFeePercent} %</span></dd>
  const footer2 = <>
                    <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16">{t('recent-interest-date')} : {interestDate}</span></dd>
                    <dd class="mb-0"><span class="fs-12 fs-sm-14 fs-md-16">{t('lowest-loan')} : {lowestLoan}</span></dd>
                  </>
  
  const header3 = <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('saved-amount')}</span></dt>
  const content3 = <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{savedCount}</span></dd>
  const footer3 = <dd class="mb-0"><span class="fs-12 fs-sm-14 fs-md-16">{t('saved-rate')} : {savedPercent} %</span></dd>

  return (
    <div class="card card-custom-3 mb-4">
      <div class="row">
        <dl class="col-12 col-lg-6 text-center mb-0">
          {header1}
          {content1}
          {footer1}
        </dl>
        <hr class="d-block d-lg-none my-4"></hr>
        <dl class="col-12 col-sm-6 col-lg-3 text-center mb-0">
          
          {header2}
          {content2}
          {footer2}
        </dl>
        <hr class="d-block d-lg-none my-4"></hr>
        <dl class="col-12 col-sm-6 col-lg-3 text-center mb-0">
          {header3}
          {content3}
          {footer3}
        </dl>
      </div>
    </div>
  )
}

export default GuaranteeItem
