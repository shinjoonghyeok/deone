import React from 'react'

import GuaranteeItem from "components/gurantee/GuaranteeItem"

const GuranteeCurrent = ({ilkList, debt}) => {
  const ilKViewItem = ilkList.map((item, index) => {
    return (<GuaranteeItem key={index} item={item} debt={debt} />)
  })

  return (
    <>
      {ilKViewItem}
    </>
  )
}

export default GuranteeCurrent