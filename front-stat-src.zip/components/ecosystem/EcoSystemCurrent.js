import React from 'react'
import { useTranslation } from 'react-i18next';

import { formatAmount, formatNoDecimals, formatDp, formatPercent } from "utils/format"

const EcoSystemCurrent = ({requestValue}) => {
  const { t } = useTranslation('ecosystem');
  
  
  return (
    <>
      <div class="col-12 col-md-6 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('gsmPauseDelay')}</span></dt>
            <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{requestValue.pauseDelay / 60 / 60} h</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-6 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('flashLoanLimit')}</span></dt>
            <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{formatPercent.format(requestValue.flashToll)}</span></dd>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{t('tillNextAuction')} : {formatAmount.format(requestValue.flashLine)}</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('DaiSupply')} ({formatAmount.format(requestValue.daiSupply / requestValue.debt * 100)}%)</span></dt>
            <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{formatAmount.format(requestValue.daiSupply)}</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('DaiInDsr')}({formatAmount.format(requestValue.savingsDai / requestValue.debt * 100)} %)</span></dt>
            <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{formatAmount.format(requestValue.savingsDai)}</span></dd>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">({t('pieInDsr')}: {formatAmount.format(requestValue.savingsPie)})</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3 h-100">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('daiSavingsRate')}</span></dt>
            <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{requestValue.potFee} %</span></dd>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{t('lastDrip')}: {requestValue.potDrip}</span></dd>
          </dl>
        </div>
      </div>
    </>
  )
}

export default EcoSystemCurrent
