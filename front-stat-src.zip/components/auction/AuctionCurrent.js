import React from 'react'
import { useTranslation } from 'react-i18next';
import { formatAmount } from "utils/format"

const AuctionCurrent = ({requestValue}) => {
  const { t } = useTranslation('auction');

  const nextFlap = () =>
    formatAmount.format(
      (Number(requestValue.surplusBuffer)
        + Number(requestValue.surplusBump))
      - Number(requestValue.sysSurplus)
    )

  return (
    <>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('left-DOne-Auction')}</span></dt>
            <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{formatAmount.format(requestValue.flapKicks)}</span></dd>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{t('tillNext-left-Auction')} : {nextFlap()}</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('opened-vault')}</span></dt>
            <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{requestValue.cdps}</span></dd>
          </dl>
        </div>
      </div>
      <div class="col-12 col-md-4 mb-3">
        <div class="card card-custom-3 py-3">
          <dl class="text-center mb-0">
            <dt class="mb-3"><span class="fs-14 fs-sm-16 fs-md-18 fw-400 fc-9f79fa">{t('supply-MCT')}</span></dt>
            <dd class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{formatAmount.format(requestValue.mkrSupply)}</span></dd>
            <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16 fw-400">{t('protocol-seed')} : {formatAmount.format(requestValue.protocolTreasury)} MCT</span></dd>
          </dl>
        </div>
      </div>
    </>
  )
}

export default AuctionCurrent
