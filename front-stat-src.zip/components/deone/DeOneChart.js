import ReactECharts from 'echarts-for-react';
import { useTranslation } from 'react-i18next';
import * as echarts from 'echarts';
import moment from 'moment'

const DeOneChart = ({historicalDebt}) => {
  const { t } = useTranslation('done');

  let daylist = historicalDebt.map(x => moment.unix(x.timestamp).format('YYYY-MM-DD'));
  let loanArray = historicalDebt.map(x => x.debtCeiling);
  let doneArray = historicalDebt.map(x => x.totalDebt);

  const options = {
    grid: { top: 8, right: 8, bottom: 24, left: 8 },
    xAxis: {
      type: 'category',
      data: daylist,
    },
    yAxis: {
      show: false
    },
    series: [
      {
        data: loanArray,
        type: 'line',
        symbol: 'none',
        itemStyle: {
          color: '#5596e7'
        },
        areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 0.8, [{
              offset: 0,
              color: '#855cea'
            }, {
                offset: 1,
                color: '#1f1b2f'
            }])
        },
        name: t('loan-limit')
      },

      {
        data: doneArray,
        type: 'line',
        symbol: 'none',
        itemStyle: {
          color: '#666666'
        },
        name: t('done-count')
      },
    ],
    tooltip: {
      trigger: 'axis',
      backgroundColor: "rgba(50,50,50,0.8)", //Set the background image rgba format
      color: "white",
      borderWidth: "1", //Border width setting 1
      borderColor: "gray", //Set the border color
      textStyle: {
        color: "white" //Set text color
      },
    },
  };

  return (
    <section class="sec-01 mb-5">
      <div class="container pb-2">
        <ReactECharts option={options} />
      </div>
    </section>
  )
}

export default DeOneChart
