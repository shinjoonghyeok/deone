import React from 'react'
import { useTranslation } from 'react-i18next';
import ReactECharts from 'echarts-for-react';
import * as echarts from 'echarts';

import SymbolImg from "assets/img/main_symbol.png"
import { formatAmount, formatPieChartOption, formatIlkSort } from "utils/format"

import DeOneImg from "assets/images/deone_02_2.png"

const DeOneSummary = ({sysLocked, ilks}) => {
  const { t } = useTranslation("done");

  const daiData = formatIlkSort(ilks, "value", 5);
  const genData = formatIlkSort(ilks, "Art", 5);

  const daiOption = formatPieChartOption(daiData, "Dai", "ilk", "value");
  const genOption = formatPieChartOption(genData, "Generate", "ilk", "Art");
 
  return (
    <section className="sec-02">
      <div className="container">
        <div className="row">
          <div className="col-12 col-md-6 mb-3 mb-md-0">
            <div className="card card-custom-3 text-center h-100">
              <div className="my-auto">
                <div className="mb-3">
                  <img src={DeOneImg} alt="DeOne" />
                </div>
                <dl className="fs-20 fs-sm-24 fw-400">
                  <dt><span className="fw-400 fc-ffffff">{t('total-saving-amount')}</span></dt>
                  <dd className="fc-9d8fed"><span className="fw-700">{formatAmount.format(sysLocked)}</span> <span>{t('money-unit')}</span></dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6">
              <div className="card card-custom-3 text-center h-100">
                {/* <div id="chart_pie" className="my-auto py-5"></div> */}
                <ReactECharts option={genOption} />
                <p className="text-white text-lg font-medium">{t('guarantee-status')}</p>
              </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default DeOneSummary
