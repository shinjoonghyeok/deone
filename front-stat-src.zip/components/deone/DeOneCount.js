import React from 'react'
import { useTranslation } from 'react-i18next';

import { formatAmount } from "utils/format"

const DeOneCount = ({loanLimit, doneCount}) => {
  const { t } = useTranslation('done');

  loanLimit = formatAmount.format(loanLimit)
  doneCount = formatAmount.format(doneCount)

  return (
    <section class="sec-01 mb-1">
      <div class="container pt-4 pb-2">
        <h1 class="row justify-content-center text-center fs-20 fs-sm-24 fw-700 py-5">
          <div class="col-12 col-md-auto mb-3 mb-md-0">
            <span class="fw-500 fc-999999">{ t('loan-limit') } : </span><span class="fc-9d8fed">{loanLimit}</span>
          </div>
          <span class="col-auto d-none d-md-block mx-0 px-0">|</span>
          <div class="col-12 col-md-auto">
            <span class="fw-500 fc-ffffff">{ t('done-count') } : </span><span class="fc-9d8fed">{doneCount}</span>
          </div>
        </h1>
      </div>
    </section>
  )
}

export default DeOneCount
