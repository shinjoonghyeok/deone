import React from 'react'

import OracleItem from "components/oracle/OracleItem"

const OracleCurrent = ({ilkList, debt}) => {
  const ilKViewItem = ilkList.map((item, index) => {
    return (<OracleItem key={index} item={item} debt={debt} />)
  })

  return (
    <>
      {ilKViewItem}
    </>
  )
}

export default OracleCurrent