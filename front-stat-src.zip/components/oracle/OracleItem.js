import React from 'react'
import { useTranslation } from 'react-i18next';

import { formatAmount, formatNoDecimals, formatDp, formatPercent } from "utils/format"

const OracleItem = ({item, debt}) => {
  const { t } = useTranslation('oracle');
  
  let currentPrice = parseFloat(item.price).toFixed(2);
  let priceNext = parseFloat(item.priceNxt).toFixed(2);
  
  return (
    <div class="col-12 col-sm-12 col-md-4 col-lg-4">
      <div class="card card-custom-3 py-3 mb-4">
        <dl class="text-center mb-0">
          <dd class="fs-14 fs-sm-16 fs-md-18"><span class="fc-ffffff">{t('nowPrice')} : </span><span class="fc-9f79fa">{currentPrice} {t('unit')}</span></dd>
          <dt class="mb-3"><span class="fs-22 fs-sm-24 fs-md-26 fs-lg-28 fw-700 fc-ffffff">{item.token}</span></dt>
          <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16">{t('predic-priceOfDiffer')} : {priceNext}원</span></dd>
          <dd class="mb-1"><span class="fs-12 fs-sm-14 fs-md-16">{t('next-update')} : {item.zzz}</span></dd>
        </dl>
      </div>
    </div>
  )
}

export default OracleItem
