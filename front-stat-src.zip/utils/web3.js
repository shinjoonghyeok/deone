// const ethers = require('ethers')
import * as ethers from 'ethers' 
window.ethers = ethers
const eth = new ethers.providers.InfuraProvider()
export default eth
