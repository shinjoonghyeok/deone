export const formatAmount = new Intl.NumberFormat('en-US', {
  style: 'decimal',
  minimumFractionDigits: 0,
  maximumFractionDigits: 2
})

export const formatForWBTC = new Intl.NumberFormat('en-US', {
  style: 'decimal',
  minimumFractionDigits: 0,
  maximumFractionDigits: 4
})

export const formatNoDecimals = new Intl.NumberFormat('en-US', {
  style: 'decimal',
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
})

export const formatDp = new Intl.NumberFormat('en-US', {
  style: 'decimal',
  minimumFractionDigits: 8,
  maximumFractionDigits: 8
})

export const formatCurrency = new Intl.NumberFormat('en-US', {
  style: 'decimal',
  minimumFractionDigits: 2,
  maximumFractionDigits: 4
})

export const formatTwoDp = new Intl.NumberFormat('en-US', {
  style: 'decimal',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
})

export const formatPercent = new Intl.NumberFormat('en-US', {
  style: 'percent',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
})

export const formatPercentFee = new Intl.NumberFormat('en-US', {
  style: 'percent',
  minimumFractionDigits: 2,
  maximumFractionDigits: 4
})

export const formatFiveDp = new Intl.NumberFormat('en-US', {
  style: 'decimal',
  minimumFractionDigits: 5,
  maximumFractionDigits: 5
})

export const formatEightDp = new Intl.NumberFormat('en-US', {
  style: 'decimal',
  minimumFractionDigits: 8,
  maximumFractionDigits: 8
})


export const formatPieChartOption = (data, title, nameField, valueField) => {
  const chartData = data.map(item => {
    return {
      name: item[nameField],
      value: item[valueField]
    }
  })
  const option = {
    tooltip: {
      trigger: 'item',
      backgroundColor: "rgba(50,50,50,0.8)", 
      color: "white",
      borderWidth: "1",
      borderColor: "gray",
      textStyle: {
        color: "white"
      },
    },
    color: [
      '#41B787',
      '#6352B9',
      '#B65480',
      '#D5735A',
      '#D7D9DA'
    ],
    animation: "auto",
    animationDetaion: 2000,
    series: [
      {
        name: title,
        type: 'pie',
        radius: ['50%', '80%'],
        data: chartData,
        itemStyle : {
          normal : {
            label : {
              show: true, 
              color: "white",
              fontWeight : 'bold',
              formatter : function (params){
                return  params.name
              },
            },
          },
          emphasis : {
            label : {
              show : true,
              textStyle : {
                fontSize : '20',
                fontWeight : 'bold'
              }
            }
          }
        },
      },
    ],
  };

  return option;
  
}

export const formatIlkSort = (arrObj, key, num) => {
  let sortNum = arrObj.sort( (a, b) => {
    return Number(b[key]) - Number(a[key]);
  })

  return sortNum.slice(0, num);
}