import React, {useContext} from 'react'
import { useHistory } from "react-router-dom";
import AddressesCurrent from "components/address/AddressesCurrent";

import { WatchDeOneState } from "layouts/WatchLayout"

const Address = () => {
  const { requestValue } = useContext(WatchDeOneState);
  let history = useHistory();

  if(requestValue.blockNumber===null) {
    history.push("/")
    history.go()
  }
  
  return (
    <>
      <main id="page-deone" class="min-vh-100 bg-1f1b2f">
        <section class="sec-01 py-5">
          <div class="container py-3">
            <div class="row">
              <AddressesCurrent />
            </div>
          </div>
        </section>
      </main>
    </>
  )
}

export default Address