import React, {useContext} from 'react'
import { useHistory } from "react-router-dom";

import { WatchDeOneState } from "layouts/WatchLayout"

import DeOneCount from "components/deone/DeOneCount"
import DeOneChart from "components/deone/DeOneChart"
import DeOneSummary from "components/deone/DeOneSummary"

const DeOneStatus = () => {
  const { requestValue } = useContext(WatchDeOneState);
  let history = useHistory();

  if(requestValue.blockNumber===null) {
    history.push("/")
    history.go()
  }

  return (
    <main id="page-deone-index" class="min-vh-100 bg-1f1b2f">
      <DeOneCount loanLimit={requestValue.debt} doneCount={requestValue.Line} />
      <DeOneChart historicalDebt={requestValue.historicalDebt} />
      <DeOneSummary sysLocked={requestValue.sysLocked} ilks={requestValue.ilks} />
    </main>
  )
}

export default DeOneStatus
