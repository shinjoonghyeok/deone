import React, {useContext} from 'react'
import { useHistory } from "react-router-dom";
import AuctionCurrent from "components/auction/AuctionCurrent";

import { WatchDeOneState } from "layouts/WatchLayout"

const Auction = () => {
  const { requestValue } = useContext(WatchDeOneState);
  let history = useHistory();

  console.log(requestValue);

  if(requestValue.blockNumber===null) {
    history.push("/")
    history.go()
  }
  
  return (
    <>
      <main id="page-deone" class="min-vh-100 bg-1f1b2f">
        <section class="sec-01 py-5">
          <div class="container py-3">
            <div class="row">
              <AuctionCurrent requestValue={requestValue} />
            </div>
          </div>
        </section>
      </main>
    </>
  )
}

export default Auction