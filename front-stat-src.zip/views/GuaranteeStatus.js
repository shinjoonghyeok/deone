import React, {useContext} from 'react'
import { useHistory } from "react-router-dom";
import GuranteeCurrent from "components/gurantee/GuranteeCurrent";

import { WatchDeOneState } from "layouts/WatchLayout"

const GuaranteeStatus = () => {
  const { requestValue } = useContext(WatchDeOneState);
  let history = useHistory();

  if(requestValue.blockNumber===null) {
    history.push("/")
    history.go()
  }
  
  return (
    <>
      <main id="page-deone" class="min-vh-100 bg-1f1b2f">
        <section class="sec-01 py-5">
          <div class="container py-3">
            <GuranteeCurrent ilkList={requestValue.ilks} debt={requestValue.debt} />
          </div>
        </section>
      </main>
    </>
  )
}

export default GuaranteeStatus