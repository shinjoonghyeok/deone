import React, {useReducer} from 'react'

export const WatchDeOneState = React.createContext();

const initSettingValue = {
  blockNumber: null,
  paused: false
}

const reducer = (state, action) => {
  switch (action.type) {
    case 'SETTING':
      return {
        ...state,
        ...action.value
      }
    default:
      return state
  }
}



const WatchLayout = ({children}) => {
  const [state, watchDispatch] = useReducer(reducer, initSettingValue);
  return (
    <React.Fragment>
      <WatchDeOneState.Provider value={{ requestValue: state, watchDispatch }}>
        { children }
      </WatchDeOneState.Provider>
    </React.Fragment>
  )
}

export default WatchLayout