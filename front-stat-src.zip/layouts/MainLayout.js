import React from 'react'
import { useLocation } from "react-router-dom";

import Navbar from "components/common/NavBar"
import Footer from "components/common/Footer"

const MainLayout = ( {children} ) => {
  const location = useLocation();

  console.log(location)
  if(location.pathname == "/") {
    return (
      <React.Fragment>
        {children}
        <Footer />
      </React.Fragment>
    )
  }
  else {
    return (
      <React.Fragment>
        <Navbar />
        {children}
        <Footer />
      </React.Fragment>
    )
  }
  
}

export default MainLayout