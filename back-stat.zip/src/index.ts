import app from "./app";
import {createServer} from "http";

const port: number = Number(process.env.SERVICE_PORT) || 3001;

const server = createServer(app);

server.listen(port, async () => {
    console.log(`Server Listening on ${port}`);
});

export default server;