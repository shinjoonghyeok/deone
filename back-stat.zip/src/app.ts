import * as dotenv from "dotenv";
import express from "express";
import bodyParser from 'body-parser';
import session from 'express-session';
import cors from "cors";
import path from 'path';

import indexRouter from "./routes/index";

dotenv.config();

const app: express.Application = express();

app.use(require('connect-history-api-fallback')());

app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());
app.use(express.json());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended : false }));
app.use(session({
    secret:`@#@$ANSWER#@$#$`,
    resave: false,
    saveUninitialized: true 
}));

app.use("/", indexRouter);

app.get('*', function(req, res){
    if (req.accepts('html')) {
        res.json({ error: 'Not found' });
        return;
    }
    if (req.accepts('json')) {
        res.json({ error: 'Not found' });
        return;
    }
    res.type('txt').send('Not found');
});

export default app;
