import {Request, Response, NextFunction } from "express";
import sequelize from "sequelize";
import bcrypt from "bcrypt";

import { makeAccessToken, makeRefreshToken } from "../middleware/auth"

const saltRounds = 10;
const salt = bcrypt.genSaltSync(saltRounds);

export default class userController {
    static indexPage(req: Request, res: Response, next: NextFunction) {
        res.send("User Success");
    }

    static errorPage(req: Request, res: Response, next: NextFunction) {
        res.send("User Error");
    }
}