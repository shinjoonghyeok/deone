import {Request, Response, NextFunction } from "express";
import { v4 as uuidv4 } from 'uuid';

import { connectDB } from '../common/utils';

export default class apiController {
    static indexPage(req: Request, res: Response, next: NextFunction) {
        res.send("Api Success");
    }

    static errorPage(req: Request, res: Response, next: NextFunction) {
        res.send("Api Error");
    }

    static getNotice(req: Request, res: Response, next: NextFunction) {
        let listArray:any = []
        connectDB.all("SELECT * FROM deone_notice ORDER BY seq DESC", function(err, rows) {
            listArray = rows;
            res.send(listArray)
        })
    }

    static insertNotice(req: Request, res: Response, next: NextFunction) {
        connectDB.run("INSERT INTO deone_notice (notice_title, notice_language, notice_content, notice_insert_date) values (?, ?, ?, CURRENT_TIMESTAMP)", ['test','ko','test'])
        res.send("success")
    }

    static updateNotice(req: Request, res: Response, next: NextFunction) {
        let seq = 1;
        let content = "retest"
        connectDB.run("UPDATE deone_notice SET notice_content = ? WHERE seq = ?", [content, seq], (err:any, result:any) => {
            if(err != null) res.send("success");
            else res.send("error")
        })
        res.send("success")
    }

    static removeNotice(req: Request, res: Response, next: NextFunction) {
        let seq = 2;
        connectDB.run("DELETE FROME deone_notice WHERE seq = ?", [seq], (err:any, result:any) => {
            if(err != null) res.send("success");
            else res.send("error")
        });
    }

    static selectNotice(req: Request, res: Response, next: NextFunction) {
        let seq = 1;
        let item = {}
        connectDB.get("SELECT * FROM deone_notice WHERE seq = ?", [seq], (err:any, row:any) => {
            item = row;
            res.send(row);
        })
    }
}