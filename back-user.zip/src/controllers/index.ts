import {Request, Response, NextFunction } from "express";

export default class indexControl {
    static indexPage(req: Request, res: Response, next: NextFunction) {
        res.send("Answer Success");
    }

    static errorPage(req: Request, res: Response, next: NextFunction) {
        res.send("Answer Error");
    }
}