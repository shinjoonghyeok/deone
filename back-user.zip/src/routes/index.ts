import express from "express";
import path from "path";

const router = express.Router();

import indexController from "../controllers/index";

router.get('/', function(req, res, next) {
  res.sendFile(path.join(__dirname, '../public','index.html'))
});
router.get("/error", indexController.errorPage)

export = router;
