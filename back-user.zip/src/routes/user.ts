import express from "express";
const router = express.Router();

import userController from "../controllers/user";
import { checkAuthToken } from "../middleware/auth"

router.get("/", userController.indexPage);
router.post("/", userController.indexPage);

router.get("/error", userController.errorPage)

export = router;