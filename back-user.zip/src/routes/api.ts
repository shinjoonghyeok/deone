import express from "express";
const router = express.Router();

import apiController from "../controllers/api";
import { checkAuthToken } from "../middleware/auth"

router.get("/", apiController.indexPage);
router.post("/", apiController.indexPage);

router.post("/listNotice", apiController.getNotice);
router.post("/writeNotice", apiController.insertNotice);
router.post("/modifyNotice", apiController.updateNotice);
router.post("/deleteNotice", apiController.removeNotice);
router.post("/detailNotice", apiController.selectNotice);

router.get("/error", apiController.errorPage)

export = router;