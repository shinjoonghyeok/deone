import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { Tedis } from "tedis";

import { connectDB } from '../common/utils';

const magicKey = process.env.MAGICKEY || 'magic_key';
const expiresIn = 60 * 60 * 24 * 365;

const saltRounds = 10;
const salt = bcrypt.genSaltSync(saltRounds);

const tedis = new Tedis({
    port: Number(process.env.REDIS_PORT) || 6379,
    host: process.env.REDIS_HOST || "127.0.0.1",
    password: process.env.REDIS_PASSWORD || "password"
});

const verifyKey = (token: string) => {
    try {
        // let verifyJWT = jwt.verify(token.replace(/^Bearer\s/, ''), magicKey)
        let verifyJWT: any = jwt.verify(token, magicKey)
        return {
            code: 200,
            msg: "success"
        };
    }
    catch(err) {
        if (err.name == 'TokenExpiredError') {
            return {
                code: 419,
                msg: "expire"
            }
        }
        else {
            return {
                code: 403,
                msg: "invalid"
            };
        }
    }
}

export const checkAuthToken = (req: Request, res: Response, next: NextFunction) => {
    const { accesstoken } = req.headers;
    console.log(accesstoken);
    if(accesstoken == undefined) {
        console.log("no token");
        res.status(400);
        return res.send("no token");
    }
    else {
        let checkToken:any = verifyKey(accesstoken.toString());
        if(checkToken.code==200) {
            next();
        }
        else {
            res.status(checkToken.code);
            return res.send(checkToken.msg);
        }
    }
}

export const makeAccessToken = (id: string) => {
    return jwt.sign({id}, magicKey, {expiresIn})
}

export const makeRefreshToken = async (id: string) => {
    let refreshToken = bcrypt.hashSync(id, salt);
    await tedis.command("SET", id, refreshToken);

    // let query = `insert into person(user_name, user_password) values ('${id}', '${refreshToken}')`
    // connectDB.serialize();
    // connectDB.each(query);

    // let select = `SELECT * FROM person  limit 3 offset 0`;
    // connectDB.serialize();
    // connectDB.all(select, (err, row) => {
    //     console.log('show', {data : row});
    // });

    return refreshToken;
}
