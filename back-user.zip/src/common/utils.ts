import sqlite3 from 'sqlite3';


export const createNotice = `CREATE TABLE IF NOT EXISTS deone_notice (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    notice_title VARCHAR(100),
    notice_language VARCHAR(2),
    notice_content TEXT,
    notice_insert_date DATETIME
)`;

export const createGovernance = `CREATE TABLE IF NOT EXISTS deone_governance (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    gov_address VARCHAR(100),
    gov_title TEXT,
    gov_content TEXT,
    gov_review TEXT,
    notice_insert_date DATETIME
)`


export const connectDB = new sqlite3.Database('./dist/db/db.db', sqlite3.OPEN_READWRITE, (err) => {
    if (err) {
        console.error(err.message);
    } else {
        console.log('Connected to the mydb database.');
    }
});