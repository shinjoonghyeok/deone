import * as dotenv from "dotenv";
import express from "express";
import bodyParser from 'body-parser';
import session from 'express-session';
import createError from "http-errors";
import cors from "cors";
import path from 'path';
import swaggerUi from 'swagger-ui-express';
import YAML from 'yamljs';

import { connectDB, createNotice, createGovernance } from './common/utils';

import indexRouter from "./routes/index";
import apiRouter from "./routes/api";
import userRouter from "./routes/user";

dotenv.config();

const app: express.Application = express();

app.use(require('connect-history-api-fallback')());

app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());
app.use(express.json());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended : false }));
app.use(session({
    secret:`@#@$ANSWER#@$#$`,
    resave: false,
    saveUninitialized: true 
}));

// swagger dev mode 일때만 동작 한다.
if(process.env.SERVICE_MODE=="dev") {
    const swaggerSpec = YAML.load(path.join(__dirname, '../dist/swagger.yaml'))
    app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec))
}


connectDB.serialize(() => {
    connectDB.each(createNotice);
    connectDB.each(createGovernance);
});

// connectDB.close((err) => {
//     if (err) {
//         console.error(err.message);
//     } else {
//         console.log('Close the database connection.');
//     }
// });

app.use("/", indexRouter);
app.use("/api", apiRouter);
app.use("/user", userRouter);

app.get('*', function(req, res){
    if (req.accepts('html')) {
        res.json({ error: 'Not found' });
        return;
    }
    if (req.accepts('json')) {
        res.json({ error: 'Not found' });
        return;
    }
    res.type('txt').send('Not found');
});

export default app;
