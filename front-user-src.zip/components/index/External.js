import React from 'react'
import { useTranslation } from 'react-i18next';

import ExternalImg1 from 'assets/images/main_ban_4_1.png';
import ExternalImg2 from 'assets/images/main_ban_4_2.png';
import ExternalImg3 from 'assets/images/main_ban_4_3.png';
import ExternalImg4 from 'assets/images/main_ban_4_4.png';
import ExternalImg5 from 'assets/images/main_ban_4_5.png';
import ExternalImg6 from 'assets/images/main_ban_4_6.png';
import ExternalImg7 from 'assets/images/main_ban_4_7.png';
import ExternalImg8 from 'assets/images/main_ban_4_8.png';

const External = () => {
  const { t } = useTranslation('main');

  return (
    <section className="sec-05 py-4 py-sm-5">
      <div className="container py-4 py-sm-5">
        <div className="text-center mb-4 mb-sm-5">
          <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-1">{ t('external.done-external') }</h1>
          <p className="fs-16 fs-sm-18 fw-400">{ t('external.done-external-sub') }</p>
        </div>
        <ul className="row text-center justify-content-between">
          <li className="px-5 px-sm-3 col-6 col-sm-3 col-lg-auto mb-3"><img src={ExternalImg1} alt="ex1" /></li>
          <li className="px-5 px-sm-3 col-6 col-sm-3 col-lg-auto mb-3"><img src={ExternalImg2} alt="ex2" /></li>
          <li className="px-5 px-sm-3 col-6 col-sm-3 col-lg-auto mb-3"><img src={ExternalImg3} alt="ex3" /></li>
          <li className="px-5 px-sm-3 col-6 col-sm-3 col-lg-auto mb-3"><img src={ExternalImg4} alt="ex4" /></li>
          <li className="px-5 px-sm-3 col-6 col-sm-3 col-lg-auto mb-3"><img src={ExternalImg5} alt="ex5" /></li>
          <li className="px-5 px-sm-3 col-6 col-sm-3 col-lg-auto mb-3 ms-lg-auto"><img src={ExternalImg6} alt="ex6" /></li>
          <li className="px-5 px-sm-3 col-6 col-sm-3 col-lg-auto mb-3 mx-lg-5"><img src={ExternalImg7} alt="ex7" /></li>
          <li className="px-5 px-sm-3 col-6 col-sm-3 col-lg-auto mb-3 me-lg-auto"><img src={ExternalImg8} alt="ex8" /></li>
        </ul>
      </div>
    </section>
  )
}

export default External
