import React from 'react'
import { useTranslation } from 'react-i18next';

import SupportMainImg1 from "assets/images/main_ban_2_1.png"
import SupportMainImg2 from "assets/images/main_ban_2_2.png"

const Support = () => {
  const { t } = useTranslation('main');

  return (
    <section className="sec-03 py-4 py-sm-5 bg-fbfaff">
      <div className="container py-4 py-sm-5">
        <div className="text-center mb-4 mb-sm-5">
          <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-1">{ t('support.done-support') }</h1>
          <p className="fs-16 fs-sm-18 fw-400">{ t('support.done-support-sub') }</p>
        </div>
        <ul className="row text-center">
          <li className="col-12 col-md-6 mb-4 mb-md-0">
            <div className="col-8 col-md-12 mx-auto"><img src={SupportMainImg1} alt="support1" /></div>
            <h2 className="fs-20 fs-sm-22 fs-md-24 fw-700 mt-3 mt-sm-4 mb-2 mb-sm-3">{ t('support.support-bb-title') }</h2>
            <div className="fs-14 fs-sm-16 mb-3 mb-sm-4">
              <div dangerouslySetInnerHTML={{__html: t('support.support-bb-content')}} />
            </div>
            <button className="btn btn-primary btn-outline"><span className="text">{ t('btn.make-bb-wallet') }</span></button>
          </li>
          <li className="col-12 col-md-6 mt-4 mt-md-0">
            <div className="col-8 col-md-12 mx-auto"><img src={SupportMainImg2} alt="support2" /></div>
            <h2 className="fs-20 fs-sm-22 fs-md-24 fw-700 mt-3 mt-sm-4 mb-2 mb-sm-3">{ t('support.support-bs-title') }</h2>
            <div className="fs-14 fs-sm-16 mb-3 mb-sm-4">
              <div dangerouslySetInnerHTML={{__html: t('support.support-bs-content')}} />
            </div>
            <button className="btn btn-primary btn-outline"><span className="text">{ t('btn.goto-bs') }</span></button>
          </li>
        </ul>
      </div>
    </section>
  )
}

export default Support
