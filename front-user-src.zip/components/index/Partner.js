import React from 'react'
import { useTranslation } from 'react-i18next';

import PartnerImg1 from 'assets/images/main_ban_3_1.png'
import PartnerImg2 from 'assets/images/main_ban_3_2.png'
import PartnerImg3 from 'assets/images/main_ban_3_3.png'
import PartnerImg4 from 'assets/images/main_ban_3_4.png'
import PartnerImg5 from 'assets/images/main_ban_3_5.png'
import PartnerImg6 from 'assets/images/main_ban_3_6.png'

const Partner = () => {
  const { t } = useTranslation('main');

  return (
    <section className="sec-04 py-4 py-sm-5">
      <div className="container py-4 py-sm-5">
        <div className="text-center mb-4 mb-sm-5">
          <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-1">{ t('partner.done-partner') }</h1>
          <p className="fs-16 fs-sm-18 fw-400">{ t('partner.done-partner-sub') }</p>
        </div>
        <ul className="row">
          <li className="col-6 col-sm-4 col-md-3 col-lg-2 p-2">
            <div className="border text-center">
              <img src={PartnerImg1} alt="partner1" />
            </div>
          </li>
          <li className="col-6 col-sm-4 col-md-3 col-lg-2 p-2">
            <div className="border text-center">
              <img src={PartnerImg2} alt="partner2" />
            </div>
          </li>
          <li className="col-6 col-sm-4 col-md-3 col-lg-2 p-2">
            <div className="border text-center">
              <img src={PartnerImg3} alt="partner3" />
            </div>
          </li>
          <li className="col-6 col-sm-4 col-md-3 col-lg-2 p-2">
            <div className="border text-center">
              <img src={PartnerImg4} alt="partner4" />
            </div>
          </li>
          <li className="col-6 col-sm-4 col-md-3 col-lg-2 p-2">
            <div className="border text-center">
              <img src={PartnerImg5} alt="partner5" />
            </div>
          </li>
          <li className="col-6 col-sm-4 col-md-3 col-lg-2 p-2">
            <div className="border text-center">
              <img src={PartnerImg6} alt="partner6" />
            </div>
          </li>
        </ul>
      </div>
    </section>
  )
}

export default Partner
