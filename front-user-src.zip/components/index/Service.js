import React from 'react'
import { NavLink } from "react-router-dom";
import { useTranslation } from 'react-i18next';

import ServiceBanner1 from "assets/images/main_ban_1_1.png"
import ServiceBanner2 from "assets/images/main_ban_1_2.png"
import ServiceBanner3 from "assets/images/main_ban_1_3.png"
import ServiceBanner4 from "assets/images/main_ban_1_4.png"

import ServiceArrowRight from "assets/images/right-chevron.png"

const Service = () => {
  const { t } = useTranslation('main');

  return (
    <section className="sec-02 container py-4 py-sm-5">
      <div className="container py-4 py-sm-5">
        <div className="text-center mb-4 mb-sm-5">
          <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-1">{ t('service.done-service') }</h1>
          <p className="fs-16 fs-sm-18 fw-400">{ t('service.done-service-sub') }</p>
        </div>
        <ul className="row text-center">
          <li className="col-12 col-sm-6 col-lg-3 mb-4 mb-lg-0">
            <img src={ServiceBanner1} alt="service1" />
            <h2 className="fs-20 fs-sm-22 fs-md-24 fw-700 my-2 my-sm-3">{ t('service.intro-done') }</h2>
            <div className="fs-16 mb-3 mb-sm-4">
              <div dangerouslySetInnerHTML={{__html: t('service.intro-done-content')}} />
            </div>
            <NavLink
              to="/deOneIntro"
              className="fs-16 fc-855cea link-hover"
            >
              <span>{ t('btn.goto') }</span>
              <img className="chevron" src={ServiceArrowRight} alt="sr" />
            </NavLink>
          </li>
          <li className="col-12 col-sm-6 col-lg-3 mb-4 mb-lg-0">
            <img src={ServiceBanner2} alt="service2" />
            <h2 className="fs-20 fs-sm-22 fs-md-24 fw-700 my-2 my-sm-3">{ t('service.loan-prod') }</h2>
            <div className="fs-16 mb-3 mb-sm-4">
              <div dangerouslySetInnerHTML={{__html: t('service.loan-prod-content')}} />
            </div>
            <NavLink
              to="/loanProd"
              className="fs-16 fc-855cea link-hover"
            >
              <span>{ t('btn.goto') }</span>
              <img className="chevron" src={ServiceArrowRight} alt="sr" />
            </NavLink>
          </li>
          <li className="col-12 col-sm-6 col-lg-3 mb-4 mb-sm-0">
            <img src={ServiceBanner3} alt="service3" />
            <h2 className="fs-20 fs-sm-22 fs-md-24 fw-700 my-2 my-sm-3">{ t('service.saving-prod') }</h2>
            <div className="fs-16 mb-3 mb-sm-4">
              <div dangerouslySetInnerHTML={{__html: t('service.saving-prod-content')}} />
            </div>
            <NavLink
              to="/savingProd"
              className="fs-16 fc-855cea link-hover"
            >
              <span>{ t('btn.goto') }</span>
              <img className="chevron" src={ServiceArrowRight} alt="sr" />
            </NavLink>
          </li>
          <li className="col-12 col-sm-6 col-lg-3 mb-4 mb-sm-0">
            <img src={ServiceBanner4} alt="service4" />
            <h2 className="fs-20 fs-sm-22 fs-md-24 fw-700 my-2 my-sm-3">{ t('service.governance') }</h2>
            <div className="fs-16 mb-3 mb-sm-4">
              <div dangerouslySetInnerHTML={{__html: t('service.governance-content')}} />
            </div>
            <NavLink
              to="/governance"
              className="fs-16 fc-855cea link-hover"
            >
              <span>{ t('btn.goto') }</span>
              <img className="chevron" src={ServiceArrowRight} alt="sr" />
            </NavLink>
          </li>
        </ul>
      </div>
    </section>
  )
}

export default Service
