import React from 'react'
import Modal from 'react-modal';
import { useTranslation } from 'react-i18next';
import { useHistory } from "react-router-dom";

import DeOneSymbol from "assets/images/main_vis_1.png"
import DeOneYoutub from "components/common/DeOneYoutub"
import { deoneVideoID } from "references/config"

const Intro = () => {
  const { t } = useTranslation('main');
  let history = useHistory();

  const [modalIsOpen, setIsOpen] = React.useState(false);

  const customStyles = {
    content: {
      top: '50%',
      left: '50%',
      right: 'auto',
      bottom: 'auto',
      marginRight: '-50%',
      transform: 'translate(-50%, -50%)',
    },
  };

  function openModal() {
    console.log("Open")
    setIsOpen(true);
  }

  function afterOpenModal() {
    console.log("After")
  }

  function closeModal() {
    console.log("Close")
    setIsOpen(false);
  }

  return (
    <section className="sec-01 bg-gradient-custom">
      <div className="container py-4 py-sm-5">
        <div className="row position-relative text-center text-md-start">
          <div className="col-12 col-md-6 py-4 py-sm-5">
            <div className="mb-5">
              <h1 className="fs-30 fs-sm-36 fs-md-42 fs-lg-48 fw-700 mb-4">
                <div dangerouslySetInnerHTML={{__html: t('intro.done-title')}} />
              </h1>
              <div className="fs-18 fw-400 mb-4">
                <div dangerouslySetInnerHTML={{__html: t('intro.done-content')}} />
              </div>
              <button className="btn btn-primary" onClick={() => {history.push("/loanProd")}}>
                <span className="text">{ t('btn.deploy-done') }</span>
              </button>
            </div>
            <div>
              <h1 className="fs-30 fs-sm-36 fs-md-42 fs-lg-48 fw-700 mb-4">
              <div dangerouslySetInnerHTML={{__html: t('intro.done-subtitle')}} />
              </h1>
              <div className="fs-18 fw-400 mb-4">
                <div dangerouslySetInnerHTML={{__html: t('intro.done-subcontent')}} />
              </div>
              <button className="btn btn-primary btn-outline" onClick={openModal}>
                <span className="text"><i className="fas fa-play mr-1"></i> { t('btn.movie-done') }</span>
              </button>
            </div>
          </div>
          <div className="col-8 col-md-6 my-5 my-md-0 mx-auto order-first order-md-last text-center text-md-end">
            <img src={DeOneSymbol} alt="DeOne" />
          </div>
        </div>
      </div>

      <Modal
        isOpen={modalIsOpen}
        onAfterOpen={afterOpenModal}
        onRequestClose={closeModal}
        style={customStyles}
        contentLabel="DONE"
        ariaHideApp={false}
      >
        <DeOneYoutub videoID={deoneVideoID} />
      </Modal>
    </section>
  )
}

export default Intro
