import React, {useState, useContext} from 'react'
import { useTranslation } from "react-i18next";

import { DeOneProductList}  from "layouts/ProductLayout"
import { LoanRequestInfo } from "layouts/LoanRequestLayout"

import DeOneImg from "assets/images/loan_2_0.png"

const LoanRequestDeOne = () => {
  const { t } = useTranslation('loan');
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);
  const [inputDone, setInputDone] = useState(0);

  let readonly = true;
  if(loanRequestValue.nowStatus === "ready" || loanRequestValue.nowStatus === "startGen") readonly = false;

  const changeInputDone = async (e) => {
    setInputDone(e.target.value)
    loanRequestDispatch({"type":"LOAN", "value":Number(e.target.value)})
  }

  return (
    <>
      <dl>
        <dt className="col-auto fs-16 fs-sm-18 fw-400 mb-2">{t('loan-request.loan-amount')}</dt>
        <dd className="input-group mb-3">
          <input type="number" className="form-control form-custom-1 fs-sm-24" placeholder="" aria-label="" value={inputDone} onChange={changeInputDone} readOnly={readonly} />
          <span className="input-group-text form-label-custom-1">
            <img className="me-1" src={DeOneImg} alt="DeOne" />
            <span className="d-inline-block my-auto fs-16 fs-sm-18 fw-400">DeONE</span>
          </span>
        </dd>
      </dl>
    </>
  )
}

export default LoanRequestDeOne
