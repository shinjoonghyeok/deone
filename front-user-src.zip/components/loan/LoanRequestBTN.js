import React, {useState, useContext} from 'react'
import { useTranslation } from "react-i18next";

import { DeOneProductList}  from "layouts/ProductLayout"
import { LoanRequestInfo } from "layouts/LoanRequestLayout"

import useMaker from "hooks/useMaker"

const LoanRequestBTN = ({productKey}) => {
  const { t } = useTranslation('loan');
  const { productValue, productDispatch } = useContext(DeOneProductList);
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);

  const { gemsToLock, daiToDraw } = loanRequestValue.transactionFee;

  let selectedProduct = productValue.productList.find(x => x.key === productKey);

  const { maker } = useMaker();

  const requestLoanStart = () => {
    loanRequestDispatch({"type":"STATUS", "value":"start"});
  }

  const requestTransaction = async () => {
    const txObject = maker
      .service('mcd:cdpManager')
      .openLockAndDraw(
        selectedProduct.symbol,
        selectedProduct.currency(gemsToLock),
        daiToDraw
      );

    const txMgr = maker.service('transactionManager');
    txMgr.listen(txObject, {
      pending: tx => {
        loanRequestDispatch({"type":"STATUS", "value":"transaction"});
        console.log("pending", tx)
      }, 
      mined: tx => {
        loanRequestDispatch({"type":"STATUS", "value":"finish"});
        console.log("minted", tx)
      },
      confirmed: () => {
        console.log("confirmed")
      },
      error: () => {
        loanRequestDispatch({"type":"STATUS", "value":"ready"})
        console.log("ERROR")
      }

    });
    await txMgr.confirm(txObject, 1);
  }

  if(loanRequestValue.isLoanActive) {
    if(loanRequestValue.nowStatus==="ready") {
      return (
        <button className="btn btn-primary mb-4" onClick={requestLoanStart}>{t('btn.request-loan')}</button>
      )
    }
    else if(loanRequestValue.nowStatus==="start") {
      return (
        <button className="btn btn-primary mb-4" onClick={requestTransaction}>{t('btn.excute-transaction')}</button>
      )
    }
    else {
      return (
        <div></div>
      )
    }
  }
  else {
    return (
      <button className="btn btn-inactive mb-4">{t('btn.not-enought-gurantee')}</button>
    )
  }
}

export default LoanRequestBTN
