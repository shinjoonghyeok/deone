import React, {useState, useEffect, useContext} from 'react'
import { useTranslation } from "react-i18next";

import { DeOneProductList}  from "layouts/ProductLayout"
import { LoanRequestInfo } from "layouts/LoanRequestLayout"
import { ProdIconDisplay } from "components/common/CommonFunction"

const LoanRequestGurantee = ({productInfo}) => {
  const { t } = useTranslation('loan');
  const [inputAmount, setInputAmount] = useState(0);
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);

  let readonly = true;
  if(loanRequestValue.nowStatus === "ready" || loanRequestValue.nowStatus === "startLock") readonly = false;
  
  const changeInputAmount = async (e) => {
    const limitAmount = productInfo.userBalance
    let userInputAmount = e.target.value
    if(Number(e.target.value) > Number(limitAmount)) userInputAmount = limitAmount;

    setInputAmount(userInputAmount)
    loanRequestDispatch({"type":"GUARANTEE", "value":Number(userInputAmount)})
  }

  const setMaxAmount = async () => {
    const limitAmount = productInfo.userBalance

    setInputAmount(limitAmount)
    loanRequestDispatch({"type":"GUARANTEE", "value":Number(limitAmount)})
  }

  useEffect(() => {
    setInputAmount(0)
  }, [productInfo.userBalance])

  return (
    <>
      <dl>
        <div className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.guarantee-amount')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>Balance : </span><span>{productInfo.userBalance}</span></dd>
        </div>
        <dd className="input-group mb-3">
          <input type="number" className="form-control form-custom-1 fs-sm-24" placeholder="" aria-label="" value={inputAmount} onChange={changeInputAmount} readOnly={readonly} />
          <span className="input-group-text form-label-custom-1">
            {
              !readonly &&
              <button className="badge badge-custom-2 my-auto"
              onClick={() => {setMaxAmount()}}
              >MAX 
              </button>
            }

            <ProdIconDisplay icon={productInfo.icon} />
          </span>
        </dd>
      </dl>
    </>
  )
}

export default LoanRequestGurantee
