import React from 'react'
import { useTranslation } from "react-i18next";
import { NavLink } from "react-router-dom";

const LoanNotLogin = () => {
  const { t } = useTranslation('loan');

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row">
          <div className="col-12 text-center px-3 px-md-0">
            <h1 className="fs-30 fs-sm-36 fs-md-42 fs-lg-48 fw-700 mb-4">{ t('notlogin.welcome-loan') }</h1>
            <div className="fs-16 fs-sm-18 fw-400 mb-4">
              <div dangerouslySetInnerHTML={{__html: t('notlogin.content1')}} />
              <br />
              <span className="fc-855cea">{ t('notlogin.content2') }</span>
            </div>
            <div className="text-center">
              <NavLink to="/walletConnect" className="btn btn-primary"><span>{ t('btn.make-wallet') }</span></NavLink>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default LoanNotLogin
