import React from 'react'
import { useTranslation } from 'react-i18next';

import ProdNewImg from "assets/images/loan_1_1.png"
import ProdFavImg from "assets/images/loan_1_2.png"
import ProdLowImg from "assets/images/loan_1_3.png"

const ProductTop = () => {
  const  { t } = useTranslation('loan');

  const topProdList = [
    {id:"new", name: t('prod-top.top-new'), icon: ProdNewImg, badge:"NEW!", bggra: "row bg-gradient-custom-1 mx-0 py-3 px-2", bgbg: "badge badge-custom-1 mb-2 fc-2d94e8 bg-f1f8ff", content: "ETH-A"},
    {id:"fav", name: t('prod-top.top-best'), icon: ProdFavImg, badge:"POPULAR", bggra: "row bg-gradient-custom-2 mx-0 py-3 px-2", bgbg: "badge badge-custom-1 mb-2 fc-ff8368 bg-fff7ea", content: "BAT-A"},
    {id:"low", name: t('prod-top.top-low'), icon: ProdLowImg, badge:"lowest interest", bggra: "row bg-gradient-custom-3 mx-0 py-3 px-2", bgbg: "badge badge-custom-1 mb-2 fc-9f79fa bg-f6f2fe", content: "USDC-A"},
  ]

  const displayTopProd = topProdList.map((item, index) => (
    <div className="col-12 col-md-4 mb-3 mb-lg-0" key={index}>
      <div className="border rounded-custom-1 overflow-hidden">
        <div className={item.bggra}>
          <div className="col-auto my-auto px-1 px-md-2 px-lg-3">
            <img className="deone-sec02-img" src={item.icon} alt={item.id} />
          </div>
          <div className="col-auto my-auto px-md-2 px-lg-3">
            <p className="fs-16 fs-sm-18 fs-md-14 fs-lg-18 fw-400 mb-0">{ t('prod-top.done-title') }</p>
            <h1 className="fs-20 fs-sm-24 fs-md-18 fs-lg-24 fw-700">{ item.name }</h1>
          </div>
        </div>
        <div className="text-center py-3 py-lg-5">
          <p className={item.bgbg}>{ item.badge }</p>
          <h2 className="fs-28 fs-sm-42 fs-md-36 fs-lg-48 fw-700 mb-0">{ item.content }</h2>
        </div>
      </div>
    </div>))

  return (
    <section className="sec-03 py-3">
      <div className="container">
        <div className="row">

          {displayTopProd}

        </div>
      </div>
    </section>
  )
}

export default ProductTop
