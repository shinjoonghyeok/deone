import React, {useState, useEffect, useContext} from 'react'
import { useTranslation } from "react-i18next";
import BigNumber from 'bignumber.js';

import { DeOneProductList}  from "layouts/ProductLayout"
import { LoanRequestInfo } from "layouts/LoanRequestLayout"
import LoadingProgress from "components/common/LoadingProgress"

import { DAI } from '@makerdao/dai-plugin-mcd';
import { formatter } from 'utils/deOne';

const LoanrequestFooter = ({productKey, fixGuaranteeAmount}) => {
  const { t } = useTranslation('loan');
  const { productValue, productDispatch } = useContext(DeOneProductList);
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);

  let selectedProduct = productValue.productList.find(x => x.key === productKey);

  let totalLoan = 0;
  let userLoan = 0;
  let guaranteeRate = "0.00";
  let loanFee = "0.00";
  let adjustFee = "0.00";
  let isLoanActive = false;
  let cdpParams = {}

  let guaranteeAmount = 0;
  if(fixGuaranteeAmount!==null) guaranteeAmount = fixGuaranteeAmount
  else guaranteeAmount = loanRequestValue.guaranteeAmount;

  if(typeof selectedProduct !== "undefined") {
    cdpParams = {
      "daiToDraw": loanRequestValue.loanAmount,
      "gemsToLock": guaranteeAmount, //loanRequestValue.guaranteeAmount,
      "txState": ""
    }

    let { calculateMaxDai, debtFloor, collateralDebtAvailable } = selectedProduct;

    collateralDebtAvailable = collateralDebtAvailable?.toBigNumber();
    const daiAvailable = calculateMaxDai(BigNumber(cdpParams.gemsToLock ||'0'));
    const daiAvailableToGenerate = daiAvailable.gt(collateralDebtAvailable)
      ? collateralDebtAvailable.lt(debtFloor)
        ? BigNumber(0)
        : collateralDebtAvailable
      : daiAvailable;

    const userCanDrawDaiAmount = daiAvailable?.gte(
      BigNumber(cdpParams.daiToDraw === '' ? '0' : cdpParams.daiToDraw)
    );

    const collateralizationRatio = selectedProduct.calculateCollateralizationRatio(
      BigNumber(cdpParams.gemsToLock || '0'),
      DAI(cdpParams.daiToDraw || '0')
    );

    totalLoan = parseFloat(collateralDebtAvailable).toFixed(2);
    userLoan = parseFloat(daiAvailableToGenerate).toFixed(2);
    if(collateralizationRatio !== Infinity) guaranteeRate = collateralizationRatio.toFixed(2);
    loanFee = parseFloat(selectedProduct.stabilityFee).toFixed(2);
    adjustFee = formatter(selectedProduct.liquidationPenalty, { percentage: true })
    isLoanActive = userCanDrawDaiAmount
  }

  useEffect(() => {
    if(loanRequestValue.nowStatus === "ready") {
      if(loanRequestValue.guaranteeAmount <= 0 || loanRequestValue.loanAmount <= 0) loanRequestDispatch({"type":"LOANACTIVE", "value":false});
      else loanRequestDispatch({"type":"LOANACTIVE", "value":true});

      if(isLoanActive && guaranteeRate > 150) loanRequestDispatch({"type":"LOANACTIVE", "value":true});
      else loanRequestDispatch({"type":"LOANACTIVE", "value":false});
    }
    else if(loanRequestValue.nowStatus === "startLock") {
      if(loanRequestValue.guaranteeAmount <= 0) loanRequestDispatch({"type":"LOANACTIVE", "value":false});
      else loanRequestDispatch({"type":"LOANACTIVE", "value":true});
    }
    else if(loanRequestValue.nowStatus === "startGen") {
      if(loanRequestValue.loanAmount <= 0) loanRequestDispatch({"type":"LOANACTIVE", "value":false});
      else loanRequestDispatch({"type":"LOANACTIVE", "value":true});
    }
    loanRequestDispatch({"type":"TRANSACTION", "value":cdpParams});
  }, [loanRequestValue.guaranteeAmount, loanRequestValue.loanAmount])

  let transactionFee = "0.0042"

  if(loanRequestValue.nowStatus==="ready") {
    return (
      <>
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.total-avail-done')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{totalLoan.toLocaleString()}</span></dd>
        </dl>
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.user-avail-done')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{userLoan.toLocaleString()}</span></dd>
        </dl>
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.guarantee-rate')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{guaranteeRate.toLocaleString()}</span><span>%</span></dd>
        </dl>
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.loan-fee')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{loanFee.toLocaleString()}</span><span>%</span></dd>
        </dl>
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.adjust-fee')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{adjustFee.toLocaleString()}</span><span>%</span></dd>
        </dl>
      </>
    )
  }
  else if(loanRequestValue.nowStatus==="startLock") {
    return (
      <div className="mb-4">
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.total-avail-done')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{totalLoan.toLocaleString()}</span></dd>
        </dl>
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.user-avail-done')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{userLoan.toLocaleString()}</span></dd>
        </dl>
      </div>
    )
  }
  else if(loanRequestValue.nowStatus==="startGen") {
    return (
      <div className="mb-4">
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.guarantee-rate')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{guaranteeRate.toLocaleString()}</span><span>%</span></dd>
        </dl>
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.loan-fee')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{loanFee.toLocaleString()}</span><span>%</span></dd>
        </dl>
        <dl className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.adjust-fee')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{adjustFee.toLocaleString()}</span><span>%</span></dd>
        </dl>
      </div>
    )
  }
  else if(loanRequestValue.nowStatus==="start") {
    return (
      <dl className="row justify-content-between mb-2">
        <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.transaction-fee')}</dt>
        <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{transactionFee}</span><span>ETH</span></dd>
      </dl>
    )
  }
  else if(loanRequestValue.nowStatus==="transaction") {
    return (
      <div className="text-center">
        <LoadingProgress str={t('loan-request.check-transaction')} />
      </div>
    )
  }
  else {
    return (
      <><p>dddd</p></>
    )
  }

}

export default LoanrequestFooter
