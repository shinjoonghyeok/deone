import React, {useContext, useEffect} from 'react'
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";

import { LoanRequestInfo } from "layouts/LoanRequestLayout"
import LoanFinishImg from "assets/images/complete_1.png"

const LoanRequestSuccess = () => {
  const { t } = useTranslation('loan');
  let history = useHistory();
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);

  const gotoLoanProdPage = () => {
    history.push("/loanProd")
  }

  const loanAmount = loanRequestValue.loanAmount;
  return (
    <>
      <div className="row pb-2 mb-4">
          <div className="col-12 card card-custom-1 mx-auto text-center">
              <h2 className="fs-20 fs-sm-24 fs-md-28 fw-700 mb-3 lh-base">
                <div dangerouslySetInnerHTML={{__html:t('loan-request.loan-complete', {loanAmount})}} />
              </h2>
              <div className="mb-5">
                <img src={LoanFinishImg} alt="complete" />
              </div>
              <div>
                <button className="btn btn-primary" onClick={ gotoLoanProdPage }>{t('btn.check-account')}</button>
              </div>
          </div>
      </div>
    </>
  )
}

export default LoanRequestSuccess
