import React, {useContext} from 'react'
import { useTranslation } from "react-i18next";

import { LoanRequestInfo } from "layouts/LoanRequestLayout"

const LoanRequestSelect = () => {
  const { t } = useTranslation('loan');
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);

  const startAddLock = () => {
    loanRequestDispatch({"type":"STATUS", "value":"startLock"});
  }

  const startAddDeOne = () => {
    loanRequestDispatch({"type":"STATUS", "value":"startGen"});
  }

  return (
    <>
      <div className="row mb-4 mx-0">
        <button onClick={startAddLock} className={`col btn btn-primary me-2 ${loanRequestValue.nowStatus=="startLock" ? '' : 'btn-outline'}`} >{t('btn.add-lock')}</button>
        <button onClick={startAddDeOne} className={`col btn btn-primary  ${loanRequestValue.nowStatus=="startGen" ? '' : 'btn-outline'}`}>{t('btn.add-generate')}</button>
      </div>
    </>
  )
}

export default LoanRequestSelect
