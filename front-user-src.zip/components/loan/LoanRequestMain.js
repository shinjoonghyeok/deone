import React, {useContext, useEffect} from 'react'
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";

import { LoanRequestInfo } from "layouts/LoanRequestLayout"

import ArrowImg from "assets/images/ico_arrow.png"
import LoanRequestGurantee from 'components/loan/LoanRequestGurantee';
import LoanRequestDeOne from 'components/loan/LoanRequestDeOne';
import LoanRequestBTN from 'components/loan/LoanRequestBTN';
import LoanrequestFooter from "components/loan/LoanrequestFooter"

import LoanRequestSuccess from "components/loan/LoanRequestSuccess"

const LoanRequestMain = ({productKey, productInfo}) => {
  const { t } = useTranslation('loan');
  let history = useHistory();
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);

  let loanRequestTitle = t('loan-request.request-title')
  if(loanRequestValue.nowStatus === "finish") loanRequestTitle = t('loan-request.complete-title')

  const cardStyle = {
    minHeight: "550px"
  }
  const fixGuaranteeAmount = null;

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row pb-2 mb-4">
          <div className="col-12 text-cproductKeyenter px-3 px-md-0 text-center">
            <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-0">{loanRequestTitle}</h1>
          </div>
        </div>


        <div className="row pb-2 mb-4">
          { loanRequestValue.nowStatus === "finish" &&
            <LoanRequestSuccess />
          }
          { loanRequestValue.nowStatus !== "finish" &&
            <>
              <div className="col-12 card card-custom-1 mx-auto" style={cardStyle}>
                <LoanRequestGurantee productInfo={productInfo} />            
                <div className="text-center">
                  <img src={ArrowImg} alt="arrow" />
                </div>
                <LoanRequestDeOne />
                <LoanRequestBTN productKey={productKey} />
                <LoanrequestFooter productKey={productKey} fixGuaranteeAmount={fixGuaranteeAmount} />
              </div>
            </>
          }
        </div>
      </div>
    </section>
  )
}

export default LoanRequestMain
