import React, {useContext} from 'react'
import { useTranslation } from 'react-i18next';
import { useHistory } from "react-router-dom";

import { DeOneProductList } from "layouts/ProductLayout"
import useMaker from "hooks/useMaker"
import LoadingProgress from 'components/common/LoadingProgress';
import { ProdIconDisplay } from "components/common/CommonFunction"

const UserProdList = () => {
  const  { t } = useTranslation('loan');
  let history = useHistory();
  const { productValue } = useContext(DeOneProductList);
  const { watch, daiAccount } = useMaker();

  let rawUserProductList = [];
  const cdpList = productValue.productList;
  const userVaultsList = watch.userVaultsList(daiAccount?.address);

  const userVaultIds = typeof userVaultsList !== "undefined" ? userVaultsList.map(x => x.vaultId) : [];
  const userVaultsData = watch.userVaultsData(
    userVaultIds.length ? userVaultIds : undefined
  );

  let proxyAddress = watch.proxyAddress(daiAccount?.address);
  const tokenSymbol = "DAI";
  const allowance = watch.tokenAllowance(
    daiAccount?.address,
    proxyAddress || undefined,
    tokenSymbol
  );
  const hasAllowance = allowance !== undefined && allowance !== null && !allowance.eq(0);
  if(typeof proxyAddress === "undefined") proxyAddress = null;

  if(typeof userVaultsList !== "undefined" && typeof userVaultsData !== "undefined") {
    if(userVaultsList.length === userVaultsData.length) {
      userVaultsList.forEach(item => {
        let prodData = cdpList.find(cdp => cdp.key === item.vaultType);
        let vaultData = userVaultsData.find(vault => vault.id === item.vaultId);
        rawUserProductList.push({item, prodData, vaultData})
      })
    }
  }
  
  let userProductContent = [];
  rawUserProductList.forEach(upl => {
    let uplData = {};
    uplData.guarantee         = upl.prodData.icon;
    uplData.guaranteeAmount   = (typeof upl.vaultData.collateralAmount !== "undefined") ? upl.vaultData.collateralAmount.toString() : 0;
    uplData.availDeoneCount   = (typeof upl.vaultData.debtValue !== "undefined") ? upl.vaultData.debtValue.toString() : 0;
    uplData.nowPrice          = (typeof upl.vaultData.collateralValue !== "undefined") ? upl.vaultData.collateralValue.toString() : 0;
    uplData.riskRate          = (typeof upl.vaultData.liquidationRatio !== "undefined") ? upl.vaultData.liquidationRatio.toString() : 0;
    uplData.btnStatus         = true;
    uplData.btn               = t('btn.loan-add');

    uplData.icon              = upl.prodData.icon;
    uplData.gem               = upl.prodData.gem;
    uplData.desc              = upl.prodData.desc;
    uplData.vaultId           = upl.item.vaultId;

    userProductContent.push(uplData);
  })

  let showUserProductList = <div className="d-flex w-100 justify-content-center"><LoadingProgress /></div>

  const gotoMakeProxy = () => {
    history.push("/walletSetting")
  }

  if(userProductContent.length > 0) {
    showUserProductList = userProductContent.map((item, index) => (
      <div className="card px-4 py-4 py-lg-3 mb-3" key={index}>
        <div className="row justify-content-between">
          <div className="col-12 col-lg-2 my-auto px-0">
            <dl className="row justify-content-between mb-3 mb-lg-0">
              <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('user-prod-list.guarantee')}</span></dt>
              <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><ProdIconDisplay icon={item.icon} /></dd>
            </dl>
          </div>
          <div className="col-12 col-lg-auto my-auto px-0">
            <dl className="row justify-content-between mb-3 mb-lg-0">
              <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('user-prod-list.guarantee-amount')}</span></dt>
              <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.guaranteeAmount}</span></dd>
            </dl>
          </div>
          <div className="col-12 col-lg-auto my-auto px-0">
            <dl className="row justify-content-between mb-3 mb-lg-0">
              <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('user-prod-list.avail-deone-count')}</span></dt>
              <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.availDeoneCount}</span></dd>
            </dl>
          </div>
          <div className="col-12 col-lg-auto my-auto px-0">
            <dl className="row justify-content-between mb-3 mb-lg-0">
              <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('user-prod-list.now-price')}</span></dt>
              <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.nowPrice}</span></dd>
            </dl>
          </div>
          <div className="col-12 col-lg-auto my-auto px-0">
            <dl className="row justify-content-between mb-3 mb-lg-0">
              <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('user-prod-list.risk-rate')}</span></dt>
              <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.riskRate}</span></dd>
            </dl>
          </div>
          <div className="col-12 col-lg-auto my-auto px-0">
            <dl className="row mb-0">
              { item.btnStatus && 
                <>
                <dd className="mb-0">
                  <button className="btn btn-primary d-block"
                    onClick={() => {
                      history.push({
                        pathname: '/loanAddRequest',
                        state: {
                          vaultId: item.vaultId,
                          gem: item.gem
                        }
                      })
                    }}
                  >
                    { t('btn.loan-add') }
                  </button>
                </dd>
                </>
              }
              { !(item.btnStatus) && 
                <>
                <dd className="mb-0"><button className="btn btn-inactive d-block">{ t('btn.loan-deny') }</button></dd>
                </>
              }
            </dl>
          </div>
        </div>
      </div>
    ))
  }
  else {
    showUserProductList = <span className="d-flex w-100 justify-content-center">{t('user-prod-list.no-prod')}</span>
  }

  return (
    <section className="sec-02 pb-5">
      {
        ( proxyAddress === null && !hasAllowance ) &&
        <div className="d-flex justify-content-center">
          <button className="btn btn-primary" onClick={ gotoMakeProxy }>{ t('btn.make-wallet') }</button>
        </div>
      }
      {
        ( proxyAddress === null && hasAllowance ) &&
        <div className="d-flex justify-content-center">
          <button className="btn btn-primary" onClick={ gotoMakeProxy }>{ t('btn.make-wallet') }</button>
        </div>
      }
      {
        ( proxyAddress !== null && !hasAllowance ) &&
        <div className="d-flex justify-content-center">
          <button className="btn btn-primary" onClick={ gotoMakeProxy }>{ t('btn.make-wallet') }</button>
        </div>
      }
      {
        ( proxyAddress !== null && hasAllowance ) &&
        <>
        <div className="container">
          <div className="card px-4 py-3 d-none d-lg-block mb-3">
            <div className="row justify-content-between">
              <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('user-prod-list.guarantee')}</span></div>
              <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('user-prod-list.guarantee-amount')}</span></div>
              <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('user-prod-list.avail-deone-count')}</span></div>
              <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('user-prod-list.now-price')}</span></div>
              <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('user-prod-list.risk-rate')}</span></div>
              <div className="col-2 text-center px-0"><span className="fs-18 fw-500"></span></div>
            </div>
          </div>

          {showUserProductList}
        </div>
        </>
      }

    </section>
  )
}

export default UserProdList
