import React, {useContext, useEffect} from 'react'
import { useTranslation } from "react-i18next";

import { DeOneProductList } from "layouts/ProductLayout"
import { LoanRequestInfo } from "layouts/LoanRequestLayout"


import ArrowImg from "assets/images/ico_arrow.png"

import LoanRequestSelect from "components/loan/LoanRequestSelect"
import LoanrequestInfo from "components/loan/LoanrequestInfo"

import LoanRequestGurantee from 'components/loan/LoanRequestGurantee';
import LoanRequestDeOne from 'components/loan/LoanRequestDeOne';
import LoanAddRequestBTN from 'components/loan/LoanAddRequestBTN';
// import LoanrequestFooter from "components/loan/LoanrequestFooter"
import LoadingProgress from "components/common/LoadingProgress"

import LoanRequestSuccess from "components/loan/LoanRequestSuccess"


const LoanAddRequestMain = ({vaultData, productKey, productInfo}) => {
  const { t } = useTranslation('loan');
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);

  let loanRequestTitle = t('loan-request.request-title')
  if(loanRequestValue.nowStatus === "finish") loanRequestTitle = t('loan-request.complete-title')

  console.log(loanRequestValue);

  const cardStyle = {
    minHeight: "100px"
  }

  let fixGuaranteeAmount = null;
  if(typeof vaultData.collateralAmount !== "undefined") fixGuaranteeAmount = vaultData.collateralAmount.toNumber();

  useEffect(() => {
    if(loanRequestValue.nowStatus==="ready") {
      loanRequestDispatch({"type":"GUARANTEE", "value":0});
      loanRequestDispatch({"type":"LOAN", "value":0});
    }
  }, [loanRequestValue.nowStatus])

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row pb-2 mb-4">
          <div className="col-12 text-cproductKeyenter px-3 px-md-0 text-center">
            <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-0">{loanRequestTitle}</h1>
          </div>
        </div>


        <div className="row pb-2 mb-4">
          { loanRequestValue.nowStatus === "finish" &&
            <LoanRequestSuccess />
          }
          { loanRequestValue.nowStatus !== "finish" &&
            <>
              <div className="col-12 card card-custom-1 mx-auto" style={cardStyle}>
                <LoanRequestSelect />
                <LoanrequestInfo vaultData={vaultData} productInfo={productInfo} />
                
                { (loanRequestValue.nowStatus === "checkLock" || loanRequestValue.nowStatus === "startLock") &&
                  <>
                    <LoanRequestGurantee productInfo={productInfo} />
                    <LoanAddRequestBTN vaultData={vaultData} productKey={productKey} />
                  </>
                }

                { (loanRequestValue.nowStatus === "checkGen" || loanRequestValue.nowStatus === "startGen") &&
                  <>
                    <LoanRequestDeOne />
                    <LoanAddRequestBTN vaultData={vaultData} productKey={productKey} />
                  </>
                }
                
                { (loanRequestValue.nowStatus === "transaction") &&
                  // <LoanrequestFooter productKey={productKey} fixGuaranteeAmount={fixGuaranteeAmount} />
                  <div className="text-center">
                    <LoadingProgress str={t('loan-request.check-transaction')} />
                  </div>
                }
              </div>
            </>
          }
        </div>
      </div>
    </section>
  )
}

export default LoanAddRequestMain
