import React from 'react'
import { useTranslation } from 'react-i18next';

import LoanGuideImg1 from "assets/images/loan_3_1.png"
import LoanGuideImg2 from "assets/images/loan_3_2.png"
import LoanGuideImg3 from "assets/images/loan_3_3.png"
import LoanGuideImg4 from "assets/images/loan_3_4.png"

const LoanGuide = () => {
  const  { t } = useTranslation('loan');

  return (
    <section className="sec-05 pt-3 pb-5">
      <div className="container pb-4">
        <div className="row">
          <div className="col-12 col-lg-3 mb-3 mb-lg-0">
            <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-0">{ t('loan-guide.title') }</h1>
            <p className="fs-16 fs-sm-18 fw-400 mb-4">{ t('loan-guide.title-sub') }</p>
          </div>
          <div className="col-12 col-lg-9">
            <div className="row mb-4 pb-2">
              <div className="col-auto pe-1">
                <img src={LoanGuideImg1} alt="guide1" />
              </div>
              <div className="col pt-2">
                <h4 className="fs-20 fs-sm-24 fw-700">{t('loan-guide.borrow-rate')}</h4>
                <div className="fs-14 fs-sm-16 fw-400 mb-1" dangerouslySetInnerHTML={{__html:t('loan-guide.borrow-rate-content')}}>
                </div>
              </div>
            </div>
            <div className="row mb-4 pb-2">
              <div className="col-auto pe-1">
              <img src={LoanGuideImg2} alt="guide2" />
              </div>
              <div className="col pt-2">
                <h4 className="fs-20 fs-sm-24 fw-700">{t('loan-guide.loadn-limit')}</h4>
                <div className="fs-14 fs-sm-16 fw-400 mb-1" dangerouslySetInnerHTML={{__html:t('loan-guide.loadn-limit-content')}}></div>
              </div>
            </div>
            <div className="row mb-4 pb-2">
              <div className="col-auto pe-1">
                <img src={LoanGuideImg3} alt="guide3" />
              </div>
              <div className="col pt-2">
                <h4 className="fs-20 fs-sm-24 fw-700">{t('loan-guide.loan-fee')}</h4>
                <div className="fs-14 fs-sm-16 fw-400 mb-1" dangerouslySetInnerHTML={{__html:t('loan-guide.loan-fee-content')}}>
                </div>
              </div>
            </div>
            <div className="row mb-4 pb-2">
              <div className="col-auto pe-1">
                <img src={LoanGuideImg4} alt="guide4" />
              </div>
              <div className="col pt-2">
                <h4 className="fs-20 fs-sm-24 fw-700">{t('loan-guide.clear-fee')}</h4>
                <div className="fs-14 fs-sm-16 fw-400 mb-1" dangerouslySetInnerHTML={{__html:t('loan-guide.clear-fee-content')}}>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default LoanGuide
