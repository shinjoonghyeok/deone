import React from 'react'
import { useTranslation } from "react-i18next";

const LoanrequestInfo = ({vaultData, productInfo}) => {
  const { t } = useTranslation('loan');
  let vaultAmount = 0;
  let daiAvailable = 0;
  let collateralizationRatio = 0;

  if(typeof vaultData.collateralAmount !== "undefined") vaultAmount = vaultData.collateralAmount.toString()
  if(typeof vaultData.daiAvailable !== "undefined") daiAvailable = vaultData.daiAvailable.toString()
  if(typeof vaultData.collateralizationRatio !== "undefined") collateralizationRatio = (vaultData.collateralizationRatio.toNumber().toFixed(2) ) * 100;

  return (
    <div className="mb-2">
      <dl className="row justify-content-between mb-2">
        <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.lock-amount')}</dt>
        <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{vaultAmount}</span></dd>
      </dl>
      <dl className="row justify-content-between mb-2">
        <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.available-gen-amount')}</dt>
        <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{daiAvailable}</span></dd>
      </dl>
      <dl className="row justify-content-between mb-2">
        <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('loan-request.guarantee-rate')}</dt>
        <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{collateralizationRatio}</span><span>%</span></dd>
      </dl>
    </div>
  )
}

export default LoanrequestInfo
