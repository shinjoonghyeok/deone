import React, {useContext} from 'react'
import { useTranslation } from 'react-i18next';
import { useHistory } from "react-router-dom";

import { DeOneProductList } from "layouts/ProductLayout"
import { ProdIconDisplay } from "components/common/CommonFunction"

const ProductList = () => {
  const  { t } = useTranslation('loan');
  let history = useHistory();
  const { productValue, productDispatch } = useContext(DeOneProductList);

  let cdpList = [];
  cdpList = productValue.productList

  const prodList = cdpList.map((item, index) => (
    <div className="card px-4 py-4 py-lg-3 mb-3" key={index}>
      <div className="row justify-content-between">
        <div className="col-12 col-lg-2 my-auto px-0">
          <dl className="row justify-content-between mb-3 mb-lg-0">
            <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('prod-list.borrow')}</span></dt>
            <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><ProdIconDisplay icon={item.icon} /></dd>
          </dl>
        </div>
        <div className="col-12 col-lg-auto my-auto px-0">
          <dl className="row justify-content-between mb-3 mb-lg-0">
            <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('prod-list.kind')}</span></dt>
            <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.symbol}</span></dd>
          </dl>
        </div>
        <div className="col-12 col-lg-auto my-auto px-0">
          <dl className="row justify-content-between mb-3 mb-lg-0">
            <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('prod-list.done-count')}</span></dt>
            <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.maxDoneCount}</span></dd>
          </dl>
        </div>
        <div className="col-12 col-lg-auto my-auto px-0">
          <dl className="row justify-content-between mb-3 mb-lg-0">
            <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('prod-list.fix-fee')}</span></dt>
            <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.stabilityFee}</span></dd>
          </dl>
        </div>
        <div className="col-12 col-lg-auto my-auto px-0">
          <dl className="row justify-content-between mb-3 mb-lg-0">
            <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('prod-list.risk-rate')}</span></dt>
            <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.liquidationRatio.toString()}</span></dd>
          </dl>
        </div>
        <div className="col-12 col-lg-auto my-auto px-0">
          <dl className="row mb-0">
            { item.btnStatus && 
              <>
                <dd className="mb-0">
                  <button className="btn btn-primary d-block" onClick={() => {
                      history.push({
                        pathname: '/loanRequest',
                        state: {productKey: item.key}
                      })
                    }}>
                      { t('btn.loan-request') }
                  </button>
                </dd>
              </>
            }
            { !(item.btnStatus) && 
              <>
                <dd className="mb-0"><button className="btn btn-inactive d-block">{ t('btn.loan-deny') }</button></dd>
              </>
            }
            
          </dl>
        </div>
      </div>
    </div>
  ));

  return (
    <section className="sec-04 py-3">
      <div className="container">
        <div className="card px-4 py-3 d-none d-lg-block mb-3">
          <div className="row justify-content-between">
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('prod-list.borrow')}</span></div>
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('prod-list.kind')}</span></div>
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('prod-list.done-count')}</span></div>
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('prod-list.fix-fee')}</span></div>
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('prod-list.risk-rate')}</span></div>
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500"></span></div>
          </div>
        </div>

        {prodList}
        
      </div>
    </section>
  )
}

export default ProductList
