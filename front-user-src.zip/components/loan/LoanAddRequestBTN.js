import React, {useEffect, useContext} from 'react'
import { useTranslation } from "react-i18next";
import BigNumber from 'bignumber.js';
import { DAI } from '@makerdao/dai-plugin-mcd';

import { DeOneProductList}  from "layouts/ProductLayout"
import { LoanRequestInfo } from "layouts/LoanRequestLayout"

import useMaker from "hooks/useMaker"
import ilkList from "references/ilkList"

const LoanAddRequestBTN = ({vaultData, productKey}) => {
  const { t } = useTranslation('loan');
  const { loanRequestValue, loanRequestDispatch } = useContext(LoanRequestInfo);

  const { maker } = useMaker();

  let daiAvailable = 0;
  if(typeof vaultData.daiAvailable !== "undefined") daiAvailable = vaultData.daiAvailable.toNumber()

  const requestAddLockStart = async () => {
    if(loanRequestValue.guaranteeAmount <= 0) {
      alert("ERROR");
      return;
    }

    loanRequestDispatch({"type":"STATUS", "value":"checkLock"});

    let inputAmount = loanRequestValue.guaranteeAmount;
    const amountToDeposit =inputAmount && !BigNumber(inputAmount).isNegative() ? BigNumber(inputAmount) : BigNumber(0);
    const currency = ilkList.find(x => x.symbol === vaultData.vaultType).currency;

    const txObject = maker
    .service('mcd:cdpManager')
    .lock(
      vaultData.id,
      vaultData.vaultType,
      currency(amountToDeposit)
    );

    const txMgr = maker.service('transactionManager');
    txMgr.listen(txObject, {
      pending: tx => {
        loanRequestDispatch({"type":"STATUS", "value":"transaction"});
        console.log("pending", tx)
      }, 
      mined: tx => {
        loanRequestDispatch({"type":"STATUS", "value":"ready"});
        console.log("minted", tx)
      },
      confirmed: () => {
        console.log("confirmed")
      },
      error: () => {
        loanRequestDispatch({"type":"STATUS", "value":"ready"})
        console.log("ERROR")
      }

    });
    await txMgr.confirm(txObject, 1);
  }

  const requestAddGenerate = async () => {
    if(loanRequestValue.loanAmount <= 0) {
      alert("ERROR");
      return;
    }
    
    if(daiAvailable <= loanRequestValue.loanAmount) {
      alert("ERROR");
      return;
    }

    loanRequestDispatch({"type":"STATUS", "value":"checkGen"});

    let inputDone = loanRequestValue.loanAmount;
    const txObject = maker.service('mcd:cdpManager')
    .draw(
      vaultData.id,
      vaultData.vaultType,
      DAI(inputDone)
    );

    const txMgr = maker.service('transactionManager');
    txMgr.listen(txObject, {
      pending: tx => {
        loanRequestDispatch({"type":"STATUS", "value":"transaction"});
        console.log("pending", tx)
      }, 
      mined: tx => {
        loanRequestDispatch({"type":"STATUS", "value":"ready"});
        console.log("minted", tx)
      },
      confirmed: () => {
        console.log("confirmed")
      },
      error: () => {
        loanRequestDispatch({"type":"STATUS", "value":"ready"})
        console.log("ERROR")
      }

    });
    await txMgr.confirm(txObject, 1);
  }

  useEffect(() => {
    if(loanRequestValue.nowStatus === "startLock") {
      if(loanRequestValue.guaranteeAmount <= 0) loanRequestDispatch({"type":"LOANACTIVE", "value":false});
      else loanRequestDispatch({"type":"LOANACTIVE", "value":true});
    }
    else if(loanRequestValue.nowStatus === "startGen") {
      console.log(daiAvailable);
      if(loanRequestValue.loanAmount <= 0) loanRequestDispatch({"type":"LOANACTIVE", "value":false});
      else if(daiAvailable <= loanRequestValue.loanAmount) loanRequestDispatch({"type":"LOANACTIVE", "value":false});
      else loanRequestDispatch({"type":"LOANACTIVE", "value":true});
    }
  }, [loanRequestValue.guaranteeAmount, loanRequestValue.loanAmount])


  if(loanRequestValue.isLoanActive) {
    if(loanRequestValue.nowStatus==="startLock") {
      return (
        <button className="btn btn-primary mb-4" onClick={requestAddLockStart}>{t('btn.request-add-lock')}</button>
      )
    }
    else if(loanRequestValue.nowStatus==="startGen") {
      return (
        <button className="btn btn-primary mb-4" onClick={requestAddGenerate}>{t('btn.request-add-generate')}</button>
      )
    }
    else {
      return (
        <div></div>
      )
    }
  }
  else {
    return (
      <button className="btn btn-inactive mb-4">{t('btn.not-enought-gurantee')}</button>
    )
  }
}

export default LoanAddRequestBTN
