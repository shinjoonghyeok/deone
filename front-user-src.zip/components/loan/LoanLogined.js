import React from 'react'
import { useTranslation } from 'react-i18next';

import DeOneSymbol from 'assets/images/ico_d.png'
import useMaker from 'hooks/useMaker'
import { defaultValues } from "utils/deOne"
import { showWalletTokens } from "references/config"

const LoanLogined = () => {
  const  { t } = useTranslation('loan');
  const { watch, daiAccount } = useMaker();
  
  const symbolStyle = {
    margin: "0 0 10px 5px"
  }

  let loanAmount = 0;
  const symbols = showWalletTokens.filter(v => v !== 'DSR');

  const dsrBalance = watch.daiLockedInDsr(daiAccount?.address);
  const tokenBalances = watch.tokenBalances(daiAccount?.address, symbols);

  const tbs = tokenBalances?.reduce(
    (acc, tokenBalance) => {
      acc[tokenBalance.symbol] = tokenBalance.toBigNumber().toLocaleString();
      return acc;
    },
    { DSR: dsrBalance?.toBigNumber() }
  ) || defaultValues;

  loanAmount = tbs["DAI"];
  loanAmount = parseFloat(loanAmount).toFixed(2)

  
  return (
    <section className="sec-01 pt-3 pb-0">
      <div className="container">
        <div className="row">
          <div className="col-12 text-center px-3 px-md-0">
            <h1 className="fs-30 fs-sm-36 fs-md-42 fs-lg-48 fw-700 mb-4">
              <span>{t('logined.welcome-loan')}</span><span className="fc-855cea">{ loanAmount.toLocaleString() }</span><img src={DeOneSymbol} alt="DeOne" style={symbolStyle} />
            </h1>
            <div className="fs-16 fs-sm-18 fw-400 mb-4">
              <div dangerouslySetInnerHTML={{__html: t('notlogin.content1')}} />
              <br />
              <span className="fc-855cea">{ t('notlogin.content2') }</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default LoanLogined