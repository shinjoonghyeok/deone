import React, {useState, useEffect} from 'react'
import { useTranslation } from 'react-i18next';

import {deoneFetchAPI} from "utils/api"

const NoticeView = () => {
  const { t } = useTranslation('common');

  const [noticeList, setNoticeList] = useState([]);

  const viewDetail = (e) => {
    let targetIdx = e.target.getAttribute("data-id");
    console.log(noticeList[targetIdx].notice_content);
  }

  const tableContent = noticeList.map((item, index) => {
    return (
      <div className="card px-4 py-4 py-lg-3 mb-3">
          <div className="row justify-content-between">
          <div className="col-12 col-lg-2 my-auto px-0">
            <dl className="row justify-content-between mb-3 mb-lg-0">
              <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('notice.nt-seq')}</span></dt>
              <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.seq}</span></dd>
            </dl>
          </div>
          <div className="col-12 col-lg-auto my-auto px-0">
            <dl className="row justify-content-between mb-3 mb-lg-0">
              <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('notice.nt-title')}</span></dt>
              <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.notice_title}</span></dd>
            </dl>
          </div>
          <div className="col-12 col-lg-auto my-auto px-0">
            <dl className="row justify-content-between mb-3 mb-lg-0">
              <dt className="d-lg-none col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{t('notice.nt-date')}</span></dt>
              <dd className="col-auto my-auto mb-0 fs-16 fs-lg-18 fw-400"><span>{item.notice_insert_date}</span></dd>
            </dl>
          </div>
        </div>
      </div>
    )
  })

  const color = "light"

  useEffect(() => {
    async function fetchNotice () {
      let requestMethod = "post";
      let requestTaget = "api/listNotice";
      let requestParams = {};
      let requestData = {};
      let requestHeaders = { 'accept': 'application/json' };
      let noticeList = await deoneFetchAPI(requestMethod,requestTaget,requestParams,requestData,requestHeaders);

      setNoticeList(noticeList)
    }
    fetchNotice();
  }, [])

  return (
    <section className="sec-03 py-3">
      <div className="container">
        <div className="card px-4 py-3 d-none d-lg-block mb-3">
          <div className="row justify-content-between">
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('notice.nt-seq')}</span></div>
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('notice.nt-title')}</span></div>
            <div className="col-2 text-center px-0"><span className="fs-18 fw-500">{t('notice.nt-date')}</span></div>
          </div>
        </div>

        {tableContent}

      </div>
    </section>
  )
}

export default NoticeView