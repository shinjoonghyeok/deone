import React from 'react'
import { NavLink } from "react-router-dom";
import { useTranslation } from 'react-i18next';

import FooterLogoImg from "assets/images/f_logo_1.png"
import FooterMCImg from "assets/images/f_logo_2.png"

const Footer = () => {
  const { i18n } = useTranslation()
  const { t } = useTranslation('footer');

  const changeLanguage = (lang) => {
    console.log(lang)
    i18n.changeLanguage(lang)
  }

  return (
    <>
      <footer id="footer" className="bg-1f1b2f py-4 py-sm-5">
        <div className="container py-4 py-sm-5">
          <div className="row mb-70">
            <div className="col-12 col-md-3 mb-4 mb-md-0">
              <img src={FooterLogoImg} alt="DeOne"/>
            </div>
            <div className="col-12 col-md-9">
              <ul className="row fc-ffffff">
                <li className="col-12 col-sm-6 col-md-3 mb-4 mb-sm-0">
                  <div className="fs-16 fw-500 mb-2 mb-sm-3">{ t('menu.done-service') }</div>
                  <div className="d-flex flex-sm-column">
                    <NavLink to="/loanProd" className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0"><span>{ t('menu.loan-prod') }</span></NavLink>
                    <NavLink to="/savingProd" className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0"><span>{ t('menu.saving-prod') }</span></NavLink>
                    <NavLink to="/governance" className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0"><span>{ t('menu.governance') }</span></NavLink>
                    <NavLink to="/community" className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0"><span>{ t('menu.community') }</span></NavLink>
                  </div>
                </li>
                <li className="col-12 col-sm-6 col-md-3 mb-4 mb-sm-0">
                  <div className="fs-16 fw-500 mb-2 mb-sm-3">{ t('menu.community') }</div>
                  <div className="d-flex flex-sm-column">
                    <NavLink to="/notice" className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0"><span>{ t('menu.notice') }</span></NavLink>
                  </div>
                </li>
                <li className="col-12 col-sm-6 col-md-3 mb-4 mb-sm-0">
                  <div className="fs-16 fw-500 mb-2 mb-sm-3">{ t('menu.language') }</div>
                  <div className="d-flex flex-sm-column">
                    <p className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0 cursor-pointer" onClick={() => changeLanguage('en')}>{ t('menu.english') }</p>
                    <p className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0 cursor-pointer" onClick={() => changeLanguage('ko')}>{ t('menu.korea') }</p>
                  </div>
                </li>
                <li className="col-12 col-sm-6 col-md-3 mb-4 mb-sm-0">
                  <div className="fs-16 fw-500 mb-2 mb-sm-3">{ t('menu.use-guide') }</div>
                  <div className="d-flex flex-sm-column">
                    <NavLink className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0" to="/privatePolicy">{ t('menu.privacy-policy') }</NavLink>
                    <NavLink className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0" to="/useTerm">{ t('menu.use-term') }</NavLink>
                    <NavLink className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0" to="/serviceManual">{ t('menu.service-manual') }</NavLink>
                    <NavLink className="d-block fs-14 fw-400 mb-1 me-3 me-sm-0" to="/contactUs">{ t('menu.contact') }</NavLink>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div className="row">
            <div className="col-12 col-md-3 mb-4 mb-md-0">
              <img src={FooterMCImg} alt="Monster" />
            </div>
            <div className="col-12 col-md-9 fc-ffffff">
              <address>
                <p className="fs-14 fw-400">서울특별시 강남구 논현로63길 71 (주)몬스터큐브</p>
                <p className="fs-14 fw-400">CEO : 유재범<span className="mx-3">|</span>사업자등록 : 441-87-00779<span className="mx-3">|</span>통신판매번호 : 제2018-서울강남-02815호<span className="mx-3">|</span>Tel : 02 1522 9746<span className="mx-3">|</span>Fax : 0504 276 3309
                </p>
                <p className="fs-14 fw-400">Copyright ⓒ MONSTER CUBE Corporation. All Rights Reserved.</p>
              </address>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}

export default Footer
