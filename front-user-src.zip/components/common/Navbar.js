import React, {useState} from 'react'
import { Link, NavLink, useHistory } from "react-router-dom";
import { useTranslation } from 'react-i18next';

import useMaker from 'hooks/useMaker'
import { defaultValues } from "utils/deOne"
import { showWalletTokens } from "references/config"

import LogoImg from "assets/images/logo.png"
import { AccountDisplay } from 'components/common/CommonFunction'

const Navbar = () => {
  const { t } = useTranslation('nav');
  let history = useHistory();

  let loanAmount = 0;
  const { watch, daiAccount } = useMaker();
  const symbols = showWalletTokens.filter(v => v !== 'DSR');

  const dsrBalance = watch.daiLockedInDsr(daiAccount?.address);
  const tokenBalances = watch.tokenBalances(daiAccount?.address, symbols);

  const tbs = tokenBalances?.reduce(
    (acc, tokenBalance) => {
      acc[tokenBalance.symbol] = tokenBalance.toBigNumber().toLocaleString();
      return acc;
    },
    { DSR: dsrBalance?.toBigNumber() }
  ) || defaultValues;

  if(typeof tbs["DAI"] == "string") loanAmount = tbs["DAI"];
  loanAmount = parseFloat(loanAmount).toFixed(2);

  
  const [mobileMenu, setMobileMenu] = useState(false);
  
  const toggleOn = () => {
    if(mobileMenu) setMobileMenu(false)
    else setMobileMenu(true)
  }

  const toggleOff = () => {
    setMobileMenu(false)
  }

  return (
    <>
      <header id="header" className="px-3 py-4 px-lg-0">
        <nav className="gnb-bar container">
          <div className="row">
            <div className="col-auto z-index-999">
              <Link
                to="/"
              >
                <img src={LogoImg} alt="DeONE" />
              </Link>
            </div>
            <div className="col d-none d-lg-block">
              <div className="row justify-content-end fs-16 fw-500">
                <NavLink
                  to="/deOneIntro"
                  className="col-auto me-4 my-auto"
                >
                  <span className="link-hover">{ t('intro-done') }</span>
                </NavLink>
                <NavLink
                  to="/loanProd"
                  className="col-auto me-4 my-auto"
                >
                  <span className="link-hover">{ t('loan-prod') }</span>
                </NavLink>
                <NavLink
                  to="/savingProd"
                  className="col-auto me-4 my-auto"
                >
                  <span className="link-hover">{ t('saving-prod') }</span>
                </NavLink>
                {/* <NavLink
                  to="/governance"
                  className="col-auto me-4 my-auto"
                >
                  <span className="link-hover">{ t('governance') }</span>
                </NavLink> */}

                { daiAccount === null &&
                  <NavLink to="/walletConnect" className="col-auto btn btn-primary btn-outline"><span>{ t('btn.make-wallet') }</span></NavLink>
                }
                { daiAccount !== null &&
                  <div className="col-auto user-info">
                    <div className="d-inline-block">
                      <span className="fc-855cea me-1">{loanAmount}</span><span>DeONE</span>
                    </div>
                    <div className="d-inline-block">
                      <button
                        className="btn-header-1"
                        onClick={ () => {history.push("/walletConnect")}}
                      >
                        <AccountDisplay account={daiAccount?.address} />
                      </button>
                    </div>
                  </div>
                }
              </div>
            </div>
            <div className="col d-lg-none">
              <div className="row justify-content-end">
                <div className={mobileMenu ? "menu menu-ico move-left close-ico z-index-999 active" : "menu menu-ico move-left close-ico z-index-999"} onClick={toggleOn}>
                  <span className="fs-0">menu</span>
                </div>
              </div>
            </div>
            <div className={mobileMenu ? "pop-gnb active" : "pop-gnb"}  onClick={toggleOff}>
              <div className="pop-gnb-wrap fs-20 fw-700 text-center">
                <NavLink
                  to="/deOneIntro"
                  className="d-block btn btn-primary btn-outline mb-3"
                >
                  <span>{ t('intro-done') }</span>
                </NavLink>
                <NavLink
                  to="/loanProd"
                  className="d-block btn btn-primary btn-outline mb-3"
                >
                  <span>{ t('loan-prod') }</span>
                </NavLink>
                <NavLink
                  to="/savingProd"
                  className="d-block btn btn-primary btn-outline mb-3"
                >
                  <span>{ t('saving-prod') }</span>
                </NavLink>
                {/* <NavLink
                  to="/governance"
                  className="d-block btn btn-primary btn-outline mb-3"
                >
                  <span>{ t('governance') }</span>
                </NavLink> */}
                
                { daiAccount === null &&
                  <NavLink to="/walletConnect" className="d-block btn btn-primary"><span>{ t('btn.make-wallet') }</span></NavLink>
                }
                { daiAccount !== null &&
                  <div className="text-center">
                    <div className="user-info">
                      <div>
                        <span className="fc-855cea me-1">{loanAmount}</span><span>DeONE</span>
                      </div>
                      <div>
                        <button
                          className="btn-header-1 w-100"
                          onClick={ () => {history.push("/walletConnect")}}
                        >
                          <AccountDisplay account={daiAccount?.address} />
                        </button>
                      </div>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>
        </nav>
      </header>
    </>
  )
}

export default Navbar
