import React from 'react'

import "assets/styles/loading.scss"

const LoadingProgress = ({str}) => {
  if(typeof str === "undefined") str = "";

  const strArray = str.split('');
  const displayString = strArray.map((item, index) => (
    <span key={index}>{item}</span>
  ))

  return (
    <>
    <div className='d-flex mt-4 mb-2 justify-content-center'>
      <div className="done_loading">
        <div className='done_loading__square'></div>
        <div className='done_loading__square'></div>
        <div className='done_loading__square'></div>
        <div className='done_loading__square'></div>
        <div className='done_loading__square'></div>
        <div className='done_loading__square'></div>
        <div className='done_loading__square'></div>
      </div>
    </div>

    <div className="loading-text fs-20 fs-sm-24 fw-500 fc-855cea">
      {displayString}
    </div>

    </>
  )
}

export default LoadingProgress
