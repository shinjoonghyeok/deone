import React from 'react'
import Jazzicon, { jsNumberForAddress } from 'react-jazzicon'

const WalletIcon = ({account, diameter}) => {
  return (
    <div id="walletIcon">
      <Jazzicon diameter={diameter} seed={jsNumberForAddress(account)} />
    </div>
  )
}

export default WalletIcon
