import React from 'react'

const SliderBar = ({value}) => {
  return (
    <div>
      <div className="progress">
        <span className="progress-bar done" style={{"width": `${value}%`}}>
        </span>    
      </div>
    </div>
  )
}

export default SliderBar