import React from "react";
import YouTube from "react-youtube";

const DeOneYoutub = ({videoID}) => {
  const opts = {
    playerVars: {
      autoplay: 1,
    },
  }
  return (
    <div>
      <YouTube videoId={videoID} opts={opts} />
    </div>
  );
};

export default DeOneYoutub;