import React from 'react'
import WalletIcon from 'components/common/WalletIcon'

import Ethereum from "assets/images/loan_2_1.png"
import Bitcoin from "assets/images/loan_2_2.png"
import USDC from "assets/images/loan_2_3.png"
import Paxos from "assets/images/loan_2_4.png"

export const AccountDisplay = ({account, type}) => {
  let displayAddress = `${account.slice(0, 6)}...${account.slice(-4)}` 
  if(type==="full") displayAddress = `${account}` 
  
  return (
    <>
      <div className="d-flex">
        <span className="me-1">{displayAddress}</span>
        <WalletIcon account={account} diameter={18} />
      </div>
    </>
  )
}

export const ProdIconDisplay = ({icon}) => {
  switch(icon) {
    case "Ether":
      return (<><img className="mx-2" src={Ethereum} /><span className="d-inline-block my-auto fs-16 fs-sm-18 fw-400">{icon}</span></>)
    case "Bitcoin":
      return (<><img className="mx-2" src={Bitcoin} /><span className="d-inline-block my-auto fs-16 fs-sm-18 fw-400">{icon}</span></>)
    case "USDC":
      return (<><img className="mx-2" src={USDC} /><span className="d-inline-block my-auto fs-16 fs-sm-18 fw-400">{icon}</span></>)
    case "Paxos":
      return (<><img className="mx-2" src={Paxos} /><span className="d-inline-block my-auto fs-16 fs-sm-18 fw-400">{icon}</span></>)
    default:
      return (<><img className="mx-2" src={Ethereum} /><span className="d-inline-block my-auto fs-16 fs-sm-18 fw-400">{icon}</span></>)
  }
}