import React from 'react'
import { useTranslation } from 'react-i18next';

import GovernanceImg from "assets/images/governance_1.png"

const GovIntro = () => {
  const { t } = useTranslation('governance');

  return (
    <>
      <div className="card card-custom-2 mb-5">
        <div className="text-center fs-16 fs-sm-18 fw-400">
        {t('intro.content1')}<br /><br />
          {t('intro.content2')}<br />
          {t('intro.content3')}
        </div>
      </div>
      <div className="row pt-4">
        <div className="col-12 col-lg-6">
          <dl className="mb-5">
            <dt className="fs-20 fs-sm-22 fs-md-24 fs-lg-28 fw-700 mb-4"><div dangerouslySetInnerHTML={{__html: t('intro.guide-normal-title')}} /></dt>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-normal-content1')}</span></dd>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-normal-content2')}</span></dd>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-normal-content3')}</span></dd>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-normal-content4')}</span></dd>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-normal-content5')}</span></dd>
            <dd className="fs-16 fs-sm-18 fw-400 mt-4"><span>{t('intro.guide-normal-notice')}</span></dd>
          </dl>
          <dl className="mb-5">
            <dt className="fs-20 fs-sm-22 fs-md-24 fs-lg-28 fw-700 mb-4"><div dangerouslySetInnerHTML={{__html: t('intro.guide-excution-title')}} /></dt>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-excution-content1')}</span></dd>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-excution-content2')}</span></dd>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-excution-content3')}</span></dd>
            <dd className="fs-14 fs-sm-16 fw-400 mb-0"><span>•  {t('intro.guide-excution-content4')}</span></dd>
            <dd className="fs-16 fs-sm-18 fw-400 mt-4"><span>{t('intro.guide-excution-notice')}</span></dd>
          </dl>
        </div>
        <div className="col-12 col-lg-6 px-5 px-md-0 mb-4 mb-lg-0 text-center text-lg-end order-first order-lg-last">
          <img src={GovernanceImg} alt="governance" />
        </div>
      </div>
    </>
  )
}

export default GovIntro
