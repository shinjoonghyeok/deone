import React from 'react'
import { useTranslation } from 'react-i18next';
import { useHistory } from "react-router-dom";
import useMaker from "hooks/useMaker";

const GovMain = () => {
  const { t } = useTranslation('governance');
  let history = useHistory();
  const { daiAccount } = useMaker();

  let isWalletConnect = true;
  if(daiAccount == null) {
    isWalletConnect = false;
  }

  const gotoJoinVote = () => {
    history.push("/governance")
  }
  const gotoWalletConnect = () => {
    history.push("/walletConnect");
  }

  return (
    <>
      <div className="text-center px-3 px-md-0">
        <h1 className="fs-30 fs-sm-36 fs-md-42 fs-lg-48 fw-700 mb-4">{ t('main.governance-main-title') }</h1>
        <p className="fs-16 fs-sm-18 fw-400 mb-3">
          { t('main.governance-main-sub') }
          <br/>
          <span className="fc-855cea">{ t('main.governance-main-vote') }</span>
        </p>
      </div>
      <div className="text-center mb-5 pb-4">
        { isWalletConnect &&
          <button className="btn btn-primary" onClick={gotoJoinVote}>{ t('btn.join-vote') }</button>
        }
        { !isWalletConnect &&
          <button className="btn btn-primary" onClick={gotoWalletConnect}>{ t('btn.make-wallet') }</button>
        }
      </div>
    </>
  )
}

export default GovMain
