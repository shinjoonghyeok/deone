import React from 'react'
import { useTranslation } from 'react-i18next';

import { statusURL } from "references/config"

const GovStatus = () => {
  const { t } = useTranslation('governance');

  let savingRate = 0.05;
  let deployDone = 5191386930;
  let debtListmi = 6665020501;
  let remainLimit = 1565020501;

  const gotoStatusPage = () => {
    window.open(statusURL)
  }

  return (
    <>
      <div className="card card-custom-2 mb-3">
        <div className="row text-center">
          <dl className="col-12 col-sm-6 col-md-3 mx-auto my-2 my-md-0">
            <dt className="fs-16 fs-sm-18 fw-400"><span>{ t('status.saving-rate') }</span></dt>
            <dd className="fs-18 fs-sm-20 fs-md-22 fs-lg-24 fw-700 fc-855cea mb-0"><span>{savingRate}%</span></dd>
          </dl>
          <dl className="col-12 col-sm-6 col-md-3 mx-auto my-2 my-md-0">
            <dt className="fs-16 fs-sm-18 fw-400"><span>{ t('status.deploy-done') }</span></dt>
            <dd className="fs-18 fs-sm-20 fs-md-22 fs-lg-24 fw-700 fc-855cea mb-0"><span>{deployDone}</span></dd>
          </dl>
          <dl className="col-12 col-sm-6 col-md-3 mx-auto my-2 my-md-0">
            <dt className="fs-16 fs-sm-18 fw-400"><span>{ t('status.debt-limit') }</span></dt>
            <dd className="fs-18 fs-sm-20 fs-md-22 fs-lg-24 fw-700 fc-855cea mb-0"><span>{debtListmi}</span></dd>
          </dl>
          <dl className="col-12 col-sm-6 col-md-3 mx-auto my-2 my-md-0">
            <dt className="fs-16 fs-sm-18 fw-400"><span>{ t('status.remain-limit') }</span></dt>
            <dd className="fs-18 fs-sm-20 fs-md-22 fs-lg-24 fw-700 fc-855cea mb-0"><span>{remainLimit}</span></dd>
          </dl>
        </div>
      </div>
      <div className="text-center mb-5 pb-4">
        <button className="btn btn-primary btn-outline" onClick={gotoStatusPage}>{t('btn.show-done-status')}</button>
      </div>
    </>
  )
}

export default GovStatus
