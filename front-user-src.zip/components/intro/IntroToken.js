import React from 'react'
import { useTranslation } from 'react-i18next';

import DoneIcon from "assets/images/about_2.png"
import MCTIcon from "assets/images/about_3.png"

const IntroToken = () => {
  const { t } = useTranslation('intro');

  return (
    <section className="sec-02 pb-5">
      <div className="container pb-5">
        <div className="row">
          <div className="col-12 col-lg-3 mb-3 mb-lg-0">
            <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-0">{ t('token.token-util') }</h1>
            <p className="fs-16 fs-sm-18 fw-400 mb-4">{ t('token.token-util-sub') }</p>
          </div>
          <div className="col-12 col-lg-9">
            <div className="row">
              <div className="col-12 col-md-6 mb-5 mb-md-0">
                <div className="row mb-3">
                  <div className="col-auto">
                    <img src={DoneIcon} alt="DeOne" />
                  </div>
                  <div className="col-auto">
                    <p className="fs-16 fs-sm-18 fw-400 mb-1">{ t('token.stable-coin') }</p>
                    <h4 className="fs-20 fs-sm-24 fw-700">{ t('token.done') }</h4>
                  </div>
                </div>
                <div className="common-box-1">
                  <p className="fs-14 fs-sm-16">
                    { t('token.done-content1') }
                    <br /><br />
                    { t('token.done-content2') }
                  </p>
                </div>
              </div>
              <div className="col-12 col-md-6 mb-5 mb-md-0">
                <div className="row mb-3">
                  <div className="col-auto">
                    <img src={MCTIcon} alt="MCT" />
                  </div>
                  <div className="col-auto">
                    <p className="fs-16 fs-sm-18 fw-400 mb-1">{ t('token.gov-token') }</p>
                    <h4 className="fs-20 fs-sm-24 fw-700">{ t('token.mct') }</h4>
                  </div>
                </div>
                <div className="common-box-1">
                  <p className="fs-14 fs-sm-16">
                    { t('token.mct-content1') }
                    <br /><br />
                    { t('token.mct-content2') }
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default IntroToken
