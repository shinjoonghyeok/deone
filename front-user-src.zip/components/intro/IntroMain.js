import React from 'react'
import { useTranslation } from 'react-i18next';

import { statusURL } from "references/config"
import DeOneIntroImg from "assets/images/about_1.png"

const IntroMain = () => {
  const { t } = useTranslation('intro');

  const gotoStatusPage = () => {
    window.open(statusURL)
  }

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row">
          <div className="col-12 text-center px-3 px-md-0">
            <h1 className="fs-30 fs-sm-36 fs-md-42 fs-lg-48 fw-700 mb-4">{ t('main.title') }</h1>
            <div className="fs-16 fs-sm-18 fw-400 mb-4">
              <div dangerouslySetInnerHTML={{__html: t('main.content1')}} />
              <br /><br />
              <div dangerouslySetInnerHTML={{__html: t('main.content2')}} />
            </div>
            <div className="text-center">
              <button onClick={gotoStatusPage} className="btn btn-primary">{t('btn.show-status')}</button>
            </div>

            <div className="img-wrap my-4 px-5 px-md-0">
              <img src={DeOneIntroImg} className="img_100" alt="DeOne" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default IntroMain
