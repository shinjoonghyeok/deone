import React, {useContext, useState} from 'react'
import { useTranslation } from 'react-i18next';
import { SavingProductInfo } from "layouts/SavingLayout"

const SavingRequestBTN = () => {
  const { t } = useTranslation('saving');
  const { savingValue, savingDispatch } = useContext(SavingProductInfo);

  const startDeposit = () => {
    savingDispatch({"type":"STATUS", "value":"startDeposit"});
  }

  const startWithdraw = () => {
    savingDispatch({"type":"STATUS", "value":"startWithdraw"});
  }

  return (
    <>
      <div className="row mb-4 mx-0">
        <button onClick={startDeposit} className="col btn btn-primary me-2">{t('btn.deposit')}</button>
        <button onClick={startWithdraw} className="col btn btn-primary btn-outline">{t('btn.withdraw')}</button>
      </div>
    </>
  )
}

export default SavingRequestBTN
