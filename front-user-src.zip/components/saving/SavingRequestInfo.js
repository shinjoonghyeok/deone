import React from 'react'
import { useTranslation } from 'react-i18next';

import DeOneSymbolBig from "assets/images/ico_d2.png"

const SavingRequestInfo = ({interestRate, savingAmount}) => {
  const { t } = useTranslation('saving');
  
  const interestRevenue = "0.00"

  const accountStyle = {
    height: "60px"
  }

  return (
    <>
      <h2 className="fs-16 fs-sm-18 fw-400 mb-4">{ t('request.my-account') }</h2>
      <p className="d-flex justify-content-center mb-4" style={accountStyle}>
        <img className="my-auto me-1" src={DeOneSymbolBig} alt="DeOne" />
        <span className="fs-36 fw-700 fc-855cea">{savingAmount.toFixed(2)}</span>
      </p>
      <p className="fs-16 fs-sm-18 fw-400 mb-0"><span>{t('request.avg-interest-rate')} : </span><span>{parseFloat(interestRate).toFixed(2)}</span><span>%</span></p>
      <p className="fs-16 fs-sm-18 fw-400 mb-5"><span>{t('request.interest-revenu')} : </span><span>{interestRevenue}</span><span>%</span></p>
    </>
  )
}

export default SavingRequestInfo
