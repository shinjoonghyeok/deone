import React, {useContext} from 'react'
import { useTranslation } from 'react-i18next';

import { SavingProductInfo } from "layouts/SavingLayout"
import SavingSuccessImg from "assets/images/complete_1.png"

const SavingRequestSuccess = ({method}) => {
  const { t } = useTranslation('saving');
  const { savingValue, savingDispatch } = useContext(SavingProductInfo);

  const gotoSavingProdPage = () => {
    savingDispatch({"type":"DEPOSIT", "value":0})
    savingDispatch({"type":"WITHDRAW", "value":0})
    savingDispatch({"type":"STATUS", "value":"ready"});
  }

  let resultTitle = t('request.deposit-complete');
  let resultStr = t('request.deposit');
  let resultAmount = savingValue.depositAmount;
  if(method === "completeWithdraw") {
    resultTitle = t('request.withdraw-complete');
    resultStr = t('request.withdraw');
    resultAmount = savingValue.withdrawAmount;
  }

  return (
    <>
      <h2 className="fs-20 fs-sm-24 fs-md-28 fw-700 mb-3 lh-base">
        <div dangerouslySetInnerHTML={{__html: t('request.saving-result-success', {resultStr, resultAmount})}} />
      </h2>
      <div className="mb-5">
        <img src={SavingSuccessImg} alt="success" />
      </div>
      <div>
        <button onClick={ gotoSavingProdPage } className="btn btn-primary">{t('btn.check-account')}</button>
      </div>
    </>
  )
}

export default SavingRequestSuccess