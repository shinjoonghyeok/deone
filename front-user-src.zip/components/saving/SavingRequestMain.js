import React, {useContext, useState} from 'react'
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";

import { SavingProductInfo } from "layouts/SavingLayout"
import useMaker from "hooks/useMaker";

import { defaultValues } from "utils/deOne"
import { showWalletTokens } from "references/config"

import SavingRequestInfo from 'components/saving/SavingRequestInfo';
import SavingRequestBTN from 'components/saving/SavingRequestBTN';
import SavingRequestList from 'components/saving/SavingRequestList';

import SavingRequestDepositStart from "components/saving/SavingRequestDepositStart"
import SavingRequestDepositCheck from "components/saving/SavingRequestDepositCheck"

import SavingRequestWithdrawStart from "components/saving/SavingRequestWithdrawStart"
import SavingRequestWithdrawCheck from "components/saving/SavingRequestWithdrawCheck"

import SavingRequestSuccess from "components/saving/SavingRequestSuccess"
import LoadingProgress from 'components/common/LoadingProgress';

const SavingRequestMain = () => {
  const { t } = useTranslation('saving');
  let history = useHistory();
  const { savingValue, savingDispatch } = useContext(SavingProductInfo);
  const { maker, watch, daiAccount } = useMaker();

  const [savingAmount, setSavingAmount] = useState(0);
  const [interestRate, setInterestRate] = useState(0);

  const symbols = showWalletTokens.filter(v => v !== 'DSR');
  const dsrBalance = watch.daiLockedInDsr(daiAccount?.address);
  const tokenBalances = watch.tokenBalances(daiAccount?.address, symbols);

  const tbs = tokenBalances?.reduce(
    (acc, tokenBalance) => {
      acc[tokenBalance.symbol] = tokenBalance.toBigNumber().toLocaleString();
      return acc;
    },
    { DSR: dsrBalance?.toBigNumber().toLocaleString() }
  ) || defaultValues;

  let balance = "";
  balance = tbs["ETH"];
  let userToken = "";
  userToken = parseFloat(tbs["DAI"]);

  const service = maker.service('mcd:savings');
  const getYearlyRate = async () => {
    let rate = await service.getYearlyRate();
    rate = rate * 100;
    setInterestRate(rate.toString())
  }
  const getUserSavingAmount = async () => {
    let savingBalance = await service.balance();
    setSavingAmount(savingBalance.toNumber());
  }

  if(daiAccount !== null) {
    getYearlyRate();
    getUserSavingAmount()
  }

  let topTitle = t('request.saving-title');
  switch(savingValue.status) {
    case "ready":
      topTitle = t('request.saving-title');
    break;
    case "startDeposit":
    case "checkDeposit":
    case "transactionDeposit":
      topTitle = t('request.deposit-title');
    break;
    case "startWithdraw":
    case "checkWithdraw":
    case "transactionWithdraw":
      topTitle = t('request.withdraw-title');
    break;
    case "completeDeposit":
      topTitle = t('request.deposit-complete');
    break;
    case "completeWithdraw":
      topTitle = t('request.withdraw-complete');
    break;
    default:
      topTitle = t('request.saving-title');
    break;
  }

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row pb-2 mb-4">
          <div className="col-12 text-center px-3 px-md-0">
            <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-0">{topTitle}</h1>
          </div>
        </div>
        <div className="row pb-2 mb-4">
          <div className="col-12 card card-custom-1 mx-auto text-center">
            
            { (savingValue.status !== "completeDeposit" && savingValue.status !== "completeWithdraw") && 
              <SavingRequestInfo interestRate={interestRate} savingAmount={savingAmount} />
            }
            

            { (savingValue.status === "ready") &&
              <>
                <SavingRequestBTN />
                <SavingRequestList userToken={userToken} />
              </>
            }

            { (savingValue.status === "startDeposit") && 
              <SavingRequestDepositStart userToken={userToken} />
            }
            { (savingValue.status === "checkDeposit") && 
              <SavingRequestDepositCheck />
            }

            { (savingValue.status === "startWithdraw") && 
              <SavingRequestWithdrawStart savingAmount={savingAmount} />
            }
            { (savingValue.status === "checkWithdraw") && 
              <SavingRequestWithdrawCheck />
            }

            
            { (savingValue.status === "transactionDeposit" || savingValue.status === "transactionWithdraw") && 
              <div className="text-center">
                <LoadingProgress str={t('request.check-transaction')} />
              </div>
            }
            { (savingValue.status === "completeDeposit" || savingValue.status === "completeWithdraw") && 
              <div className="text-center">
                <SavingRequestSuccess method={savingValue.status} />
              </div>
            }
          </div>
        </div>
      </div>
    </section>
  )
}

export default SavingRequestMain
