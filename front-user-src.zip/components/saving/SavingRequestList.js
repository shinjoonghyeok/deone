import React, {useState} from 'react'
import { useTranslation } from 'react-i18next';

import DeOneSymbolSmall from "assets/images/ico_d3.png"
import SavingRequestListItem from 'components/saving/SavingRequestListItem';

import useMaker from "hooks/useMaker"

// import 'react-perfect-scrollbar/dist/css/styles.css';
import PerfectScrollbar from 'react-perfect-scrollbar'

const SavingRequestList = ({userToken}) => {
  const { t } = useTranslation('saving');

  const [eventHistory, setEventHistory] = useState([]);

  const { maker, watch, daiAccount } = useMaker();

  const getEventHistory = async () => {
    let proxyAddress = watch.proxyAddress(daiAccount?.address);
    if(typeof proxyAddress === "undefined") proxyAddress = null;

    if(proxyAddress!==null) {
      let eventList = await maker.service('mcd:savings').getEventHistory(proxyAddress);
      setEventHistory(eventList);
    }
  }
  getEventHistory();

  const savingList = eventHistory.map((item, index) => {
    return <SavingRequestListItem key={index} type={item.type} amount={item.amount} date={item.timestamp} />
  })

  return (
    <>
      <dl className="mb-0">
        <div className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('request.recent-transaction')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0">
            <span>Balance : </span><span className="me-1">{userToken.toFixed(2)}</span><img src={DeOneSymbolSmall} alt="DeOne" />
          </dd>
        </div>
        <div className="card card-custom-2 mb-0">
          <div>
            <PerfectScrollbar>
              {savingList}
            </PerfectScrollbar>
          </div>
        </div>
      </dl>
    </>
  )
}

export default SavingRequestList
