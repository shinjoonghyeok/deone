import React from 'react'
import { useTranslation } from 'react-i18next';
import Moment from 'react-moment';

const SavingRequestListItem = ({type, amount, date}) => {
  const { t } = useTranslation('saving');

  let unit = "+";
  if(type=="DSR_WITHDRAW") unit="-";

  return (
    <dd className="mb-0">
      <div className="d-flex justify-content-between">
        <div className="col-auto">
          <p className="fs-16 fs-sm-18 fw-400 mb-0"><span className="d-inline-block text-start me-2 w-70px">{t(`request.${type}`)}</span><span><Moment unix format="YY-MM-DD HH:mm">{date}</Moment></span></p>
        </div>
        <div className="col-auto">
          <p className="fs-16 fs-sm-18 fw-400 fc-855cea mb-0"><span>{unit}</span><span>{parseFloat(amount).toFixed(2)}</span></p>
        </div>
      </div>
    </dd>
  )
}

export default SavingRequestListItem
