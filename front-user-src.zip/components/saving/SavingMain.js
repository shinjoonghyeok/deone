import React, {useState} from 'react'
import { useTranslation } from 'react-i18next';
import { useHistory } from "react-router-dom";

import useMaker from 'hooks/useMaker'

import SavingMainImg from "assets/images/saving_1.png"

const SavingMain = () => {
  const  { t } = useTranslation('saving');
  let history = useHistory();

  const { maker, watch, daiAccount } = useMaker();
    const [interestRate, setInterestRate] = useState(0);

  let proxyAddress = watch.proxyAddress(daiAccount?.address);
  const tokenSymbol = "DAI";
  const allowance = watch.tokenAllowance(
    daiAccount?.address,
    proxyAddress || undefined,
    tokenSymbol
  );
  const hasAllowance = allowance !== undefined && allowance !== null && !allowance.eq(0);
  if(typeof proxyAddress === "undefined") proxyAddress = null;

  const savingStyle = {
    "marginBottom": "-0.5rem"
  }

  const minGuarantee = 200;
  const minSavingAmount = 5000;
  
  const service = maker.service('mcd:savings');
  const getYearlyRate = async () => {
    let rate = await service.getYearlyRate();
    rate = rate * 100;
    setInterestRate(rate.toFixed(2).toString())
  }
  getYearlyRate();

  const gotoMakeProxy = () => {
    history.push("/walletSetting")
  }
  const gotoSavingDone = () => {
    history.push("/savingRequest")
  }

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row">
          <div className="col-12 text-center px-3 px-md-0">
            <h1 className="fs-30 fs-sm-36 fs-md-42 fs-lg-48 fw-700 mb-4">{ t('main.saving-main-title') }</h1>
            <p className="fs-12 fs-md-14 fs-md-16 fs-lg-18 fw-500 fc-855cea" style={savingStyle}>
              { t('main.saving-sub-intro1', {minGuarantee, minSavingAmount}) }
            </p>

            <div dangerouslySetInnerHTML={{__html: t('main.saving-now-intro', {interestRate})}} className="fs-20 fs-sm-24 fs-md-30 fs-lg-36 fw-400 mb-3" />

            <p className="fs-14 fs-md-16 fs-md-18 fw-400 mb-3">{ t('main.saving-sub-intro2') }</p>
            
            <div className="text-center mb-5">
              {
                ( proxyAddress === null && !hasAllowance ) &&
                <button className="btn btn-primary" onClick={ gotoMakeProxy }>{ t('btn.make-wallet') }</button>
              }
              {
                ( proxyAddress === null && hasAllowance ) &&
                <button className="btn btn-primary" onClick={ gotoMakeProxy }>{ t('btn.make-wallet') }</button>
              }
              {
                ( proxyAddress !== null && !hasAllowance ) &&
                <button className="btn btn-primary" onClick={ gotoMakeProxy }>{ t('btn.make-wallet') }</button>
              }
              {
                ( proxyAddress !== null && hasAllowance ) &&
                <button className="btn btn-primary" onClick={ gotoSavingDone }>{ t('btn.saving-done') }</button>
              }
            </div>

            <div className="text-center">
              <img src={SavingMainImg} alt="Saving" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default SavingMain
