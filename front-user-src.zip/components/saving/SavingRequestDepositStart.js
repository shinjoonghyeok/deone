import React, {useContext, useState} from 'react'
import { useTranslation } from 'react-i18next';

import { SavingProductInfo } from "layouts/SavingLayout"
import DeOneSymbolSmall from "assets/images/ico_d3.png"

const SavingRequestDepositStart = ({userToken}) => {
  const { t } = useTranslation('saving');
  const { savingValue, savingDispatch } = useContext(SavingProductInfo);
  const [inputAmount, setInputAmount] = useState(0);

  let showBalance = userToken.toString();

  const prevStep = () => {
    savingDispatch({"type":"STATUS", "value":"ready"});
  }

  const changeInputAmount = (e) => {
    const limitAmount = showBalance

    let userInputAmount = e.target.value
    if(Number(e.target.value) > Number(limitAmount)) userInputAmount = limitAmount;

    setInputAmount(userInputAmount)
    savingDispatch({"type":"DEPOSIT", "value":Number(userInputAmount)})
  }

  const setMaxAmount = () => {
    const limitAmount = showBalance

    setInputAmount(limitAmount)
    savingDispatch({"type":"DEPOSIT", "value":Number(limitAmount)})
  }

  const checkDeposit = () => {
    if(savingValue.depositAmount <= 0) {
      alert(t("msg.invalid-amount"));
      return;
    }

    savingDispatch({"type":"STATUS", "value":"checkDeposit"});
  }

  return (
    <>
      <dl className="mb-4">
        <div className="row justify-content-between mb-2">
          <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('request.deposit-done-amount')}</dt>
          <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0">
            <span>Balance : </span><span className="me-1">{showBalance.toLocaleString()}</span><img src={DeOneSymbolSmall} alt="DeOne" />
          </dd>
        </div>
        <dd className="input-group">
          <input type="number" className="form-control form-custom-1 fs-sm-24" placeholder="" aria-label="" value={inputAmount} onChange={changeInputAmount} />
          <span className="input-group-text form-label-custom-1">
            <button className="badge badge-custom-2 my-auto" onClick={() => {setMaxAmount()}}>MAX</button>
          </span>
        </dd>
      </dl>
      <div className="row mx-0">
        <button onClick={prevStep} className="col btn btn-primary btn-outline me-2">{t('btn.prev')}</button>
        <button onClick={checkDeposit} className="col btn btn-primary ">{t('btn.next')}</button>
      </div>
    </>
  )
}

export default SavingRequestDepositStart
