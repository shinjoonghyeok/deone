import React, {useContext, useState} from 'react'
import { useTranslation } from 'react-i18next';

import useMaker from "hooks/useMaker"
import BigNumber from 'bignumber.js';

import { SavingProductInfo } from "layouts/SavingLayout"

const SavingRequestWithdrawCheck = () => {
  const { t } = useTranslation('saving');
  const { savingValue, savingDispatch } = useContext(SavingProductInfo);
  const { maker } = useMaker();

  const transactionFee = 0.0042

  const savingProcess = async () => {
    let savingAmount = new BigNumber(savingValue.withdrawAmount).shiftedBy(18).toString();
    savingAmount = parseFloat(savingAmount);

    const service = maker
      .service('mcd:savings')
      .exit(savingAmount);
    
    const txMgr = maker.service('transactionManager');
    txMgr.listen(service, {
      pending: tx => {
        savingDispatch({"type":"STATUS", "value":"transactionWithdraw"});
        console.log("pending", tx)
      }, 
      mined: tx => {
        savingDispatch({"type":"STATUS", "value":"completeWithdraw"});
        console.log("minted", tx)
      },
      confirmed: () => {
        console.log("confirmed")
      },
      error: () => {
        savingDispatch({"type":"WITHDRAW", "value":0})
        savingDispatch({"type":"STATUS", "value":"startWithdraw"})
        console.log("ERROR")
      }

    });
    await txMgr.confirm(service, 1);
  }

  const transactionWithdraw = async () => {
    await savingProcess();
  }

  return (
    <>
      <button className="col btn btn-primary mb-5" onClick={transactionWithdraw}>{t('btn.check-withdraw-fee')}</button>
      <dl className="row justify-content-between mb-0">
        <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('request.transaction-fee')}</dt>
        <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{transactionFee}</span><span>ETH</span></dd>
      </dl>
    </>
  )
}

export default SavingRequestWithdrawCheck
