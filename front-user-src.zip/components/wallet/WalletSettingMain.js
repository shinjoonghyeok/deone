import React, {useContext} from 'react'
import { useTranslation } from "react-i18next";

import { WalletInfo } from "layouts/WalletLayout"
import useMaker from 'hooks/useMaker'

import BulletImg1 from "assets/images/ico_num_01.png"
import BulletImg2 from "assets/images/ico_num_02.png"
import LoadingProgress from 'components/common/LoadingProgress';

const WalletSettingMain = ({proxyAddress, hasAllowance}) => {
  const { t } = useTranslation('wallet');
  const { walletValue, walletDispatch } = useContext(WalletInfo);
  const { maker, daiAccount } = useMaker();

  const transactionFee = "0.0042";
  const transactionUnit = "ETH"


  const checkFee = () => {
    walletDispatch({"type":"STATUS", "value":"check"})
  }
  const createProxy = async () => {
    walletDispatch({"type":"STATUS", "value":"precreate"})
    /////////////////////////////////////
    const txPromise = maker.service('proxy').ensureProxy();
    const txMgr = maker.service('transactionManager');
    txMgr.listen(txPromise, {
      pending: tx => {
        walletDispatch({"type":"STATUS", "value":"creating"})
        console.log("pending", tx)
      }, 
      mined: tx => {
        walletDispatch({"type":"STATUS", "value":"created"})
          console.log("minted", tx)
      },
      confirmed: () => {
        console.log("confirmed")
      },
      error: () => {
        walletDispatch({"type":"STATUS", "value":"ready"})
        console.log("ERROR")
      }
    });

    await txMgr.confirm(txPromise, 10);
    //////////////////////////////////////////
  }
  const allowGrant = async () => {
    walletDispatch({"type":"STATUS", "value":"pregrant"})
    console.log("proxyAddress", proxyAddress)
    //////////////////////////////////////////
    const token = maker
      .getToken("DAI")
      .approveUnlimited(proxyAddress)

    const txMgr = maker.service('transactionManager');
    txMgr.listen(token, {
      pending: tx => {
        walletDispatch({"type":"STATUS", "value":"grantting"})
        console.log("pending", tx)
      }, 
      mined: tx => {
        walletDispatch({"type":"STATUS", "value":"granted"})
        console.log("minted", tx)
      },
      confirmed: () => {
        console.log("confirmed")
      },
      error: () => {
        walletDispatch({"type":"STATUS", "value":"created"})
        console.log("ERROR")
      }

    });
    await txMgr.confirm(token, 1);
    //////////////////////////////////////////
  }

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row pb-2 mb-4">
          <div className="col-12 text-center px-3 px-md-0">
            <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-0">{t('main-wallet-setting')}</h1>
          </div>
        </div>

        <div className="row pb-2 mb-4">
          <div className="col-12 card card-custom-1 mx-auto">
            <dl>
              <div className="row justify-content-between">
                <dt className="col-auto fs-16 fs-sm-18 fw-500 mb-3">
                  <img className="me-1" src={BulletImg1} alt="one"/>
                  <span>{t('setting.create-proxy')}</span>
                </dt>
                <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-2">{t('setting.create-proxy-desc')}</dd>
              </div>
            </dl>
            
            {
              (walletValue.status === "ready") &&
              <button className="btn btn-primary mb-4" onClick={checkFee}>{t('btn.check-fee')}</button>
            }
            
            {
              (walletValue.status === "check") &&
              <>
              <button className="btn btn-primary mb-4" onClick={createProxy}>{t('btn.create-proxy')}</button>
              <dl className="row justify-content-between mb-2">
                  <dt className="col-auto fs-16 fs-sm-18 fw-400">{t('setting.transaction-fee')}</dt>
                  <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-0"><span>{transactionFee}</span><span>{transactionUnit}</span></dd>
              </dl>
              </>
            }

            {
              (walletValue.status === "precreate" || walletValue.status === "pregrant" || walletValue.status === "created" || walletValue.status === "grantting" || walletValue.status === "granted" || walletValue.status === "complete") && 
              <button className="btn btn-inactive mb-4">{t('btn.create-proxy')}</button>
            }

            {
              (walletValue.status === "creating") &&

              <>
              <div className="text-center">
                <LoadingProgress str={t('setting.check-transaction')} />
              </div>
              </>
            } 


            {
              (walletValue.status === "created" || walletValue.status === "pregrant" || walletValue.status === "grantting" || walletValue.status === "granted" || walletValue.status === "complete") &&
              <>
              <dl>
                <div className="row justify-content-between">
                  <dt className="col-auto fs-16 fs-sm-18 fw-500 mb-3">
                    <img className="me-1" src={BulletImg2} alt="two"/>
                    <span>{t('setting.setting-grant')}</span>
                  </dt>
                  <dd className="col-auto fs-16 fs-sm-18 fw-400 mb-2">{t('setting.setting-grant-desc')}</dd>
                </div>
              </dl>
              </>
            }

            {
              (walletValue.status === "created") &&
              <button className="btn btn-primary" onClick={allowGrant}>{t('btn.setting-grant')}</button>
            }


            {
              (walletValue.status === "pregrant") && 
              <button className="btn btn-inactive">{t('btn.setting-grant')}</button>
            }

            {
              (walletValue.status === "grantting") &&
              <>
              <div className="text-center">
                <LoadingProgress str={t('setting.check-grant')} />
              </div>
              </>
            }

            {
              (walletValue.status === "granted" || walletValue.status === "complete") &&
              <>
              <button className="btn btn-primary mt-2">{t('btn.setting-complete')}</button>
              </>
            }


          </div>
        </div>
      </div>
    </section>
  )
}

export default WalletSettingMain
