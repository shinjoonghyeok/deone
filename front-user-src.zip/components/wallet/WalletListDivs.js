import React, {useCallback} from 'react'
import {NotificationContainer} from 'react-notifications';
import { getWebClientProviderName } from 'utils/web3';

import useMaker from "hooks/useMaker"

const WalletListDivs = ({id, name, icon, setWalletTry, setWalletInfo}) => {
  const { maker, connectBrowserProvider } = useMaker();
  const providerName = getWebClientProviderName();

  const onAccountChosen = useCallback(
    async ({ address }, type) => {
      maker.useAccountWithAddress(address);
    },
    [maker]
  );
  
  const connectWallet = async (id, name, icon) => {
    if(id==="metamask") {
      setWalletInfo({id, name, icon})
      setWalletTry("waiting");
      // activate(injected)
      try {
        const connectedAddress = await connectBrowserProvider();
        onAccountChosen({ address: connectedAddress }, providerName);
      } catch (err) {
        window.alert(err.message);
        setWalletTry("disconnect");
      }
    }
    else {
      window.alert("Not Support");
    }
  }
  return (
    <>
      <li>
        <a className="cursor-pointer" onClick={() => (connectWallet(id, name, icon))}>
          <span className="me-auto">{name}</span>
          <img src={icon} alt={id} />
        </a>
      </li>
      
      <NotificationContainer />
    </>
    
  )
}

export default WalletListDivs
