import React from 'react'
import { useTranslation } from "react-i18next";
import { CopyToClipboard } from 'react-copy-to-clipboard'
import {NotificationContainer, NotificationManager} from 'react-notifications';

import useMaker from "hooks/useMaker"
import { AccountDisplay } from 'components/common/CommonFunction'
import { NetworkNames } from "references/config"

import CopyImg from "assets/images/ico_copy.png"
import SendImg from "assets/images/ico_send.png"

const MyWalletInfo = () => {
  const { t } = useTranslation('wallet');

  const { daiAccount, disconnect } = useMaker();
  const logoutWallet = () => {
    disconnect();
  }

  const gotoEtherscan = () => {
    console.log(daiAccount);
    let etherscanUrl = "https://";
    if(daiAccount.networkID!==1) {
      etherscanUrl += NetworkNames[daiAccount.networkID] + ".";
    }
    etherscanUrl += `etherscan.io/address/${daiAccount.address}`
    window.open(etherscanUrl, '_blank');
  }

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row pb-2 mb-4">
          <div className="col-12 text-center px-3 px-md-0">
            <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-0">{ t('connect.my-wallet-title') }</h1>
          </div>
        </div>
        <div className="row pb-2 mb-4">
          <div className="col-12 con_box mx-auto">
            <div className="con_box_2">
              <ul>
                <li className="position-relative">
                  <p className="fs-16 fs-sm-18 fw-400 mb-3">{t('my-wallet.wallet-metamask')} {t('my-wallet.connected-wallet')}</p>
                  <button className="btn btn-small btn-primary btn-outline rounded-pill position-absolute end-20" onClick={() => {logoutWallet()}}><span>{ t('btn.change-wallet') }</span></button>
                  <div className="mb-2 fs-20 fs-sm-24 fw-700 fc-855cea">
                    <AccountDisplay account={daiAccount?.address} />
                    {/* <img src="/res/images/ico_ball.png" /><span className="fs-20 fs-sm-24 fw-700 fc-855cea">0x9DFF...92c0</span> */}
                  </div>
                  <div>
                    <CopyToClipboard text={daiAccount?.address}>
                      <a href="#" onClick={() => (NotificationManager.info(t('my-wallet.copy-complete')))}><img src={CopyImg} alt="copy" /><span className="link-hover">{ t('btn.copy-address') }</span></a>
                    </CopyToClipboard>
                    <a href="#" onClick={gotoEtherscan}><img src={SendImg} alt="send" /><span className="link-hover">{ t('btn.show-etherscan') }</span></a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-12 con_box mx-auto text-center">
            <p className="fs-14 fs-sm-16 fw-400 mb-0">최근 거래 이력이 없습니다.</p>
          </div>
        </div>
      </div>

      <NotificationContainer/>
    </section>
  )
}

export default MyWalletInfo
