import React, {useState, useEffect} from 'react'
import { useTranslation } from "react-i18next";

import MetaMaskImg from "assets/images/ico_loan_11.png"
import WalletConnectImg from "assets/images/ico_loan_12.png"
import CoinbaseImg from "assets/images/ico_loan_13.png"
import FormaticImg from "assets/images/ico_loan_14.png"
import PortisImg from "assets/images/ico_loan_15.png"
import MEWImg from "assets/images/ico_loan_16.png"
import TrezorImg from "assets/images/ico_loan_17.png"
import LedgerImg from "assets/images/ico_loan_18.png"

import useMaker from "hooks/useMaker";

import WalletListDivs from "components/wallet/WalletListDivs"
import LoadingProgress from 'components/common/LoadingProgress';

const WalletList = () => {
  const { t } = useTranslation('wallet');

  const [walletTry, setWalletTry] = useState("disconnect");
  const [walletInfo, setWalletInfo] = useState({"id":null,"name":null,"icon":null})
  const { daiAccount } = useMaker();

  useEffect(() => {
    if(daiAccount != null) {
      setWalletTry("connected")
    }
    else {
      console.log("disconnect")
    }
  }, [daiAccount])

  

  let walletList = [
    { "id":"metamask","name": "Install Metamask", "icon": MetaMaskImg },
    { "id":"walletconnect","name": "WalletConnect", "icon": WalletConnectImg },
    { "id":"coinbase","name": "Coinbase wallet", "icon": CoinbaseImg },
    { "id":"formatic","name": "Formatic", "icon": FormaticImg },
    { "id":"portis","name": "Portis", "icon": PortisImg },
    { "id":"mew","name": "My Ether Wallet", "icon": MEWImg },
    { "id":"trezor","name": "Trezor", "icon": TrezorImg },
    { "id":"ledger","name": "Ledger", "icon": LedgerImg }
  ];

  const walletDivs = walletList.map((item, idx) => (<WalletListDivs key={idx} id={item.id} name={item.name} icon={item.icon} setWalletTry={setWalletTry} setWalletInfo={setWalletInfo} />))

  return (
    <section className="sec-01 py-3">
      <div className="container">
        <div className="row pb-2 mb-4">
          <div className="col-12 text-center px-3 px-md-0">
            <h1 className="fs-30 fs-sm-32 fs-md-34 fs-lg-36 fw-700 mb-0">{t('connect.wallet-connect-title')}</h1>
          </div>
        </div>
        <div className="row pb-2 mb-4">
          <div className="col-12">
            <div className="con_box mx-auto">
              { walletTry === "disconnect" &&
                <div className="con_box_1">
                  <ul>
                    {walletDivs}
                  </ul>
                </div>
              }
              { walletTry === "waiting" &&
                <>
                <div className="con_box_tit">
                  <div className="d-inline-block">
                    <LoadingProgress str={t('connect.wallet-init')}/>
                  </div>
                </div>
                <div className="con_box_1">
                  <ul>
                    <li>
                    <div href="#" className="box d-flex">
                      <div className="col me-auto">
                        <p className="d-block fc-855cea mb-0">Metamask</p>
                        <p className="d-block txt-info fs-12 mb-0">Easy-to-use browser extension</p>
                      </div>
                      <img className="m-auto" src={MetaMaskImg} alt="MetaMask" />
                    </div>
                    </li>
                  </ul>
                </div>
                </>
              }

              
            </div>
        </div>
      </div>
    </div>
  </section>
  )
}

export default WalletList
