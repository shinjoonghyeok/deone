const nav = {
  "intro-done": "DeOne",
  "loan-prod": "Loan",
  "saving-prod": "Saving",
  "governance": "Governance"  
}

export default nav;