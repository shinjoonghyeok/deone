export { default as main } from './main';
export { default as nav } from './nav';

export { default as footer } from './footer';
// export { default as footer } from './footer';