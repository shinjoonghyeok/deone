const governance = {
  "main-governance": "거버넌스",
  "main-governance-join-normal": "일반투표",
  "main-governance-join-excution": "집행투표",
  "main": {
    "governance-main-title": "디원 거버넌스에 오신 것을 환영합니다.",
    "governance-main-sub": "엠씨티(MCT) 홀더만이 투표에 참여할 수 있으며, 투표에 참여하려면 월렛을 연동해야 합니다.",
    "governance-main-vote": "탈중앙화된 자율 조직의 중요 의사결정을 위한 투표에 참가하세요."
  },
  "status": {
    "saving-rate": "저축이자율",
    "deploy-done": "총 발행된 디원",
    "debt-limit": "부채한도",
    "remain-limit": "잔여한도",
  },
  "intro": {
    "content1": "디원 프로토콜의 여러 중요의사 결정을 하는 거버넌스는 엠씨티(MCT) 홀더들의 투표를 통해 이루어 집니다.",
    "content2": "투표 참여에는 엠씨티(MCT) 토큰이 필요하며, 자신이 보유한 엠씨티(MCT)를 전송하여 \"잠금\"을 해야 합니다.",
    "content3": "투표 참여를 위해 잠금된 엠씨티(MCT)수량에 따라 가중치가 부여되어 이루어지며, 잠금된 엠씨티(MCT)는 언제든지 \"잠금해제\" 할 수 있습니다.",
    "guide-normal-title": "<span class=\"fc-855cea\">일반투표</span><span>로 이루어지는 사안들</span>",
    "guide-normal-content1": "중요한 커뮤니티 목표 및 목표에 대한 합의를 형성",
    "guide-normal-content2": "잠재적인 Excutive 투표 안건에 대한 반응을 측정",
    "guide-normal-content3": "포험에서 시작된 거버넌스 제안을 승인",
    "guide-normal-content4": "Excutive 투표에서 확인되기 전, 특정 시스템 매개변수를 설정 값을 결정",
    "guide-normal-content5": "위험 관리팀이 제시한 새로운 담보 유형에 대한 위험 매개 변수를 승인",
    "guide-normal-notice": "일반투표는 매주 월요일 16:00 UTC에 실시간 온체인에서 진행 됩니다.",

    "guide-excution-title": "<span class=\"fc-855cea\">집행투표</span><span>로 이루어지는 사안들</span>",
    "guide-excution-content1": "자료 유형을 추가하거나 제거",
    "guide-excution-content2": "담보대출 상품 계좌의 유형을 추가하거나 제가",
    "guide-excution-content3": "글로별 시스템 매개 변수를 조정",
    "guide-excution-content4": "담보대출 상품 계좌 관련 매개 변수를 조정",
    "guide-excution-notice": "집행투표는 매주 금요일 16:00 UTC에 실시간 온체인에서 진행 됩니다."
  },
  "vote": {
    "normal-vote": "일반투표",
    "excution-vote": "집행투표",
    "normal-vote-desc": "집행투표를 실시하기 전에 제안된 안건에 대해 대략적인 협의를 도출하기 위해 투표가 실시됩니다.",
    "excution-vote-desc": "집행투표는 뭐라뭐라 블라블라 blabla 라고 하는 투표 입니다.",
    "review": "검토",
    "vote-address": "투표주소",
    "done-saving-rate": "디원 저축율",
    "done-total-amount": "총 디원수량",
    "done-loan-limit": "디원 부채한도",
    "done-loan-remain": "남은 부채",
    "agree": "찬성",
    "disagree": "반대",
    "abandon": "기권",
    "total-vote-count": "총 투표수",
    "vote-user": "투표자수",
    "vote": "투표",
    "end-vote": "투표종료"
  },
  "btn": {
    "make-wallet": "월렛 연동(생성)하기",
    "join-vote": "투표 참가하기",
    "show-done-status": "디원 현황보기",
    "show-propose": "제안보기",
    "vote-mct": "{{voteSum}} MCT 투표",
    "history-vote": "모든트표로 돌아가기",
    "next-vote": "다음투표",
    "prev-vote": "이전투표"
  }
}

export default governance;