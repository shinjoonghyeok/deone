const intro = {
  "home": "홈",
  "main-intro-done": "디원소개",
  "main": {
    "title": "안정화된 디지털 화폐 '디원'을 소개합니다.",
    "content1": "‘디원’은 가격변동에 노출된 암호화폐를 담보로, 스테이블코인 디원(Done)을 발행하는 대출 서비스로 <br class=\"d-none d-md-block\">특정 주체가 아닌 개인들이 개별적으로 디원을 발행할 수 있습니다.",
    "content2": "<span class=\"fc-855cea\">디원 프로토콜에서 담보대출계좌를 개설하면 승인된 암호화폐를 담보로 <br class=\"d-none d-md-block\">디원을 대출받아 여러 탈 중앙화 금융서비스에서</span> 사용 할 수 있습니다.",
  },
  "token": {
    "token-util": "토큰 유틸리티",
    "token-util-sub": "Token Utility",
    "stable-coin": "스테이블 코인",
    "done": "디원(DeONE)",
    "done-content1": "스테이블 코인인 디원(DeONE)은 원화 (1,000)원에 소프트 페깅 되어졌습니다.",
    "done-content2": "디원(DeONE)은 개인의 암호화폐 자산을 담보로 디원 프로토콜에서 자동 생성되어집니다.",
    "gov-token": "거버넌스 토큰",
    "mct": "엠씨티(MCT)",
    "mct-content1": "거버넌스 토큰 엠씨티(MCT)는 발행 및 소각을 통해 스테이블 코인인 디원(DeONE)의 가격 안정화에 기여하며, 청산을 통해서도 복구가 불가능한 악성채무를 엠씨티(MCT)를 발행하여 해결합니다.",
    "mct-content2": "1MCT는 한표와 동일하며, 중요 정책을 결정하기 위한 시스템 의사결정 참여를 위해 사용합니다."
  },
  "btn": {
    "show-status": "디원 현황보기"
  }
}

export default intro;