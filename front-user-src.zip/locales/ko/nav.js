const nav = {
  "intro-done": "디원소개",
  "loan-prod": "대출상품",
  "saving-prod": "저축상품",
  "governance": "거버넌스",
  "btn": {
    "make-wallet": "월렛 연동하기"
  }
}

export default nav;
