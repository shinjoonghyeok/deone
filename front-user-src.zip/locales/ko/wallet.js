const wallet = {
  "home": "홈",
  "main-wallet": "월렛 연동하기",
  "main-wallet-setting": "월렛 설정하기",
  "main-my-wallet": "나월 월렛",
  "connect": {
    "wallet-connect-title": "월렛 연동하기",
    "my-wallet-title": "나의 월렛",
    "wallet-init": "초기화중..."
  },
  "my-wallet": {
    "my-wallet-title": "나의 월렛",
    "no-trade-list": "최근 거래 이력이 없습니다.",
    "connected-wallet": "연결 되었습니다.",
    "wallet-metamask": "메타마스크로",
    "copy-complete": "복사 했습니다."
  },
  "setting": {
    "create-proxy": "프록시 생성하기",
    "create-proxy-desc": "저축 및 다른기능을 사용하기 위해서는 월렛 프록시 생성이 필요 합니다.",
    "transaction-fee": "트랜잭션 수수료",
    "check-transaction": "트랜잭션 확인중...",
    "setting-grant": "권한 설정하기",
    "check-grant": "권한 설정중...",
    "setting-grant-desc": "이 권한은 디원 사이트가 월렛에 있는 디원과 상호작용할 수 있도록 합니다.",
    "transaction-fee-check": "트랜잭션 수수료를 확인해 주세요.",
    "proxy-allow": "담보 유형 권한 설정",
    "proxy-allow-desc": "이 설정을 통해 {{prodSymbol}}와 상호 작용 할 수 있습니다. 새로운 담보 유형에 대해 한번씩 수행되어야 합니다."
  },
  "btn": {
    "copy-address": "주소복사",
    "show-etherscan": "이더스캔 보기",
    "change-wallet": "지갑 변경",
    "create-proxy": "프록시 생성하기",
    "check-fee": "수수료 확인 및 생성하기",
    "setting-grant": "권한 설정하기",
    "setting-complete": "월렛 설정완료",
    "setting-allow": "권한 설정하기"
  }

}

export default wallet;