const main = {
  "home": "홈",
  "intro": {
    "done-title": "안정화된 디지털 화폐<br class=\"d-block d-md-none\" /> '디원'",
    "done-content": "디원은 안정적인 원화 가치를 추구하는 디지털 화폐로써,<br class=\"d-none d-sm-block\" /> 탈중앙화된 생태계에서 누구나 경험할 수 있습니다.",
    "done-subtitle": "국내최초 중립을 추구하는<br class=\"d-block d-md-none\" /> 안정적인 화폐",
    "done-subcontent": "디원은 사용자들을 위해 차별없는<br class=\"d-none d-sm-block\" />탈중앙화된 화폐로 안정적인 가치를 추구합니다."
  },
  "service": {
    "done-service": "디원 서비스",
    "done-service-sub": "DeONE Service",
    "intro-done": "디원소개",
    "intro-done-content": "디파이 실현을 위한 월렛 플랫폼을 <br />통해 디원을 경험하세요.",
    "loan-prod": "대출상품",
    "loan-prod-content": "더 많은 투자기회 확보를 <br />위해 담보대출을 이용해보세요.",
    "saving-prod": "저축상품",
    "saving-prod-content": "저축을 통해 안전화된 <br />자산관리를 경험하세요.",
    "governance": "거버넌스",
    "governance-content": "탈중앙화의 의사결정 <br />직접 투표하고 의사결정하세요."
  },
  "support": {
    "done-support": "지원서비스",
    "done-support-sub": "support Sservice",
    "support-bb-title": "쉽고 안전한 개인용 멀티 암호화폐 결제 지갑",
    "support-bb-content": "암호화폐 노드 직접 운영 및 관리를 통한 <br class=\"pc_only\" />안정적인서비스",
    "support-bs-title": "차세대 디파이 탈중앙거래소 서비스",
    "support-bs-content": "이더리움 네트워크를 이용한 <br class=\"pc_only\" />스마트컨트랙트로 구현된 탈중앙 거래소"
  },
  "partner": {
    "done-partner": "파트너사",
    "done-partner-sub": "Our Partners"
  },
  "external": {
    "done-external": "외부 지원 서비스",
    "done-external-sub": "External Support Service"
  },
  "btn": {
    "deploy-done": "디원 발행하기",
    "movie-done": "디원 영상보기",
    "goto": "바로가기",
    "make-bb-wallet": "비트베리 월렛 만들기",
    "goto-bs": "비트베리스왑 바로가기" 
  }
}

export default main;