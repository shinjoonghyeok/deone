const loan = {
  "home": "홈",
  "main-loan-prod": "대출상품",
  "main-loan-request": "대출신청",
  "main-loan-wallet-settig": "월렛 설정",
  "main-loan-add-request": "추가대출신청",
  "main-wallet-setting": "월렛 설정하기",
  "notlogin": {
    "welcome-loan": "대출상품 서비스에 오신것을 환영합니다.",
    "content1": "디원 프로토콜에서 담보대출계좌를 개설하면 승인된 암호화폐를 담보로 <br class=\"d-none d-md-block\">스테이블코인 디원(DONE)을 대출받아 여러 탈 중앙화 금융서비스에서 사용 할 수 있습니다.",
    "content2": "더 많은 투자 기회 확보를 위해 담보대출을 이용해보세요."
  },
  "logined": {
    "welcome-loan-old": "나의 대출 현황: <span class='font-bold text-purple-500'>{{loanAmount}}</span>",
    "welcome-loan": "나의 대출 현황: ",
  },
  "prod-top": {
    "done-title": "디원(DeONE)",
    "top-new": "신규 대출 상품",
    "top-best": "최고 인기 상품",
    "top-low": "최저 이자율 상품"
  },
  "prod-list": {
    "borrow": "담보",
    "kind": "종류",
    "done-count": "발행가능한 디원개수",
    "fix-fee": "안정화 수수료",
    "risk-rate": "위험비율 대비",
    "request-loan": "대출신청",
    "deny-loan": "대출불가",
    "user-balance": "잔액"
  },
  "user-prod-list": {
    "guarantee":"담보",
    "guarantee-amount":"담보수량",
    "avail-deone-count":"발행한 디원개수",
    "now-price":"현재가격",
    "risk-rate":"위험비율 대비",
    "no-prod": "상품이 없습니다."
  },
  "loan-guide": {
    "title": "담보대출 안내",
    "title-sub": "Mortgage Loan",
    "borrow-rate": "담보비율",
    "borrow-rate-content": "담보물인 암호화폐가 가격 변동성이 높은 자산인 만큼, 개인이 발행할 DeONE의 총액보다 훨씬 많은 가치의 담보물을 맡겨야 하며, 각 담보대출 상품 마다 다른 최소담보비율이 적용됩니다.",
    "loadn-limit": "대출한도",
    "loadn-limit-content": "각 담보대출 상품마다 대출한도가 있어, 대출한도에 다다른 담보대출상품에서는 대출이 불가능합니다.",
    "loan-fee": "대출수수료",
    "loan-fee-content": "비 수탁성이므로 대출계좌에 입금된 담보는 안전하게 보관되며, 보관된 담보는 대출한 DeONE을 상환하고, 계약된 대출 수수료를 지불하면 돌려주게 됩니다.",
    "clear-fee": "청산수수료",
    "clear-fee-content": "만약, 담보율의 시장가격이 하락하여, 맡겨진 담보의 비율이 최소담보비율이하로 하락하면, 해당 계좌에 있는 담보물은 스마트 계약에 의해서 강제적으로 경매를 통해 청산 과정에 들어가며, 계약된 청산수수료가 발생합니다. <br />경매 후, 대출금과 청산수수료를 상환하고 남은 담보물(암호화폐)은 사용자에게 돌려주게 됩니다."
  },
  "loan-request":{
    "request-title": "대출신청",
    "guarantee-amount":"담보가능수량",
    "lock-amount": "담보수량",
    "available-gen-amount": "발행가능 디원수량",
    "loan-amount": "디원 대출수량",
    "total-avail-done": "총 대출가능 디원수량",
    "user-avail-done": "대출 가능 디원수량",
    "guarantee-rate": "담보비율",
    "loan-fee": "대출수수료",
    "adjust-fee": "정산수수료",
    "transaction-fee": "트랜잭션 수수료",
    "check-transaction": "트랜잭션 확인중...",
    "finish-unit": "디원이",
    "finish-string": "성공적으로 발행되었습니다.",
    "complete-title": "대출 완료",
    "request-add-title": "추가 대출 신청",
    "loan-complete": "<span class=\"fc-855cea\">{{loanAmount}}</span><span class=\"fc-855cea\"> 디원</span>이 <br class=\"d-none d-md-block\" />성공적으로 발행되었습니다."
  },
  "btn": {
    "make-wallet": "월렛 연동(생성)하기",
    "not-enought-gurantee": "담보 잔액이 부족합니다.",
    "request-loan": "대출 신청하기",
    "excute-transaction": "수수료 확인 및 트랜젝센 실행",
    "check-account": "잔고 확인하기",
    "loan-add": "추가대출",
    "loan-request": "대출신청",
    "loan-deny": "대출불가",
    "add-lock": "추가 담보",
    "add-generate": "추가 대출",
    "request-add-lock": "추가 담보 신청하기",
    "request-add-generate": "추가 대출 신청하기"
  }
}

export default loan;