const saving = {
  "home": "홈",
  "main-saving-prod": "저축상품",
  "main-saving-wallet": "월렛설정하기",
  "main-saving-request": "디원 저축하기",
  "main-wallet-setting": "월렛 설정하기",
  "main": {
    "saving-main-title": "저축상품 서비스에 오신것을 환영합니다.",
    "saving-sub-intro1": "최소 보증금 {{minGuarantee}}원, 최소 저축금액 {{minSavingAmount}}원",
    "saving-now-intro": "현재 디원의 연이자율은 <span class=\"fc-855cea fw-700\">{{interestRate}} %</span> 입니다.",
    "saving-sub-intro2": "언제든 저축과 출금이 가능한 디원 저축 서비스를 이용해 보세요.",
  },
  "wallet": {
    "create-proxy": "프록시 생성하기",
    "create-proxy-desc": "저축 및 다른기능을 사용하기 위해서는 월렛 프록시 생성이 필요 합니다.",
    "transaction-fee": "트랜잭션 수수료",
    "check-transaction": "트랜잭션 확인중...",
    "setting-grant": "권한 설정하기",
    "setting-grant-desc": "이 권한은 디원 사이트가 월렛에 있는 디원과 상호작용할 수 있도록 합니다."
  },
  "request": {
    "my-account": "나의 저축 계좌",
    "avg-interest-rate": "연 평균이자율",
    "interest-revenu": "저축이자수익",
    "recent-transaction": "최근 거래내역",
    "saving-title": "디원 저축하기",
    "deposit-title": "입금하기",
    "withdraw-title": "출금하기",
    "deposit-complete": "입금완료",
    "withdraw-complete": "출금완료",
    "deposit": "입금",
    "withdraw": "출금",
    "loan": "담보대출",
    "deposit-done-amount": "입금할 디원 수량",
    "transaction-fee": "트랜잭션 수수료",
    "check-transaction": "트랜잭션 확인중...",
    "check-grant": "권한 부여중...",
    "saving-result-success": "<span class=\"fc-855cea\">{{resultAmount}}</span><span class=\"fc-855cea\"> 디원</span>이 <br class=\"d-none d-md-block\" />성공적으로 {{resultStr}}되었습니다.",
    "DSR_DEPOSIT": "입금",
    "DSR_WITHDRAW": "출금",
    "withdraw-done-amount": "출금할 디원 수량"
  },
  "msg": {
    "invalid-amount": "금액을 확인 해 주세요."
  },
  "btn": {
    "make-wallet": "월렛 연동(생성)하기",
    "config-wallet": "월렛 설정하기",
    "saving-done": "디원 저축하기",
    "create-proxy": "프록시 생성하기",
    "check-deposit-fee": "수수료 확인 및 입금하기",
    "check-withdraw-fee": "수수료 확인 및 출금하기",
    "setting-grant": "권한 설정하기",
    "wallet-complete": "월렛 설정완료",
    "deposit": "입금하기",
    "withdraw": "출금하기",
    "next": "다음으로",
    "check-account": "잔고 확인하기",
    "prev": "이전으로"
  }
}

export default saving;