export { default as nav } from './nav';
export { default as footer } from './footer';
export { default as common } from './common';

export { default as main } from './main';
export { default as intro } from './intro';
export { default as loan } from './loan';
export { default as saving } from './saving';
export { default as governance } from './governance';

export { default as wallet } from './wallet';
