const common = {
  "main-notice": "공지사항",
  "main-private-policy": "개인정보처리방침",
  "main-use-term": "이용약관",
  "main-service-manual": "서비스 메뉴얼",
  "main-contact-us": "Contact",
  "private-policy": {
    "title": "개인정보 처리방침"
  },
  "use-term": {
    "title": "이용약관"
  },
  "service-manual": {
    "title": "서비스 메뉴얼"
  },
  "contact": {
    "title": "Contact"
  },
  "notice": {
    "title": "공지사항",
    "nt-seq": "No",
    "nt-title": "제목",
    "nt-date": "등록일"
  },
  "error": {
    "notfound-title": "페이지를 찾을 수 없습니다.",
    "notfound-description": "찾고 있는 페이지가 없거나 존재하지 않습니다. <br />웹 주소가 올바른지 다시 확인해 주세요.",
    "no-support-network": "지원하지 않는 네트워크 입니다."
  },
  "btn": {
    "goto-home": "홈으로 가기"
  },
  "loading": {
    "initialize": "초기화중...",
    "plz-wait": "잠시만 기다려 주십시오."
  }
}

export default common;