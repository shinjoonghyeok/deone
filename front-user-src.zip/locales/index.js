import * as localeKo from './ko';
import * as localeEn from './en';

export const ko = { ...localeKo };
export const en = { ...localeEn };

const language = { ko, en };

export default language;