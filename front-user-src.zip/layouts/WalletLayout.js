import React, {useReducer} from 'react'
import { useTranslation } from 'react-i18next';

import { defaultValues } from "utils/deOne"
import { showWalletTokens } from "references/config"
import useMaker from 'hooks/useMaker'
import ilkList from "references/ilkList"

export const WalletInfo = React.createContext();

const initWalletValue = {
  status: "ready",
  account: null,
  proxyAddress: null,
  hasAllowance: false
}
const reducer = (state, action) => {
  switch (action.type) {
    case "STATUS":
      return {
        ...state,
        status: action.value
    }
    case "ACCOUT":
      return {
        ...state,
        account: action.value
    }
    default:
      return {
        ...state
      }
  }
}

const WalletLayout = ( {children} ) => {
  const  { t } = useTranslation('loan');
  const { maker, watch, daiAccount } = useMaker();
  const [state, walletDispatch] = useReducer(reducer, initWalletValue);

  initWalletValue.account = daiAccount;
  
  let proxyAddress = watch.proxyAddress(daiAccount?.address);
  const tokenSymbol = "DAI";
  const allowance = watch.tokenAllowance(
    daiAccount?.address,
    proxyAddress || undefined,
    tokenSymbol
  );
  const hasAllowance = allowance !== undefined && allowance !== null && !allowance.eq(0);
  if(typeof proxyAddress === "undefined") proxyAddress = null;
  
  initWalletValue.proxyAddress = proxyAddress;
  initWalletValue.hasAllowance = hasAllowance;

  if(proxyAddress!==null) {
    if(hasAllowance) initWalletValue.status = "complete";
    else initWalletValue.status = "created";
    
  }

  return (
    <React.Fragment>
      <WalletInfo.Provider value={{ walletValue: state, walletDispatch }}>
        { children }
      </WalletInfo.Provider>
    </React.Fragment>
  )
}

export default WalletLayout
