import React, {useReducer} from 'react'
import { useTranslation } from 'react-i18next';

import { defaultValues } from "utils/deOne"
import { showWalletTokens } from "references/config"
import useMaker from 'hooks/useMaker'
import ilkList from "references/ilkList"

export const DeOneProductList = React.createContext();

const initRequestValue = {
  productList: [],
  selectedProd: ""
}
const reducer = (state, action) => {
  switch (action.type) {
    case "PRODUCTLIST":
      return {
        ...state,
        productList: action.value
    }
    case "SELECTEDPROD":
      return {
        ...state,
        selectedProd: action.value
    }
    default:
      return {
        ...state
      }
  }
}

const ProductLayout = ( {children} ) => {
  const  { t } = useTranslation('loan');
  const { watch, daiAccount } = useMaker();

  const symbols = showWalletTokens.filter(v => v !== 'DSR');
  const dsrBalance = watch.daiLockedInDsr(daiAccount?.address);
  const tokenBalances = watch.tokenBalances(daiAccount?.address, symbols);

  const tbs = tokenBalances?.reduce(
    (acc, tokenBalance) => {
      acc[tokenBalance.symbol] = tokenBalance.toBigNumber().toLocaleString();
      return acc;
    },
    { DSR: dsrBalance?.toBigNumber() }
  ) || defaultValues;

  const cdpTypesList = ilkList.map(x => x.key);
  const collateralTypesData = watch.collateralTypesData(cdpTypesList);

  let prodList = [];
  if(typeof collateralTypesData != "undefined" && collateralTypesData != null) {
    collateralTypesData.forEach((cdp) => {
      let inputObj = ilkList.find(x => x.symbol === cdp.symbol);
      inputObj.maxDoneCount = cdp.collateralDebtAvailable.toBigNumber().toFixed(2).toLocaleString();
      inputObj.stabilityFee = ( cdp.annualStabilityFee.toFixed(2).toLocaleString() ) * 100;
      inputObj.btn = t('btn.request-loan')
      inputObj.userBalance = parseFloat(tbs[inputObj.gem]).toFixed(2);
      inputObj.riskRate = ( cdp.liquidationRatio.toBigNumber().toFixed(2).toLocaleString() ) * 100 
      
      if(tbs[inputObj.gem] > 0) inputObj.btnStatus = true;
      else inputObj.btnStatus = false;
      prodList.push({...inputObj, ...cdp})
    })
  }
  initRequestValue.productList = prodList;

  const [state, productDispatch] = useReducer(reducer, initRequestValue);

  return (
    <React.Fragment>
      <DeOneProductList.Provider value={{ productValue: state, productDispatch }}>
        { children }
      </DeOneProductList.Provider>
    </React.Fragment>
    
  )
}

export default ProductLayout
