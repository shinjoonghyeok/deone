import React, {useReducer} from 'react'
import { useTranslation } from 'react-i18next';

export const SavingProductInfo = React.createContext();

const initSavingValue = {
  status: "ready",
  depositAmount: 0,
  withdrawAmount: 0,
}
const reducer = (state, action) => {
  switch (action.type) {
    case "STATUS":
      return {
        ...state,
        status: action.value
    }
    case "DEPOSIT":
      return {
        ...state,
        depositAmount: action.value
    }
    case "WITHDRAW":
      return {
        ...state,
        withdrawAmount: action.value
    }
    default:
      return {
        ...state
      }
  }
}

const SavingLayout = ( {children} ) => {
  const  { t } = useTranslation('loan');
  const [state, savingDispatch] = useReducer(reducer, initSavingValue);
  
  return (
    <React.Fragment>
      <SavingProductInfo.Provider value={{ savingValue: state, savingDispatch }}>
        { children }
      </SavingProductInfo.Provider>
    </React.Fragment>
  )
}

export default SavingLayout
