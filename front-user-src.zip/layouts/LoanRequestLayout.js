import React, {useReducer} from 'react'

export const LoanRequestInfo = React.createContext();

const initRequestValue = {
  guaranteeAmount: 0, 
  loanAmount: 0,
  maxLoanAmount: 0,
  transactionFee: 0,
  nowStatus: "ready",
  isLoanActive: false
}
const reducer = (state, action) => {
  switch (action.type) {
    case "GUARANTEE":
      return {
        ...state,
        guaranteeAmount: action.value
    }
    case "LOAN":
      return {
        ...state,
        loanAmount: action.value
    }
    case "MAXLOAN":
      return {
        ...state,
        maxLoanAmount: action.value
    }
    case "TRANSACTION":
      return {
        ...state,
        transactionFee: action.value
    }
    case "STATUS":
      return {
        ...state,
        nowStatus: action.value
    }
    case "LOANACTIVE":
      return {
        ...state,
        isLoanActive: action.value
    }
    default:
      return {
        ...state
      }
  }
}

const LoanRequestLayout = ( {children} ) => {
  const [state, loanRequestDispatch] = useReducer(reducer, initRequestValue);

  return (
    <React.Fragment>
      <LoanRequestInfo.Provider value={{ loanRequestValue: state, loanRequestDispatch }}>
        { children }
      </LoanRequestInfo.Provider>
    </React.Fragment>
    
  )
}

export default LoanRequestLayout
