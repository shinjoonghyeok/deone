import React, {useEffect} from 'react'
import { useLocation } from "react-router-dom";

import Navbar from "components/common/Navbar"
import Footer from "components/common/Footer"

const MainLayout = ( {children} ) => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <React.Fragment>
      <Navbar />
      <main>
        {children}
      </main>
      <Footer />
    </React.Fragment>
  )
}

export default MainLayout