import React from 'react'
import { NavLink, useHistory, useLocation } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import HomeIcon from 'assets/images/ico_nav.png'

import ProductLayout from "layouts/ProductLayout"
import WalletLayout from "layouts/WalletLayout"
import LoanRequestLayout from 'layouts/LoanRequestLayout';

import LoanAddRequestMain from "components/loan/LoanAddRequestMain"
import WalletSettingMain from "components/wallet/WalletSettingMain"

import ilkList from "references/ilkList"

import useMaker from 'hooks/useMaker'

const LoanAddRequest = () => {
  const { t } = useTranslation('loan');
  let history = useHistory();
  const location = useLocation();
  const { watch, daiAccount } = useMaker();

  if(typeof location.state === "undefined") {
    history.push("/")
  }

  if(daiAccount==null) {
    history.push("/walletConnect")
  }

  const vaultId = location.state.vaultId;
  const gem = location.state.gem;

  const userVaultsData = watch.userVaultsData([vaultId]);
  let vaultData = {}
  let productKey = "";
  let productInfo = {};
  if(typeof userVaultsData !== "undefined") {
    vaultData = userVaultsData[0]
    productKey = vaultData.vaultType;
    productInfo = ilkList.find(x => x.symbol === productKey);
  }

  let proxyAddress = watch.proxyAddress(daiAccount?.address);
  const tokenSymbol = "DAI";
  const allowance = watch.tokenAllowance(
    daiAccount?.address,
    proxyAddress || undefined,
    tokenSymbol
  );
  const hasAllowance = allowance !== undefined && allowance !== null && !allowance.eq(0);
  if(typeof proxyAddress === "undefined") proxyAddress = null;

  if(proxyAddress==null || !hasAllowance) {
    return (
      <main id="page-loan-products" className="min-vh-100">
        <div className="container px-5 py-3 fs-12">
          <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
          <span className="mx-2">/</span>
          <NavLink to="/walletSetting">{t('main-wallet-setting')}</NavLink>
        </div>
  
        <WalletLayout>
          <WalletSettingMain proxyAddress={proxyAddress} hasAllowance={hasAllowance} />
        </WalletLayout>
      </main>
    )
  }
  else {
    return (
      <main id="page-loan-products" className="min-vh-100">
        <div className="container px-5 py-3 fs-12">
          <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
          <span className="mx-2">/</span>
          <NavLink to="/loanProd">{t('main-loan-prod')}</NavLink>
          <span className="mx-2">/</span>
          <NavLink to="/loanProd">{t('main-loan-add-request')}</NavLink>
        </div>
  
        <ProductLayout>
          <LoanRequestLayout>
            <LoanAddRequestMain vaultData={vaultData} productKey={productKey} productInfo={productInfo} />
          </LoanRequestLayout>
        </ProductLayout>
      </main>
    )
  }
  
}

export default withTranslation("translations")(LoanAddRequest)
