import React from 'react'
import { NavLink } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import HomeIcon from 'assets/images/ico_nav.png'

import IntroMain from "components/intro/IntroMain"
import IntroToken from "components/intro/IntroToken"

const DeOneIntro = () => {
  const { t } = useTranslation('intro');

  return (
    <main id="page-about">
      <div className="container px-5 py-3 fs-12">
        <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
        <span className="mx-2">/</span>
        <NavLink to="/deOneIntro">{t('main-intro-done')}</NavLink>
      </div>

      <IntroMain />
      <IntroToken />
    </main>
  )
}

export default withTranslation("translations")(DeOneIntro)
