import React from 'react'

const GovernanceJoin = () => {
  return (
    <div>
      
    </div>
  )
}

export default GovernanceJoin
