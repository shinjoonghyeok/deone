import React from 'react'
import { withTranslation } from "react-i18next";

import Intro from "components/index/Intro"
import Service from "components/index/Service"
import Support from "components/index/Support"
import Partner from "components/index/Partner"
import External from "components/index/External"


const Index = () => {
  return (
    <main id="page-index">
      <Intro />
      <Service />
      <Support />
      <Partner />
      <External />
    </main>
  )
}

export default withTranslation("translations")(Index)