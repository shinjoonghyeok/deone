import React from 'react'
import { NavLink } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import HomeIcon from 'assets/images/ico_nav.png'

import NoticeView from "components/etc/NoticeView"

const NoticeList = () => {
  const { t } = useTranslation('common');

  return (
    <main id="page-loan-products" className="min-vh-100">
      <div className="container px-5 py-3 fs-12">
        <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
        <span className="mx-2">/</span>
        <NavLink to="/notice">{t('main-notice')}</NavLink>
      </div>

      <NoticeView />
    </main>
  )
}

export default withTranslation("translations")(NoticeList)