import React from 'react'
import { NavLink } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import HomeIcon from 'assets/images/ico_nav.png'

import SavingLayout from "layouts/SavingLayout"
import useMaker from "hooks/useMaker";

import SavingMain from "components/saving/SavingMain"


const SavingProd = () => {
  const { t } = useTranslation('saving');
  const { daiAccount } = useMaker();

  return (
    <main id="page-loan-products" className="min-vh-100">
      <div className="container px-5 py-3 fs-12">
        <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
        <span className="mx-2">/</span>
        <NavLink to="/savingProd">{t('main-saving-prod')}</NavLink>
      </div>

      <SavingLayout>
        <SavingMain />
      </SavingLayout>

      
    </main>
  )
}

export default withTranslation("translations")(SavingProd)
