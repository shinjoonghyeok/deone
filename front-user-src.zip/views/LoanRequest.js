import React from 'react'
import { NavLink, useHistory, useLocation } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import HomeIcon from 'assets/images/ico_nav.png'

import ProductLayout from "layouts/ProductLayout"
import WalletLayout from "layouts/WalletLayout"
import LoanRequestLayout from 'layouts/LoanRequestLayout';
import ilkList from "references/ilkList"

import LoanRequestMain from "components/loan/LoanRequestMain"
import WalletSettingMain from "components/wallet/WalletSettingMain"
import useMaker from "hooks/useMaker"

const LoanRequest = () => {
  const { t } = useTranslation('loan');
  let history = useHistory();
  const location = useLocation();

  const { watch, daiAccount } = useMaker();

  if(typeof location.state === "undefined") {
    history.push("/")
  }

  if(daiAccount==null) {
    history.push("/walletConnect")
  }

  const productKey = location.state.productKey;
  const productInfo = ilkList.find(x => x.symbol === productKey);

  let proxyAddress = watch.proxyAddress(daiAccount?.address);
  const tokenSymbol = "DAI";
  const allowance = watch.tokenAllowance(
    daiAccount?.address,
    proxyAddress || undefined,
    tokenSymbol
  );
  const hasAllowance = allowance !== undefined && allowance !== null && !allowance.eq(0);
  if(typeof proxyAddress === "undefined") proxyAddress = null;

  if(proxyAddress==null || !hasAllowance) {
    return (
      <main id="page-loan-products" className="min-vh-100">
        <div className="container px-5 py-3 fs-12">
          <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
          <span className="mx-2">/</span>
          <NavLink to="/walletSetting">{t('main-wallet-setting')}</NavLink>
        </div>
  
        <WalletLayout>
          <WalletSettingMain proxyAddress={proxyAddress} hasAllowance={hasAllowance} />
        </WalletLayout>
      </main>
    )
  }
  else {
    return (
      <main id="page-loan-products" className="min-vh-100">
        <div className="container px-5 py-3 fs-12">
          <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
          <span className="mx-2">/</span>
          <NavLink to="/loanProd">{t('main-loan-prod')}</NavLink>
          <span className="mx-2">/</span>
          <NavLink to="/loanProd">{t('main-loan-request')}</NavLink>
        </div>
  
        <ProductLayout>
          <LoanRequestLayout>
            <LoanRequestMain productKey={productKey} productInfo={productInfo} />
          </LoanRequestLayout>
        </ProductLayout>
        
      </main>
    )
  }

  

  
}

export default withTranslation("translations")(LoanRequest)
