import React from 'react'
import { NavLink } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import HomeIcon from 'assets/images/ico_nav.png'

import GovMain from "components/governance/GovMain"
import GovStatus from "components/governance/GovStatus"
import GovIntro from "components/governance/GovIntro"

const Governance = () => {
  const { t } = useTranslation('governance');

  return (
    <main id="page-loan-products" className="min-vh-100">
      <div className="container px-5 py-3 fs-12">
        <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
        <span className="mx-2">/</span>
        <NavLink to="/loanProd">{t('main-governance')}</NavLink>
      </div>

      <section className="sec-01 py-3">
        <div className="container">
          <GovMain />
          <GovStatus />
          <GovIntro />
        </div>
      </section>
    </main>
  )
}

export default withTranslation("translations")(Governance)
