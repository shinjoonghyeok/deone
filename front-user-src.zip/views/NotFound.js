import React from 'react'
import { useHistory } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import ErrorImg from "assets/images/none.png"

const NotFound = () => {
  const { t } = useTranslation('common');
  let history = useHistory();
  
  return (
    <main id="page-none" className="min-vh-100">
      <div className="section sec-01 py-5">
        <div className="container text-center">
            <img src={ErrorImg} alt="error" />
            <h1 className="fs-30 fs-sm-36 fs-md-42 fs-lg-48 fw-700 mb-4">{ t('error.notfound-title') }</h1>
            <div className="fs-16 fs-sm-18 fw-400">
              <div dangerouslySetInnerHTML={{__html:t('error.notfound-description')}} className="mb-5" />
            </div>
            <button onClick={ () => {history.push("/")}} className="btn btn-primary">{ t('btn.goto-home') }</button>
        </div>
      </div>
    </main>
  )
}

export default withTranslation("translations")(NotFound)
