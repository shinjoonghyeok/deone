import React, {useEffect} from 'react'
import { NavLink } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import HomeIcon from 'assets/images/ico_nav.png'
import useMaker from "hooks/useMaker"

import WalletList from "components/wallet/WalletList"
import MyWalletInfo from "components/wallet/MyWalletInfo"

const WalletConnect = () => {
  const { t } = useTranslation('wallet');
  const { daiAccount } = useMaker();

  let menuDisplay = [t('main-my-wallet')]
  if(daiAccount == null) menuDisplay = [t('main-wallet')]

  return (
    <main id="page-loan-wallet" className="min-vh-100">
      <div className="container px-5 py-3 fs-12">
        <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
        <span className="mx-2">/</span>
        <NavLink to="/walletConnect">{menuDisplay}</NavLink>
      </div>

      {
        (daiAccount == null) &&
        <WalletList />
      }

      {
        (daiAccount != null) &&
        <MyWalletInfo />
      }
    </main>
  )
}

export default withTranslation("translations")(WalletConnect)
