import React from 'react'
import { NavLink } from "react-router-dom";
import { useTranslation, withTranslation } from "react-i18next";

import HomeIcon from 'assets/images/ico_nav.png'

import SavingLayout from "layouts/SavingLayout"
import WalletLayout from "layouts/WalletLayout"
import useMaker from "hooks/useMaker";

import SavingRequestMain from "components/saving/SavingRequestMain"
import WalletSettingMain from "components/wallet/WalletSettingMain"

const SavingRequest = () => {
  const { t } = useTranslation('saving');
  const { watch, daiAccount } = useMaker();

  let proxyAddress = watch.proxyAddress(daiAccount?.address);
  const tokenSymbol = "DAI";
  const allowance = watch.tokenAllowance(
    daiAccount?.address,
    proxyAddress || undefined,
    tokenSymbol
  );
  const hasAllowance = allowance !== undefined && allowance !== null && !allowance.eq(0);
  if(typeof proxyAddress === "undefined") proxyAddress = null;

  if(proxyAddress==null || !hasAllowance) {
    return (
      <main id="page-loan-products" className="min-vh-100">
        <div className="container px-5 py-3 fs-12">
          <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
          <span className="mx-2">/</span>
          <NavLink to="/walletSetting">{t('main-wallet-setting')}</NavLink>
        </div>
  
        <WalletLayout>
          <WalletSettingMain proxyAddress={proxyAddress} hasAllowance={hasAllowance} />
        </WalletLayout>
      </main>
    )
  }
  else {
    return (
      <main id="page-loan-products" className="min-vh-100">
        <div className="container px-5 py-3 fs-12">
          <NavLink to="/"><img className="me-1" src={HomeIcon} alt="home" /><span>{ t('home') }</span></NavLink>
          <span className="mx-2">/</span>
          <NavLink to="/savingProd">{t('main-saving-request')}</NavLink>
        </div>
  
        <SavingLayout>
          <SavingRequestMain />
        </SavingLayout>
        
      </main>
    )
  }
  
}

export default withTranslation("translations")(SavingRequest)
