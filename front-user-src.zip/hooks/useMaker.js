import { useContext } from 'react';

import { MakerObjectContext } from 'providers/MakerProvider';

function useMaker() {
  const { 
    maker,
    watcher,
    multicall,
    watch,
    daiAccount,
    connectBrowserProvider,
    connectToProviderOfType,
    disconnect,
    txLastUpdate
  } = useContext(MakerObjectContext) || {};

  return {
    maker,
    watcher,
    multicall,
    watch,
    daiAccount,
    connectBrowserProvider,
    connectToProviderOfType,
    disconnect,
    txLastUpdate
  };
}

export default useMaker;
