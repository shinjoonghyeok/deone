import React, {useContext, useState, useEffect} from 'react'

import BigNumber from 'bignumber.js';
import { showWalletTokens } from "references/config"
import useMaker from 'hooks/useMaker'

const useBalance = () => {
  const { maker, watch } = useMaker();

  const defaultValues = showWalletTokens.reduce((acc, token) => {
    acc[token] = BigNumber(0);
    return acc;
  }, {});

  const [tbs, setTbs] = useState([]);

  useEffect(() => {
    console.log(maker.currentAccount())
    const account = maker.currentAccount();
    const symbols = showWalletTokens.filter(v => v !== 'DSR');

    const dsrBalance = watch.daiLockedInDsr(account?.address);
    const tokenBalances = watch.tokenBalances(account?.address, symbols);

    const inputtbs = tokenBalances?.reduce(
      (acc, tokenBalance) => {
        acc[tokenBalance.symbol] = tokenBalance.toBigNumber().toLocaleString();
        return acc;
      },
      { DSR: dsrBalance?.toBigNumber() }
    ) || defaultValues;  

    setTbs(inputtbs);
  }, [maker])

  return {tbs}
}

export default useBalance
