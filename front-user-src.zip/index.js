import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";

import "@fortawesome/fontawesome-free/css/all.min.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'assets/styles/style.css'
import 'assets/styles/style-responsive.css'
import 'assets/styles/deone.scss'

import { I18nextProvider } from 'react-i18next';
import i18n from 'i18n';

import 'react-notifications/lib/notifications.css';

import MakerProvider from "providers/MakerProvider"

import MainLayout from "layouts/MainLayout"

import Index from "views/Index";
import DeOneIntro from "views/DeOneIntro";

import LoanProd from "views/LoanProd";
import LoanRequest from "views/LoanRequest";
import LoanAddRequest from "views/LoanAddRequest";

import SavingProd from "views/SavingProd";
import SavingRequest from "views/SavingRequest";

import Governance from "views/Governance";
import GovernanceJoin from "views/GovernanceJoin"
// import GovernanceVote from "views/GovernanceVote"

import WalletConnect from "views/WalletConnect"
import WalletSetting from "views/WalletSetting"

import NoticeList from "views/NoticeList"
// import PrivatePolicy from "views/PrivatePolicy"
// import UseTerm from "views/UseTerm"
// import ServiceManual from "views/ServiceManual"
// import ContactUs from "views/ContactUs"

import NotFound from "views/NotFound";

ReactDOM.render(
  <MakerProvider>
    <I18nextProvider i18n={i18n}>
      <BrowserRouter>
        <Switch>
          <MainLayout>
            <Route path="/" exact component={Index} />
            <Route path="/deOneIntro" exact component={DeOneIntro} />
            
            <Route path="/loanProd" exact component={LoanProd} />
            <Route path="/loanRequest" exact component={LoanRequest} />
            <Route path="/loanAddRequest" exact component={LoanAddRequest} />
            
            <Route path="/savingProd" exact component={SavingProd} />
            <Route path="/savingRequest" exact component={SavingRequest} />

            <Route path="/governance" exact component={Governance} />
            <Route path="/governanceJoin" exact component={GovernanceJoin} />

            {/* <Route path="/governanceVote/:type/:idx/:prev/:next" exact component={GovernanceVote} /> */}

            <Route path="/walletConnect" exact component={WalletConnect} />
            <Route path="/walletSetting" exact component={WalletSetting} />

            <Route path="/notice" exact component={NoticeList} />
            
            {/* <Route path="/privatePolicy" exact component={PrivatePolicy} /> */}
            {/* <Route path="/useTerm" exact component={UseTerm} /> */}
            {/* <Route path="/serviceManual" exact component={ServiceManual} /> */}
            {/* <Route path="/contactUs" exact component={ContactUs} /> */}

            {/* <Route path="/notFount" exact component={NotFound} /> */}
            {/* <Route component={NotFound} /> */}
          </MainLayout>
          
          {/* <Redirect from="*" to="/notFount" /> */}
        </Switch>
        
      </BrowserRouter>
    </I18nextProvider>
  </MakerProvider>,
  document.getElementById("root")
);
