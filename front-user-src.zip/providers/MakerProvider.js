import React, { createContext, useState, useEffect, useCallback } from 'react';
import schemas from '@makerdao/dai-plugin-mcd/dist/schemas';
import PropTypes from 'prop-types';

import { instantiateMaker } from 'references/maker';
import { NetworkUrls, defaultNetwork } from 'references/config'
import LoadingProgress from 'components/common/LoadingProgress';
import Observable from "providers/Observable"
import {
  checkEthereumProvider,
  browserEthereumProviderAddress
} from 'utils/ethereum';
import { AccountTypes } from 'utils/constants';

export const MakerObjectContext = createContext();

const MakerProvider = ({children}) => {
  const [txLastUpdate, setTxLastUpdate] = useState({});
  const [account, setAccount] = useState(null);
  const [maker, setMaker] = useState(null);
  const [watcher, setWatcher] = useState(null);
  const [multicall, setMulticall] = useState(null);
  const [watch, setWatch] = useState({});
  const [daiAccount, setDaiAccount] = useState(null);
 
  const rpcUrl = NetworkUrls[defaultNetwork];

  const loadingProgress = 
    <div className="w-100 d-flex justify-content-center align-items-center min-vh-100">
      <LoadingProgress />
    </div>
  
  const initAccount = account => {
    setAccount({ ...account });
  };

  const removeAccounts = () => {
    maker.service('accounts')._accounts = {};
    maker.service('accounts')._currentAccount = '';
    setAccount(null);
    setDaiAccount(null);
  };

  const connectBrowserProvider = useCallback(async () => {
    const networkId = maker.service('web3').network;
    const browserProvider = await checkEthereumProvider();

    function getMatchedAccount(address) {
      return maker
        .listAccounts()
        .find(acc => acc.address.toUpperCase() === address.toUpperCase());
    }

    if (browserProvider.networkId !== networkId)
      throw new Error(
        'browser ethereum provider and URL network param do not match.'
      );
    if (
      !browserProvider.address ||
      !browserProvider.address.match(/^0x[a-fA-F0-9]{40}$/)
    )
      throw new Error(
        'browser ethereum provider providing incorrect or non-existent address'
      );

    let existingAccount;
    if (maker.service('accounts').hasAccount()) {
      existingAccount = getMatchedAccount(browserProvider.address);
      if (existingAccount) {
        console.log(`Using existing SDK account: ${existingAccount.address}`);
        maker.useAccountWithAddress(existingAccount.address);
      }
    }
    if (!existingAccount) {
      console.log('Adding new browser account to SDK');
      await maker.addAccount({
        type: 'browser',
        autoSwitch: true
      });
    }

    const connectedAddress = maker.currentAddress();
    
    ///browserProvider.networkId
    const connectedAccount = maker.currentAccount();
    setDaiAccount({networkID:browserProvider.networkId,  ...connectedAccount});

    return connectedAddress;
  }, [maker]);


  // provider 초기화
  useEffect(() => {
    (async () => {
      const newMaker = await instantiateMaker({ rpcUrl });
      // Register multicall schemas and map useObservable hook to watch convenience helper
      const multicall = newMaker.service('multicall');
      multicall.registerSchemas({ ...schemas });
      multicall.observableKeys.forEach(
        key => (watch[key] = (...args) => Observable(key, ...args))
      );
      // Create and start multicall watcher
      const watcher = multicall.createWatcher({ interval: 'block' });
      multicall.start();
      setWatcher(watcher);
      setMaker(newMaker);
      setMulticall(multicall);

      console.log('Initialized maker instance');
    })();
  }, []);
  //// chainId, account 바뀌었을때 고민을 해 보자.


  useEffect(() => {
    if (!maker) return;
    if (maker.service('accounts').hasAccount()) {
      initAccount(maker.currentAccount());
    } else {
      // Reconnect browser provider if active address matches last connected
      const lastType = sessionStorage.getItem('lastConnectedWalletType');
      if (lastType === 'browser') {
        const lastAddress = sessionStorage.getItem(
          'lastConnectedWalletAddress'
        );
        browserEthereumProviderAddress().then(activeAddress => {
          if (activeAddress === lastAddress) {
            console.log(
              `Reconnecting address: ${activeAddress} (matches last connected wallet address)`
            );
            connectBrowserProvider();
          }
        });
      }
    }

    maker.on('accounts/CHANGE', eventObj => {
      const { account } = eventObj.payload;
      // if (eventObj.sequence === 1)
      //   trackBtnClick(undefined, { fathom: { id: 'connectWallet' } });

      let preAccount = sessionStorage.getItem('lastConnectedWalletAddress');
      // console.log(preAccount)

      sessionStorage.setItem('lastConnectedWalletType', account.type);
      sessionStorage.setItem(
        'lastConnectedWalletAddress',
        account.address.toLowerCase()
      );
      // console.log(`Account changed to: ${account.address}`);
      initAccount(account);

      if(preAccount!==account.address.toLowerCase()) window.location.reload();
    });

    const txManagerSub = maker
      .service('transactionManager')
      .onTransactionUpdate((tx, state) => {
        if (state === 'mined') {
          const id = tx.metadata?.id;
          if (id) {
            console.log(`Resetting event history cache for Vault #${id}`);
            try {
              maker.service('mcd:cdpManager').resetEventHistoryCache(id);
            }
            catch {
              console.log("catch")
            }
            
            setTxLastUpdate(current => ({ ...current, [id]: Date.now() }));
          } else if (tx.metadata?.contract === 'PROXY_ACTIONS_DSR') {
            console.log('Resetting savings event history cache');
            maker.service('mcd:savings').resetEventHistoryCache();
            setTxLastUpdate(current => ({ ...current, save: Date.now() }));
          }
        }
        if (state === 'error') {
          console.log('Tx ' + state, tx.metadata);
          return;
        }
        console.log('Tx ' + state, tx.metadata);
      });
    return () => {
      txManagerSub.unsub();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [maker, connectBrowserProvider]);

  const connectToProviderOfType = async type => {
    if (!maker) return;
    if (maker.service('accounts').hasAccount()) {
      initAccount(maker.currentAccount());
    } else {
      const account = await maker.addAccount({
        type
      });
      maker.useAccountWithAddress(account.address);
    }
    const connectedAddress = maker.currentAddress();
    return connectedAddress;
  };

  const disconnectWalletLink = subprovider => subprovider.resetWallet();
  const disconnectWalletConnect = async subprovider =>
    (await subprovider.getWalletConnector()).killSession();
  const disconnectBrowserWallet = () =>
    ['lastConnectedWalletType', 'lastConnectedWalletAddress'].forEach(x =>
      sessionStorage.removeItem(x)
    );

  const disconnect = () => {
    const subprovider = maker.service('accounts').currentWallet();
    if (subprovider.isWalletLink) disconnectWalletLink(subprovider);
    else if (subprovider.isWalletConnect) disconnectWalletConnect(subprovider);
    else if (
      sessionStorage.getItem('lastConnectedWalletType') ===
      AccountTypes.METAMASK
    )
      disconnectBrowserWallet();
    removeAccounts();
  };

  return (
    <MakerObjectContext.Provider
      value={{
        maker,
        watcher,
        multicall,
        watch,
        daiAccount,
        connectBrowserProvider,
        connectToProviderOfType,
        disconnect,
        txLastUpdate
      }}
    >
      {maker ? children : loadingProgress}
    </MakerObjectContext.Provider>
  )
}

MakerProvider.propTypes = {
  network: PropTypes.string.isRequired
};

export default MakerProvider
