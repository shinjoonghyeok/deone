import BigNumber from 'bignumber.js';
import { Currency } from '@makerdao/currency';
import { showWalletTokens } from "references/config"

export const defaultValues = showWalletTokens.reduce((acc, token) => {
  acc[token] = BigNumber(0);
  return acc;
}, {});

export const decimalRules = {
  long: 6,
  medium: 4,
  short: 2
};

export const formatCurrencyValue = ({
  value,
  precision = decimalRules.short,
  percentage = false,
  integer = false,
  infinity = 'N/A',
  rounding = BigNumber.ROUND_DOWN
}) => {
  if (value instanceof Currency) value = value.toBigNumber();
  else if (!BigNumber.isBigNumber(value)) value = BigNumber(value);
  if (['Infinity', Infinity].includes(value.toFixed(precision)))
    return infinity;
  if (percentage) value = value.times(100);
  if (integer) value = value.integerValue(BigNumber.ROUND_HALF_UP);
  if (value.lt(1) && rounding === BigNumber.ROUND_DOWN) {
    precision = value.eq(0) ? decimalRules.short : decimalRules.medium;
  }
  return value.toFixed(precision, rounding);
};

export function formatter(target, options = {}) {
  return formatCurrencyValue({ value: target, ...options });
}

export function lookupCDPSafetyLevel(ratio, ilkLiqRatio) {
  const dangerThreshold = BigNumber(0.1)
    .times(ilkLiqRatio)
    .plus(ilkLiqRatio);
  const warningThreshold = BigNumber(0.5)
    .times(ilkLiqRatio)
    .plus(ilkLiqRatio);
  let level;
  if (ratio.lt(dangerThreshold)) level = "SAFETY_LEVELS.DANGER";
  else if (ratio.lt(warningThreshold)) level = "SAFETY_LEVELS.WARNING";
  else level = "SAFETY_LEVELS.SAFE";
  return { level, dangerThreshold, warningThreshold };
}