import axios from "axios";
import { apiBaseUrl } from "references/config"

export const deoneFetchAPI = async (method, targetUrl, paramsObj, dataObj, headersObj) => {
  console.log(apiBaseUrl);
  let retVal = null;
  try {
    const response = await axios({
      url: targetUrl,
      method: method,
      baseURL: apiBaseUrl,
      params: paramsObj,
      data: dataObj,
      headers: headersObj
    });
    retVal = response.data;
  }
  catch (e) {
    console.log("e",e);
  }
  return retVal;
}