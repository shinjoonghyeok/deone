export const deoneVideoID = "BWqcw4lWoBM";
export const defaultNetwork = "3";

export const statusURL = "http://13.209.11.161:3001";
export const apiBaseUrl = "http://13.209.11.161:3000/";

// export const statusURL = "http://10.220.120.75:3001";
// export const apiBaseUrl = "http://10.220.120.75:3000/";

// export const statusURL = "http://localhost:3001";
// export const apiBaseUrl = "http://localhost:3333/";

export const showWalletTokens = [
  "DAI",
  "DSR",
  "ETH",
  "SAI",
  "WETH",
  "BAT",
  "USDC"    
];

export const Networks = {
  MainNet: 1,
  Ropsten: 3,
  Rinkeby: 4,
  Goerli: 5,
  Kovan: 42,
}

export const NetworkNames = {
  1: "mainnet",
  3: "ropsten",
  4: "rinkeby",
  5: "goerli",
  42: "kovan"
}

export const POLLING_INTERVAL = 12000
export const NetworkUrls = {
  1: "https://mainnet.infura.io/v3/516f946979bc4fa187edcdc164e0bac0",
  3: "https://ropsten.infura.io/v3/516f946979bc4fa187edcdc164e0bac0",
  4: "https://rinkeby.infura.io/v3/516f946979bc4fa187edcdc164e0bac0",
  5: "https://goerli.infura.io/v3/516f946979bc4fa187edcdc164e0bac0",
  42: "https://kovan.infura.io/v3/516f946979bc4fa187edcdc164e0bac0"
}

export const wsRpcUrls = {
  1: "wss://mainnet.infura.io/ws/v3/5b8557eae1564bd88f64c2622c650d2e",
  3: "wss://ropsten.infura.io/ws/v3/5b8557eae1564bd88f64c2622c650d2e",
  4: "wss://rinkeby.infura.io/ws/v3/5b8557eae1564bd88f64c2622c650d2e",
  5: "wss://goerli.infura.io/ws/v3/5b8557eae1564bd88f64c2622c650d2e",
  42: "wss://kovan.infura.io/ws/v3/5b8557eae1564bd88f64c2622c650d2e"
}

// DAI  0x31f42841c2db5173425b5223809cf3a38fede360