import {
  ETH,
  BAT,
  USDC,
  // WBTC,
  // TUSD,
  // ZRX,
  // KNC,
  // MANA,
  // USDT,
  // PAXUSD,
  // COMP,
  // LRC,
  // LINK,
  // YFI,
  // BAL,
  // GUSD,
  // UNI,
  // RENBTC,
  // AAVE
} from '@makerdao/dai-plugin-mcd';

const ilkList = [
  {
    slug: 'eth-a',
    symbol: 'ETH-A',
    desc: "Ethereum",
    key: 'ETH-A',
    gem: 'ETH',
    icon: 'Ether',
    currency: ETH,
    btnStatus: false,
    btn: "DEFAULT",
    userBalance: 0
  },
  {
    slug: 'bat-a',
    symbol: 'BAT-A',
    desc: "Bitcoin",
    key: 'BAT-A',
    gem: 'BAT',
    icon: 'Bitcoin',
    currency: BAT,
    btnStatus: false,
    btn: "DEFAULT",
    userBalance: 0
  },
  {
    slug: 'usdc-a',
    symbol: 'USDC-A',
    desc: "USDC",
    key: 'USDC-A',
    gem: 'USDC',
    icon: 'USDC',
    currency: USDC,
    btnStatus: false,
    btn: "DEFAULT",
    userBalance: 0
  }
 ];

export default ilkList;