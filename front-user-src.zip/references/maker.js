import Maker from '@makerdao/dai';
import McdPlugin, { ETH,BAT,USDC,USD,DAI,SAI,defaultCdpTypes } from '@makerdao/dai-plugin-mcd';
// import GovernancePlugin from '@makerdao/dai-plugin-governance';
// import trezorPlugin from '@makerdao/dai-plugin-trezor-web';
// import ledgerPlugin from '@makerdao/dai-plugin-ledger-web';
// import walletLinkPlugin from '@makerdao/dai-plugin-walletlink';
// import mewconnectPlugin from '@myetherwallet/dai-plugin-mewconnect';
// import walletConnectPlugin from '@makerdao/dai-plugin-walletconnect';
// import dcentPlugin from 'dai-plugin-dcent-web';
// import portisPlugin from '@makerdao/dai-plugin-portis';
// import configPlugin from '@makerdao/dai-plugin-config';
import contractsAddresses from 'references/contracts/address';

import {defaultNetwork, NetworkNames} from "references/config"

export async function instantiateMaker({ rpcUrl }) {
  const addressOverrides = contractsAddresses;

  const mcdPluginConfig = {
    defaultCdpTypes,
    prefetch: false,
    addressOverrides
  };

  const networkName = NetworkNames[defaultNetwork];
  
  const config = {
    log: false,
    plugins: [
      [McdPlugin, mcdPluginConfig],
      // [GovernancePlugin, {network: networkName}]
    ],
    autoAuthenticate: true,
    smartContract: {
      addressOverrides
    },
    provider: {
      url: rpcUrl,
      type: 'HTTP', // 'WEBSOCKET'
    },
    web3: {
      pollingInterval: null
    },
    gas: {
      apiKey: '3e722dd73e76ba3d2eb7507e316727db8a71d1fbc960ed1018e999a53f75'
    },
    multicall: true
  };

  const maker = await Maker.create('http', config);
  
  // for debugging
  // window.maker = maker;

  return maker;
}

export { USD, DAI, ETH, BAT, SAI, USDC };
